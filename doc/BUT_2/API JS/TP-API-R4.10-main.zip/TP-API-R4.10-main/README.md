# Base de code pour le TP-API (R4.A.10)

Base de code pour le **TP-API - Développement d'une interface pour API publique**

Ressource R4.A.10 Compléments Web JavaScript côté client (IUT INFO de Grenoble)