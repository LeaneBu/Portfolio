const view = {
  btn_search: document.getElementById("btn-lancer-recherche"),
  btn_addFavorite: document.getElementById("btn-favoris"),
  date_earthDate: document.getElementById("earth-date"),
  ul_cameras: document.getElementById("camera-list"),
  ul_rovers: document.getElementById("rover-list"),
  ul_favorite: document.getElementById("liste-favoris"),
  div_result: document.getElementById("bloc-resultats"),
  div_waitingGif: document.getElementById("bloc-gif-attente"),
  btn_favoris: document.getElementById("btn-favoris"),
};
