import java.util.ArrayList;

// IMPORTANT: Il ne faut pas changer la signature des méthodes
// de cette classe, ni le nom de la classe.
// Vous pouvez par contre ajouter d'autres méthodes (ça devrait 
// être le cas)
class Board {   //   1  2  3
    // 1 0  0  0
    // 2 0  0  0
    // 3 0  0  0
    private Mark[][] board;

    // Ne pas changer la signature de cette méthode
    public Board() {
        this.board = new Mark[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                this.board[i][j] = Mark.EMPTY;
            }
        }
    }

    // Place la pièce 'mark' sur le plateau, à la
    // position spécifiée dans Move
    //
    // Ne pas changer la signature de cette méthode
    public void play(Move m, Mark mark) {
        if(board[m.getRow()][m.getCol()] == Mark.EMPTY){
            board[m.getRow()][m.getCol()] = mark;
        }
    }


    // Retourne  100 pour une victoire
    //          -100 pour une défaite
    //           0   pour un match nul
    // Ne pas changer la signature de cette méthode
    public int evaluate(Mark mark) {
        return 0;
    }

    // Retourne une liste des coups qu'il est possible
    // de jouer en fonction de l'état du plateau
    //
    // Ne pas changer la signature de cette méthode
    public ArrayList<Move> getAvailableMoves() {
        ArrayList<Move> moves = new ArrayList<Move>();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (this.board[i][j] == Mark.EMPTY) {
                    Move cases = new Move(i, j);
                    moves.add(cases);
                }
            }
        }
        return moves;
    }

    public void print() {
        System.out.println("-------------");
        for (int i = 0; i < 3; i++) {
            System.out.print("| ");
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == Mark.EMPTY) {
                    System.out.print(" ");
                } else {
                    System.out.print(board[i][j]);
                }
                System.out.print(" | ");
            }
            System.out.println("\n-------------");
        }
    }

    public boolean isGameFinished() {
        Mark mark = gameWin();
        boolean empty = getAvailableMoves().isEmpty();
        if (mark != Mark.EMPTY || empty) {
            if (!getAvailableMoves().isEmpty()){
                System.out.println(mark + " a gagné !!!!!");
            } else {
                System.out.println("Égalité RIP...");
            }
            return true;
        } else {
            return false;
        }
    }

    public Mark gameWin() {
        Mark mark = Mark.O;
        for (int i = 0; i < 2; i++) {
            if ((this.board[0][0] == mark && this.board[0][1] == mark && this.board[0][2] == mark) ||
                    (this.board[1][0] == mark && this.board[1][1] == mark && this.board[1][2] == mark) ||
                    (this.board[2][0] == mark && this.board[2][1] == mark && this.board[2][2] == mark)){
                return mark;
            }
            if ((this.board[0][0] == mark && this.board[1][0] == mark && this.board[2][0] == mark) ||
                    (this.board[0][1] == mark && this.board[1][1] == mark && this.board[2][1] == mark) ||
                    (this.board[0][2] == mark && this.board[1][2] == mark && this.board[2][2] == mark)){
                return mark;
            }
            if ((this.board[0][0] == mark && this.board[1][1] == mark && this.board[2][2] == mark) ||
                    (this.board[0][2] == mark && this.board[1][1] == mark && this.board[2][0] == mark)){
                return mark;
            }
            mark = Mark.X;
        }
        return Mark.EMPTY;
    }
}
