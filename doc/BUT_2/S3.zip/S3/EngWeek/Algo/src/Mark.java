
// marque soit X (joueur 1) soit O (joueur 2)
enum Mark{
        X,
        O,
        EMPTY
    }

