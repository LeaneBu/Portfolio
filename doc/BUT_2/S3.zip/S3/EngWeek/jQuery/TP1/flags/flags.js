/*$(function(){
    $('body').append('Hello World');
});*/

$(function(){
    var fr = $('<div/>');
    fr.append($('<div/>',{text:'France'}));
    fr.append($('<img/>',{src:'fr.gif'}));
    var gr = $('<div/>');
    gr.append($('<div/>',{text:'Greece'}));
    gr.append($('<img/>',{src:'gr.gif'}));
    var br = $('<div/>');
    br.append($('<div/>',{text:'Brazil'}));
    br.append($('<img/>',{src:'br.gif'}));
    //Création
    $('body').append(br);
    $('body').append(fr);
    $('body').append(gr);
    
    //CSS
    $('img').css('border','solid 3px gray');
    $('img').css('width',200);

    $('div div').css('text-align','center');

    $('body').css('font-family','arial');
    $('body').css('font-size','x-large');

    $('body>div').css('display', 'inline-block');
    $('body>div').css('width', 206);
    $('body>div').css('border', 'solid 2px black');
    $('body>div').css('padding', 24);
    $('body>div').css('margin', '1ex');

});



