$(function(){
  var doc = $.parseJSON($('#embeddedData').val());
  $('body').data('doc',doc); // This saves the doc object
  $('#bcf').text(doc.bcf);   // bcf is "balance carried forward"
  $('#odl').text(doc.odl);
  $('#cname').text(doc.cname);
  $('#caddr').text(doc.caddr.street+", "+doc.caddr.pc+" "+doc.caddr.town);
  
  //Table
  /* var tr = $('<tr/>');
  tr.append($('<td/>',{text:doc.spf}));
  tr.append($('<td/>',{text:'Balance carried forward'}));
  tr.append($('<td/>',{text:'','class':'num'}));
  tr.append($('<td/>',{text:'','class':'num'}));
  tr.append($('<td/>',{text:doc.bcf,'class':'num'}));
  $('#transactions').append(tr); */
  var balance = doc.bcf;
  for(var i=0;i<doc.trn.length;i++){
    var tr = $('<tr/>');
    tr.append($('<td/>',{text:doc.trn[i].whn}));
    tr.append($('<td/>',{text:doc.trn[i].nar}));
    var money = doc.trn[i].amt;
    if(money >= 0){
      tr.append($('<td/>',{text:'','class':'num'}));
      tr.append($('<td/>',{text:doc.trn[i].amt}));
    } else if (money < 0){
      tr.append($('<td/>',{text:0-doc.trn[i].amt}));
      tr.append($('<td/>',{text:'','class':'num'}));
    }
    tr.append($('<td/>',{text:doc.bcf,'class':'num'}));
    $('#transactions').append(tr);
  }

  $('#show').click(function(){
      fillTable($('#search').val().toUpperCase(),'results')
      $('#search').value = " ";
  });

  function fillTable(term){
    var doc = $.parseJSON($('#embeddedData').val());
    for(var i=0;i<doc.trn.length;i++){
      if (doc.trn[i].nar.indexOf(term)>-1){
        var tr = $('<tr/>',{'class':'generated'});
        tr.append($('<td/>',{text:doc.trn[i].whn}));
        tr.append($('<td/>',{text:doc.trn[i].nar}));
        tr.append($('<td/>',{text:doc.trn[i].amt}));
        tr.data('trn',doc.trn[i]);
        tr.appendTo($('#result'));
      }
    }
    }
});

