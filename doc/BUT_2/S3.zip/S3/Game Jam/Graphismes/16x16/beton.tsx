<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="beton" tilewidth="16" tileheight="16" tilecount="1850" columns="50">
 <image source="../img/beton.jpg" width="800" height="599"/>
</tileset>
