<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="blanc" tilewidth="16" tileheight="16" tilecount="180" columns="12">
 <image source="../img/blanc.png" width="197" height="255"/>
</tileset>
