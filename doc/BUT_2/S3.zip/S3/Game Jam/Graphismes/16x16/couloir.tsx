<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="couloir" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="../img/normal.png" width="512" height="512"/>
</tileset>
