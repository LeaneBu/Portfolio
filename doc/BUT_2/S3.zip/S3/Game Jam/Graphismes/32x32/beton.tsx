<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="beton" tilewidth="32" tileheight="32" tilecount="450" columns="25">
 <grid orientation="orthogonal" width="16" height="16"/>
 <image source="../../../Downloads/beton.jpg" width="800" height="599"/>
</tileset>
