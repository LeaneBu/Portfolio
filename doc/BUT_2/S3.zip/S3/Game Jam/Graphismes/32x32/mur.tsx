<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="mur" tilewidth="32" tileheight="32" tilecount="42" columns="6">
 <image source="../../../Downloads/noir.png" width="197" height="255"/>
</tileset>
