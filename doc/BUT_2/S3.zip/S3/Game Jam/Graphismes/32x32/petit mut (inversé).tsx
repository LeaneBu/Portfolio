<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="petit mur (inversé)" tilewidth="32" tileheight="16" margin="16" tilecount="70" columns="5">
 <image source="../../../Downloads/noir.png" width="197" height="255"/>
</tileset>
