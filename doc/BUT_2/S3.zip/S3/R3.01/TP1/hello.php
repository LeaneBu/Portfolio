<?php
    print("Hello world !\n");

?>
