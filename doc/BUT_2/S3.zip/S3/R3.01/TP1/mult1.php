<?php
    for($i = 0; $i<=10; $i++){
        $a = 9;
        $res = $i * $a;
        printf("%d x %d = %d\n", $a, $i, $res);
    }


?>