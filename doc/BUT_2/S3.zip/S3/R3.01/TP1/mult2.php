<?php

    $number = 0;
    printf("Quelle table ?: ");
    fscanf(STDIN, "%d\n", $number);

    for($i = 0; $i<=10; $i++){
        $res = $i * $number;
        printf("%d x %d = %d\n", $number, $i, $res);
    }

?>