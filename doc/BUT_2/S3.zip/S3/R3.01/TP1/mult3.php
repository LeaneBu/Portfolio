<?php

    for($i = 0; $i<=10; $i++){
        for($j = 0; $j<=10; $j++){
          $res = $i * $j;
        }
    }
?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Tables Multipications</title>
    <link href="mult3.css" rel="stylesheet" href="">
</head>
<body>
    <h1>Tables Multipications</h1>
    <table>
        <td> <p> </p></td>
    <?php for($a = 1; $a<=10; $a++){?>
        <th> <?= $a ?> </th>
    <?php }?>
        <?php for($i = 1; $i<=10; $i++){?>
            <tr>
                <th> <?= $i ?> </th>
                <?php for($j = 1; $j<=10; $j++){?>
                    <td> <?= $i*$j?> </td>
                <?php }?>
            </tr>
        <?php }?>
    </table>
</body>
</html>