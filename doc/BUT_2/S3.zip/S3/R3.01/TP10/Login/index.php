<?php
$login = $_POST['login'] ?? null;
$mdp = $_POST['password'] ?? null;
$submit = $_POST['submit'] ?? 'none';


var_dump($_POST);

session_start();
$_SESSION['login'] = $login;



switch($submit){
    case 'login':
        if (!is_null($login) && !is_null($login)){
            include("view/main.php");
        }
        else {
            include("view/login.html");
        }
        break;

    case 'new':
        include("view/not_implemented.html");
        break;

    default:
        // Envoit sur le login
        include("view/login.html");
}

?>
