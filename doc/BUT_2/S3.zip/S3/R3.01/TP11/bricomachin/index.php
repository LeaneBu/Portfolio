<?php
header('Location: controler/afficherArticles.ctrl.php'); 
