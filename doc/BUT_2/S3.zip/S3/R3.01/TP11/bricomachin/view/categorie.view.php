<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="author" content="Jean-Pierre Chevallet" />
  <link rel="stylesheet" type="text/css" href="../view/design/style.css">
  <title>Selection des categorie</title>
</head>
<body>
  <h1>Choisir une catégorie</h1>
  <!--    -->
  <!-- Placer ici le formulaire de sélection des sous catégories -->
  <!--  -->
</body>
</html>
