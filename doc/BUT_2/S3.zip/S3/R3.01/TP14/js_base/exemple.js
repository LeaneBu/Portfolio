console.log("hello")

let a = prompt("saisir un nombre", "1");
while(isNaN(a)){
    if(isNaN(a)){
      a = prompt("saisir un nombre", "1");  
    }
}
for(let i = 0; i<=10; i++){
    let res = i * a;
    console.log(a, " x ", i, " = ", res);
}

let un={
    nom : "Luc",
}

let deux={
    nom : "Léa",
}


let martin = {
    nom : "Martin",
    enfants : {
      1 : un,
      2 : deux,
    }
  }

function presenter(personne) {
    let texte = "Bonjour, je suis ";
    texte += personne.nom;
    texte += ". J'ai deux enfants : ";
    texte += personne.enfants[1].nom;
    texte += " et ";
    texte += personne.enfants[2].nom;
    return texte;
  }