<?php

header("Content-Type: text/plain; charset=utf-8");
$nom = $_GET["nom"] ?? "No value";
print("Hello  $nom !");

?>