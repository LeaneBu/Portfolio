<?php
header('Location: controler/main.ctrl.php'); 
