// Action de dempander l'heure au serveur 
function onSaluer() {
    view.input.value
    $reponse = view.input.value
    const xhttp = new XMLHttpRequest();

    xhttp.onload = function () {
        
    }
}

// Attache le controleur au bouton
view.button.onclick = onSaluer;