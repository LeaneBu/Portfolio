// Définition des paramètres de la vue 
const view = {
    // La zone input du header
    input: document.querySelector("header input"),
    // La zone de sortie, juste le body de la table dans le main
    tbody: document.querySelector("main table tbody"),

    
    // Fonction qui affiche un contact dans la table
    show: function (contacts) {
        // 
        ///////////////////////////////////////////////////////
        //  A COMPLETER
        ///////////////////////////////////////////////////////
        // 
    },

    //  
};
