<?php 

$abbrs = array('HTML' => 'HyperText Markeup Language',
'XML' => 'eXtended Markeup Language',
'PHP' => 'Hypertext PreProcessor',
'CSS' => 'Cascading Style Sheets');

function abbr(string $abbr): string {
    global $abbrs;
    $name = $abbrs[$abbr] ?? $abbr;
    return '<abbr title="' . $name . '">' . $abbr . '</abbr>';
}

function abbrAll() : string { 
  global $abbrs;
  $res = '<table>';
    foreach ($abbrs as $key => $value)
    {
        $res .= '<th>'"$key  $value" '</th>';
    }
    $res .= '</table>';
    return $res;
}

?>

<!DOCTYPE html>
<html lang="fr" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Test abbr</title>
</head>
<style media="screen">
abbr,th {
  color: blue;
}
</style>
<body>

  <h1>Exemple d'utilisation des abréviations en HTML</h1>

  <p>Le langage <?= abbr('PHP') ?> produit généralement
    du <?= abbr('HTML') ?> mais peu produire aussi
    du <?= abbr('XML') ?> ou même
    du <?= abbr('CSS') ?>.
  </p>
  <p>Voici toutes les abbréviations connues : </p>
  
  <?= abbrAll() ?>
  
</body>
</html>