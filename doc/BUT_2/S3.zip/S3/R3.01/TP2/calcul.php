<?php 

$a=$_GET['a'];
$b=$_GET['b'];
$op=$_GET['op'];



if(!isset($_GET['a'])){
    echo "erreur de variable a\n";
}
else if(!isset($_GET['b'])){
    echo "erreur de variable b\n";
}
else if(!isset($_GET['op'])){
    echo "erreur de variable op\n";
} else{
    switch ($op) {
        case '+':
            echo $a . ' + ' . $b . ' = ' . $a + $b;
            break;
        case '-':
            echo $a . ' - ' . $b . ' = ' . $a - $b;
            break;
        case '*':
            echo $a . ' * ' . $b . ' = ' . $a * $b;
            break;
        case '/':
            echo $a . ' / ' . $b . ' = ' . $a / $b;
            break;
        default:
            echo "opérateur incorrect";
            break;
    }
}

?>