<?php

$a = 1;
$a .='0 est une chaîne';
$b = 2*5;
if ($a == $b ) {
  echo "<p>'$a' et '$b' sont équivalents</p>";
}
if ($a === $b ) {
    echo "<p>'$a' et '$b' sont identiques</p>";
} else {
    echo "<p>'$a' et '$b' sont différents</p>";
}

//a et b n'ont pas la même valeur même après la conversion du type de a en nombre, ils n'ont pas non plus le même type donc a et b sont différents 
?>