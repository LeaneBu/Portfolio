<?php 

$music=$_GET['music'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <header>
        <h1><?php echo 'Playing:' . $music ?></h1>
    </header>
    <nav>
        <a href="staticJukebox.html"> &#11013 Retour</a>
    </nav>
    <main>
        <section>
        <figure>
            <a>
            <img src=<?php echo 'data/'. $music .'.jpeg'  ?> />
            </a>
            <audio src="<?php echo 'data/'. $music . '.mp3'?>" controls="" autoplay=""></audio>
        </figure>
        </section>
    </main>
</body>
</html>