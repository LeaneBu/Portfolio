<?php
// Partie CONTRÔLE de cette page WEB

// Récupération du sens, de l'action à réaliser et de la température en entrée
$sens = $_GET['sens'] ?? 'C2F';
$action = $_GET['action'] ?? 'convertir';

if ($action=='inverser' && $sens == 'F2C'){
  $sens = 'C2F';
} elseif ($action =='inverser' && $sens == 'C2F' ){
  $sens = 'F2C';
} else {
  $sens = 'C2F';
}
$label1 = ($sens == 'C2F') ? 'Celsius' : 'Fahrenheit';
$label2 = ($sens == 'C2F') ? 'fahrenheit' : 'celsius';

// Placer ici la récupération des données de la query string et le calcul
$temp_in = $_GET['temp_in'] ?? '';


if ((isset($temp_in)) && $temp_in != '' && $action=='convertir'){
  $temp_out = 1.8 * $temp_in + 32.0;
} elseif ($sens == 'F2C' && $temp_in != '') {
  $temp_out = ($temp_in - 32) * (5/9);
} else {
  $temp_out = 'X';
}



  // La suite est la partie VUE
  ?>
  <!DOCTYPE html>
  <html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Conversion Celcius/Fahrenheit</title>
    <link rel="stylesheet" href="design/style.css">
  </head>
  <body>
    <h1>Conversion de températures</h1>
    <form  action="conversion2.php" method="get">
      <button type="submit" name="action" value="inverser">Inverser</button>
      <input id="in" type="number" step="any" name="temp_in" value="<?=$temp_in?>">
      <label for="in"> <?php echo $label1; ?> </label>
      égal
      <output id="out" for="in" name="temp_out"><?=$temp_out?></output>
      <label for="out"> <?php echo $label2; ?> </label>
      <button type="submit" name="action" value="convertir">Convertir</button>
      <input type="hidden" name="sens" value="<?=$sens ?>">
    </form>
  </body>
  </html>
