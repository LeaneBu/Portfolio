<?php
// A completer
$nom = $_GET['nom'] ?? '';
$mdp = $_GET['mdp'] ?? '';

?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body>
    <h1>Sur le site</h1>
    <p>
      Bonjour <?php echo $nom; ?>, ton mot de passe fait <?php echo strlen($mdp); ?> caracteres.

    </p>
  </body>
</html>
