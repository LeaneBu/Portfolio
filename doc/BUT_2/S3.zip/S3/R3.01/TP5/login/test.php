<?php
var_dump($_GET);
?>
