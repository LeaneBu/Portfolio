<?php

//
function readCSV(string $filename,string $delimiter=',') : array {
  $res = array();

  return $res;
}

 ?>
