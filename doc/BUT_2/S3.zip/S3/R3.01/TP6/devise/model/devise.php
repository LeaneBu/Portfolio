<?php

class Devise {

}


?>
