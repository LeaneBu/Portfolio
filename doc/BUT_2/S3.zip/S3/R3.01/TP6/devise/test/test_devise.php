<?php
require_once('../model/devise.php');

$d = new Devise("EUR","Euro");
var_dump($d);


?>
