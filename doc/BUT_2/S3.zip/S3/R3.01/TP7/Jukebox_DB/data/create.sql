CREATE TABLE music (
    id INTEGER PRIMARY KEY,
    author STRING,
    title STRING,
    cover STRING,
    mp3 STRING,
    category STRING
);