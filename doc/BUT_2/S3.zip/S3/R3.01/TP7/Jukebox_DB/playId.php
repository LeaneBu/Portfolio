<?php
// Joue une musique conneu par son Id
// Inclusion du modèle
require_once('model/music.class.php');
require_once('model/dao.class.php');

$dao = new DAO();
$id = $_GET['id'] ?? $id=1;
$music = $dao->get($id);

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="design/style.css">
    <title></title>
  </head>
  <body>
    <header>
      <h1>Playing : <?= $music->getTitle() ?> BY <?= $music->getAuthor() ?></h1>
    </header>
    <nav>
      <a href="jukebox.php?page=1&pageSize=8">
        back
      </a>
    </nav>
    <section>
      <figure>
        <img src="http://www-info.iut2.upmf-grenoble.fr/intranet/enseignements/ProgWeb/data/musiques/img/<?php echo $id ?>.jpg">
        <audio src="http://www-info.iut2.upmf-grenoble.fr/intranet/enseignements/ProgWeb/data/musiques/mp3/<?php echo $id ?>.mp3" controls autoplay ></audio>
      </figure>
    </section>
    <br/>
  </body>
</html>
