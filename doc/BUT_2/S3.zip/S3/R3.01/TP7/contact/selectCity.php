<?php

$dataSourceName = 'sqlite:'.__DIR__.'/data/contact.db';
$db = new PDO($dataSourceName);

// récupère les informations de la query string
$city = $_GET['city'] ?? 'Dallas';

$pdoSth = $db->query("SELECT DISTINCT city FROM contact");
$data = $pdoSth->fetchall();


 ?>
<!DOCTYPE html>
<html lang="fr" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="design/style.css">
    <title>My contacts</title>
  </head>
  <body>
    <h1>My contacts from : select a city</h1>
    <form action="contact.php" method="get">
        <table>
        <?php foreach ($data as $villes): ?>
        <tr>
            <label for="villes">
                <td>
                <?= $villes['city'] ?>
                <input id="ville" type="radio" name="city" value="<?=$villes['city']?>">
                </td>    
            </label>
        </tr> 
        <?php endforeach; ?>
        </table>
        <button type="submit" name="action" value="select"> Select </button>
    </form>
  </body>
</html>