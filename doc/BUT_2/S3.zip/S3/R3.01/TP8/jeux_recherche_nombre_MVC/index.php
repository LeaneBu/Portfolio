<?php
  // Indique le point de démarrage de l'application
  header('Location: controler/main.ctrl.php');
  /* Il y a volontairement pas de ?> àa la fin de ce fichier */
