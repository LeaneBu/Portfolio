<html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="../view/design/style.css">
</head>
<body>
<h1> Le Jeu du nombre </h1>
<p> C'est dommage <?= $nom ?> que vous ne voulez pas jouer avec moi.</p>
<p> A une autre fois !</p>
</body>
</html>
