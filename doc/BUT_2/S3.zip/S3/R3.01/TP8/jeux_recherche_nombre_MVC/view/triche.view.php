<html>
<head>
  <meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="../view/design/style.css">
</head>
<body>
<h1> Le Jeux du nombre </h1>
<p> Cher <?= $nom ?>, vous avez triché !
  Je ne veux plus jouer avec vous. </p>
</body>
</html>
