<?php
// Controleur pour l'action sur les articles
// 
// Inclusion du framework
include_once(__DIR__."/../framework/view.class.php");
// Inclusion du modèle
include_once(__DIR__."/../model/Article.class.php");
// Nom du répertoire ou stocker les images téléchargées
$imgPath = __DIR__."/../data/img/";

// 
//
///////////////////////////////////////////////////////////////////////////////
// Partie récupération des données
///////////////////////////////////////////////////////////////////////////////

$ref = $_GET['ref'] ?? 0;

///////////////////////////////////////////////////////////////////////////////
// Partie calculs avec le modèle
///////////////////////////////////////////////////////////////////////////////

// Test pour afficher les erreurs
$error=array();
if ($ref==0) {
  $error[] = 'La reférence doit être non nulle';
}

// Crée un article vide
$article = new Article();

// S'il n'y a  pas d'erreur, on recherche l'objet
if (count($error) == 0) {
  try {
    $article = Article::read($ref);
  } catch (Exception $e) {
    $error[] = $e->getMessage();
  }
}

////////////////////////////////////////////////////////////////////////////
// Construction de la vue
////////////////////////////////////////////////////////////////////////////
$view = new View();
$view->assign('ref',$ref);
$view->assign('libelle',$article->getLibelle());
$view->assign('prix',$article->getPrix());
$view->assign('categorie',$article->getCategorie()->getNom());
$view->assign('imageURL',$article->getImageURL());
$view->assign('error',$error);
$view->display("article.read.view.php");

// 
?>
