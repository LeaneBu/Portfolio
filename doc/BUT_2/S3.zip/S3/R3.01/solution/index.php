<?php
header('Location: controler/login.ctrl.php'); 
