<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Vue principale du backoffice</title>
  <meta name="author" content="Jean-Pierre Chevallet" />
  <link rel="stylesheet" type="text/css" href="../view/design/style.css">
</head>
<body>
  <header>
    <h1>Bricomachin: backoffice</h1>
  </header>
  <aside>
    <!-- Menu  -->
    <?php include(__DIR__.'/menu.viewpart.php'); ?>
  </aside>
  <main>
    <h2>Accès à un article</h2>
    <form action="article.read.ctrl.php" method="get">
      <!--  -->
      <p>
        <label for="ref">Référence</label>
        <input type="number" id="ref" name="ref" value="<?= $ref ?>">
      </p>
      <p>
        <label for="libelle">Libéllé</label>
        <textarea id="libelle" name="libelle" rows="1" cols="30" readonly><?= $libelle ?></textarea>
      </p>
      <p>
        <label for="categorie">Catégorie</label>
        <input type="text" id="categorie" name="categorie"  value="<?= $categorie ?>" readonly>
      </p>
      <p>
        <label for="prix">Prix</label>
        <input type="number" step=".01" id="prix" name="prix" value="<?= $prix ?>" readonly>
      </p>
      <p>
          <img src="<?=$imageURL?>" alt="Photo produit">
      </p>
      <button type="submit" name="add">Rechercher</button>
      <!--  -->
    </form>
    <?php if (isset($error) && count($error) != 0) : ?>
      <output class="error">
        <p>L'article n'a pa été trouvé à cause des erreurs suivantes : </p>
        <ul>
          <?php foreach ($error as $ligne) : ?>
            <li>
              <?= $ligne ?>
              <//li>
            <?php endforeach; ?>
          </ul>
        </output>
      <?php endif; ?>
      <?php if (isset($message) && $message != "") : ?>
        <output>
          <?= $message ?>
        </output>
      <?php endif; ?>
    </main>
  </body>
  </html>
