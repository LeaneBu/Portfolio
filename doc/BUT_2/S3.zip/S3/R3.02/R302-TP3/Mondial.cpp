/* 
 * File:   Mondial.cpp
 * Author: hb
 * 
 * Created on 22 novembre 2018, 16:05
 */

#include "Mondial.h"


#include <iostream>     // pour cout
#include <iomanip>      // pour setw()
#include <iterator>

Mondial::Mondial(const char *filename) {
    // Chargement du fichier XML en mémoire
    imageMondial.LoadFile(filename);
    // Initialisation de l'attribut racineMondial avec la racine (élément <mondial>)
    racineMondial = imageMondial.FirstChildElement();
}

void Mondial::Print() {
    imageMondial.Print();
}

/*
 * FOURNIE
 */
int Mondial::getNbAirports() const {
    // initialisation du nombre d’aéroports
    int nb = 0;
    // accéder à <airportscategory>, c’est un fils de l'élément <racineMondial>
    XMLElement *airportsCategory = racineMondial->FirstChildElement("airportscategory");
    // parcours complet des fils de <airportscategory> en les comptants
    // 1) accéder au premier fils <airport> de <airportscategory>
    XMLElement *currentAirport = airportsCategory->FirstChildElement();
    // 2) parcourir tous les <airport> qui sont des frères
    while (currentAirport != nullptr) {
        // un aéroport supplémentaire
        nb = nb + 1;
        // avancer au frère <airport> suivant de currentAirport
        currentAirport = currentAirport->NextSiblingElement();
    }
    // currentAirport n’a plus de frère {currentAirport == nullptr}, c’est le dernier
    return nb;
}

/*
 * FOURNIE
 */
void Mondial::printCountriesCode() const {
    int rank = 1; // rang du pays
    string carcodeValue; // valeur de l'attribut "car_cod" du pays courant
    // accéder à <countriescategory>, c’est un fils de l'élément <racineMondial>)
    XMLElement *countriesCategory = racineMondial->FirstChildElement("countriescategory");
    // parcours complet des fils de <countriescategory> en affichant le rang et le code
    // 1) accéder au premier fils <country> de <countriescategory>
    XMLElement *currentCountry = countriesCategory->FirstChildElement();
    // 2) parcourir tous les <country> qui sont des frères
    while (currentCountry != nullptr) {
        // traiter le pays courant
        //      1) récupérer la valeur de l’attribut "car_code"
        carcodeValue = currentCountry->Attribute("car_code");
        //      2) faire l’affichage
        cout << setw(5) << rank << " : " << carcodeValue << endl;
        // avancer au frère <country> suivant de currentCountry
        currentCountry = currentCountry->NextSiblingElement();
        // mettre à jour le rang
        rank = rank + 1;
    }
    // currentCountry n’a pas de frère {currentCountry == nullptr}, c’est fini
}


/*
 * A COMPLETER
 */
//TODO: Exo 1:getNbDeserts()
int Mondial::getNbDeserts() const {
    // accéder à desertCat, c’est un fils de l'élément racineMondial
    XMLElement *desertCat = racineMondial->FirstChildElement("desertscategory");
    // accéder au premier fils desert de desertCat
    XMLElement *desert = desertCat->FirstChildElement("desert");
    int count = 0;

    //parcours de tous les deserts
    while (desert != nullptr) {
        count = count + 1;
        desert = desert->NextSiblingElement("desert");
    }
    // return le nombre de desert contenu dans la base de données
    return count;
}

/*
 * A COMPLETER
 */
//TODO: Exo 2:getNbElemCat()
int Mondial::getNbElemCat(const string &categoryName) {
    // accéder à nameCat, c’est un fils de l'élément racineMondial
    XMLElement *nameCat = racineMondial->FirstChildElement(categoryName.c_str());
    // accéder au premier fils categorie de nameCat
    XMLElement *categorie = nameCat->FirstChildElement();

    int count = 0;

    //parcours de tous les deserts
    while (categorie != nullptr) {
        count = count + 1;
        categorie = categorie->NextSiblingElement();
    }
    // return le nombre d'élément d'une category (ex: désert comme l'exo précédent ou airport dans le cours)
    return count;
}

/*
 * On recherche le pays dont le nom est countryname
 * resultat = le pays recherché recursivement dans le worker
 */
//TODO: Exo 3:getCountryXmlelementFromNameRec()
XMLElement *Mondial::getCountryXmlelementFromNameRec(const string &countryName) const {
    return getCountryXmlelementFromNameRecWorker(racineMondial
                                                         ->FirstChildElement("countriescategory")
                                                         ->FirstChildElement("country"), countryName);
}

/*
 * On recherche récursivement dans la liste des pays le pays dont le nom est countryname
 * resultat = un pointeur sur le pays dont le nom correspond à countryname, s'il exsite
 *          = nullptr sinon
 */
XMLElement *
Mondial::getCountryXmlelementFromNameRecWorker(XMLElement *currentCountryElement, const string &countryName) const {
    if (currentCountryElement == nullptr)
        return nullptr; // on a parcouru récursivement toute la liste de pays et on n'a pas trouvé
    else if (currentCountryElement->FirstChildElement("name")->GetText() == countryName)
        return currentCountryElement;
    else
        return getCountryXmlelementFromNameRecWorker(currentCountryElement->NextSiblingElement("country"), countryName);
}

/*
 * On recherche à obtenir le code du pays en fonction du nom
 * resultat = le code du pays correspondant au countryName
 */
string Mondial::getCountryCodeFromName(const string &countryName) const {
    XMLElement *pPays = getCountryXmlelementFromNameRec(countryName);
    if (!pPays) {
        throw PrecondVioleeExcep("Pays inexistant");
    } else return pPays->Attribute("car_code");
}


/**
 * élément <country> d'un pays identifié par son nom countryName
 * @param countryName
 * @return pointeur sur l'élément <country> dont la valeur du fils <name> est égal à countryName, nullprt sinon
 */
//TODO: Exo 4:getCountryPopulationFromName
XMLElement *Mondial::getCountryXmlelementFromNameIter(const string &countryName) const {
    // Acceder au pays dont on donne le nom countryName
    XMLElement *country = racineMondial->FirstChildElement("countriescategory")
            ->FirstChildElement("country");

    // Recherche d'un élément dans une liste non triée
    // rechercher l'élément qui correspond au nom du pays si il existe
    while (country != nullptr && country->FirstChildElement("name")->GetText() != countryName) {
        country = country->NextSiblingElement("country");
    }
    // country == nullptr (on n'a pas trouvé) || country pointe sur le pays dont on cherche le nom
    return country;
}

/*
 * On recherche à obtenir la population du pays meusurée au cours de l'année la plus récente
 * resultat = le nombre d'habitant (population) si le pays existe et que la population existe
 *          = 0 si la population n'est pas enregistré
 *          = -1 si le pays n'existe pas
 */
int Mondial::getCountryPopulationFromName(const string &countryName) const {
    //acceder au pays dont on donne le nom countryName
    XMLElement *pPays = getCountryXmlelementFromNameIter(countryName);
    //on vérifie que le pays existe
    if (pPays == nullptr) {
        return -1;
    } else {
        //on récupère la population
        XMLElement *population = pPays->FirstChildElement("population");
        int popYearMax = 0;
        int yearMax = 0;
        while (population != nullptr) {
            //on crée une variable contenant l'année courante celle qu'on vient de récupérer
            int year = stoi(population->Attribute("year"));
            if (year > yearMax) {
                yearMax = year;                         //on modifie la valeur de l'année max avec l'année courante
                popYearMax = stoi(population->GetText());                   //on récupère sa population
            }
            population = population->NextSiblingElement("population");
        }
        return popYearMax;
    }
}

/*
 * On recherche à obtenir le code du pays
 * resultat = un pointeur sur le pays correspondant au code
 */
//TODO: Exo 5:printCountryBorders()
XMLElement *Mondial::getCountryXmlelementFromCode(const string &countryCode) const {
    //acceder au pays dont on donne le code countryCode
    XMLElement *country = racineMondial->FirstChildElement("countriescategory")
            ->FirstChildElement("country");

    while (country != nullptr){
        if (country->Attribute("car_code") == countryCode){
            return country;
        }
        country=country->NextSiblingElement("country");
    }
    return country;

}

/*
 * On recherche à obtenir le(s) pays frontaliers au pays choisi countryName
 * resultat = affiche le(s) pays frontaliers obtenus grâce à la récupération de le car_code
 */
void Mondial::printCountryBorders(const string &countryName) const {
    //acceder au pays dont on donne le nom countryName
    XMLElement *country = getCountryXmlelementFromNameIter(countryName);
    //nom de pays inexistant
     if (country == nullptr){
        cout << countryName << " n'existe pas" ;
        return;
    }
    cout << "Le pays " << countryName;
    //acceder aux forntières du pays
    XMLElement *border = country->FirstChildElement("border");
    if (border == nullptr){
        cout << " n'a pas de pays frontalier";
        return;
    }
    cout << " a comme frontière :" << endl;
    while (border != nullptr){
        int tailleFront = stoi(border->Attribute("length"));                //on récupère la longueur de la frontière
        string codePays = border->Attribute("country");                     //on récupère le code du pays frontalier
        XMLElement *pays = getCountryXmlelementFromCode(codePays);      //on l'associe à son nom de pays
        cout <<"- "<< pays->FirstChildElement("name")->GetText() << " de longueur " << tailleFront << "km" << endl;
        border = border->NextSiblingElement("border");
    }

}

/*
 * On recherche à obtenir la rivière cherchée
 * resultat = un pointeur sur la rivière correspondant au riverName
 */
//TODO: Exo 6:printAllCountriesCrossedByRiver()
XMLElement *Mondial::getRiverXmlelementFromNameIter(const string &riverName) const {
    // Acceder à la rivière dont on donne le nom riverName
    XMLElement *river = racineMondial->FirstChildElement("riverscategory")
            ->FirstChildElement("river");

    // Recherche d'un élément dans une liste non triée
    // rechercher l'élément qui correspond au nom du pays si il existe
    while (river != nullptr && river->FirstChildElement("name")->GetText() != riverName) {
        river = river->NextSiblingElement("river");
    }
    // river == nullptr (on n'a pas trouvé) || river pointe sur la rivière dont on cherche le nom
    return river;
}

/*
 * On recherche à obtenir les pays traversés par la rivière cherchée
 * resultat = affichage des pays étant traversé par la rivière
 */
void Mondial::printAllCountriesCrossedByRiver(const string &riverName) const {
    // Acceder à la rivière dont on donne le nom riverName
    XMLElement *river = getRiverXmlelementFromNameIter(riverName);
    //on vérifie si la rivière existe
    if (river == nullptr){
        cout << "La rivière " << riverName << " n'existe pas";
    } else {
        string country = river->Attribute("country");           //on récupère les codes des pays étant traversés par la rivière
        vector<string> codesPays = split(country, ' ');       //on les sépare avec split pour les mettre dans un vecteur de "code"
        cout << "La Rivière " << riverName << " de longueur " << river->FirstChildElement("length")->GetText() << "km traverse :" << endl;
        //on parcours tout le vecteur des codes des pays et on leur associe leur nom
        for(int i = 0; i < codesPays.size(); i++){
            XMLElement *code = getCountryXmlelementFromCode(codesPays[i]);
            cout << "- " << code->FirstChildElement("name")->GetText() << endl ;
        }
    }
}

/*
 * On recherche à obtenir les pays traversés (avec la balise located) par la rivière cherchée
 * resultat = affichage des pays étant traversées par la rivière
 *
 */
void Mondial::printCountriesWithProvincesCrossedByRiver(const string &riverName) const {
    // Acceder à la rivière dont on donne le nom riverName
    XMLElement *river = getRiverXmlelementFromNameIter(riverName);
    //on vérifie si la rivière existe
    if (river == nullptr){
        cout << "La rivière " << riverName << " n'existe pas";
    } else {
        XMLElement *located = river->FirstChildElement("located");          //on récupère les "pays" étant traversés par la rivière
        cout << "La Rivière " << riverName << " de longueur " << river->FirstChildElement("length")->GetText() << "km traverse :" << endl;
        if (located == nullptr){
            cout << "Aucun pays";
        }
        else {
            while (located != nullptr){
                XMLElement *code = getCountryXmlelementFromCode(located->Attribute("country"));        //on récupère les codes des pays étant traversés par la rivière
                cout << "- " << code->FirstChildElement("name")->GetText() << endl;
                located=located->NextSiblingElement("located");
            }
        }
    }
}

/*
 * On recherche à obtenir le pays ET SES PROVINCES traversées par la rivière cherchée
 * resultat = affichage des pays et provinces étant traversées par la rivière
 */
//TODO: Exo 7:printCountriesAndProvincesCrossedByRiver()
void Mondial::printCountriesAndProvincesCrossedByRiver(const string &riverName) const {
    // Acceder à la rivière dont on donne le nom riverName
    XMLElement *river = getRiverXmlelementFromNameIter(riverName);
    //on vérifie si la rivière existe
    if (river == nullptr){
        cout << "La rivière " << riverName << " n'existe pas";
    } else {
        XMLElement *located = river->FirstChildElement("located");          //on récupère les "pays" étant traversés par la rivière
        cout << "La Rivière " << riverName << " de longueur " << river->FirstChildElement("length")->GetText() << "m traverse :" << endl;
        if (located == nullptr){
            cout << "Aucun pays";
        }
        else {
            while (located != nullptr){
                XMLElement *code = getCountryXmlelementFromCode(located->Attribute("country"));         //on récupère les codes des pays étant traversés par la rivière
                cout << "- "<< code->FirstChildElement("name")->GetText() << ", où il traverse les divisions administratives suivantes :" << endl;
                string province = located->Attribute("province");         //on récupère les provinces du pays étant traversé par la rivière
                vector<string> provinces = split(province, ' ');        //on les sépare avec split pour les mettre dans un vecteur de "provinces"
                //on parcours tout le vecteur des provinces des pays
                for(int i=0; i<provinces.size(); i++){
                    cout << " * "<< provinces[i] << endl;
                }
                located=located->NextSiblingElement("located");
            }
        }

    }
}

/*
 * On recherche à obtenir le pays associé au nom de la ville donnée
 * resultat = les informations liées à la ville (nom du pays, sa latitude, sa longitude, sa population récente et le nom de la province)
 */
//TODO: Exo 8:printCityInformation()
void Mondial::printCityInformation(const string &cityName) const {
    //acceder au pays dont on donne le code countryCode
    XMLElement *country = racineMondial->FirstChildElement("countriescategory")
            ->FirstChildElement("country");
}

/**
 * Exemple de question additionnelle pour l'exercice 9 afficher toutes les informations disponibles
 * dans Mondial concernant toutes les îles.
 * On peut commencer par une île en particulier à partir de son nom
 */
void Mondial::printIslandsInformations() const {
    /*
     * A COMPLETER
     */
}

/* RENDU:
 * Sur chamilo, déposer UN ZIP contenant TOUT le contenu du projet
 * SAUF :
 *  - le dossier  cmake-build-debug
 *  - le fichier mondial_HB.xml
 *  - les pdf
 */

/*
 * Méthodes de service fournies
 */

template<typename Out>
void Mondial::split(string &s, char delim, Out result) const {
    stringstream ss(s);
    string item;
    while (getline(ss, item, delim)) {
        *(result++) = item;
    }
}

/**
 * Méthode à utiliser pour découper les mots d'une chaîne dans un vecteur
 * Utile pour la gestion des attributs à valeurs multiples
 * @param s chaîne à découper
 * @param delim délimiteur des mots de la chaîne à découper
 * @return vecteur contenant les mots de la chaîne découpée
 */
vector<std::string> Mondial::split(string &s, char delim) const {
    vector<std::string> elems;
    split(s, delim, back_inserter(elems));
    return elems;
}

Mondial::~Mondial() {
}