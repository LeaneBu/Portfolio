// Dans le fichier d'implémentation d'une classe, on doit inclure le fichier de spécification de cette classe
#include "Point.h"

// Et on inclura aussi les librairies utilisées ici
#include <string>

using namespace std;                                        //évite de l'utiliser "std::" à chaque fois
// A COMPLETER - Implémenter les méthodes de la classe Point

//on re-declare nos constantes
const string Point::NOM_DEF = "origine";                                  // ATTENTION /!\ pas de STATIC dans le fichier .cpp UNIQUEMENT en .h || sans std:: devant string car on l'a défini dans "using namespace"
                                                                        // dans un fichier .cpp je peux lui donner une valeur ici "origine" || ATTENTION il faut le lier à ma classe Point avec Point:: devant le nom de ma constantes
const int Point::X_DEF = 0;
const int Point::Y_DEF = 0;

//appel du constructeur comme en Java
/**Point::Point(const std::string &nom, int x, int y) {
    this->m_nom = nom;//this->setNom(nom) fait la même chose mais permet de faire des vérifications et de gérer les cohérences      //"this" est pointeur en parametre par défaut dans notre constructeur qui pointe notre objet dont elle doit attribuer le nom
    this->m_x = x;//this->setX(x)
    this->m_y = y;//this->setY(y)
}**/
//appel du constructeur en C++
Point::Point(const string &nom, int x, int y) : m_nom(nom), m_x(x), m_y(y) {}                      //initialisation en C++ (pratique si on a pas de setteurs)

//destructeur
Point::~Point() {                           //il est appelé juste avant que le Point soit détruit de la mémoire
    cout << "destruction imminente du pointe" << this->getNom() << endl;                //affiche "destruction imminente" + "le nom du point qui va être effacer de la mémoire"
}

//méthodes getteurs
const string &Point::getNom() const {
    return this->m_nom;
}
int Point::getX() const {
    return this->m_x;
}
int Point::getY() const {
    return this->m_y;
}
//méthodes setteurs
void Point::setNom(const string &nom) {
    this->m_nom=nom;
}
void Point::setX(int x) {
    this->m_x=x;
}
void Point::setY(int y) {
    this->m_y=y;
}

//méthodes
void Point::saisir(istream &entree) {
    entree >> m_nom >> m_x >> m_y;
}
void Point::afficher(ostream &sortie) const {
    sortie << m_nom << m_x << m_y;
}




