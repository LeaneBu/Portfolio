// Les 2 directives ci-cessous permettent d'éviter les problèmes d'inclusions multiples d'une même classe
#ifndef POINT_H
#define POINT_H

// On inclut les librairies utilisées dans le fichier
#include <iostream>
#include <string>
// Attention : pas de clause "using namespace" dans un fichier ".h" !

class Point {
public:
    Point(const std::string & nom = NOM_DEF, int x = X_DEF, int y = Y_DEF);                      //penser au & quand je place un objet qui sera TOUJOURS par référence
    ~Point();
    const std::string & getNom() const;                             //méthode constante, elle ne va pas pouvoir modifier l'objet || "const std::string &" avec & on donne l'accès à notre objet mais on veut pas qu'il soit modifier donc on ajoute "const"
    int getX() const;
    int getY() const;
    void setNom(const std:: string & nom);
    void setX(int x);
    void setY(int y);
    void saisir (std::istream & entree = std::cin);
    void afficher (std::ostream & sortie = std::cout)const;


private:
    // attributs d'instance (spécifique à chacun)
    std::string m_nom;
    int m_x;
    int m_y;
    // attributs de classe (spécifique à un Point)
    static const std::string NOM_DEF;
    static const int X_DEF;
    static const int Y_DEF;

};

#endif /* POINT_H */

