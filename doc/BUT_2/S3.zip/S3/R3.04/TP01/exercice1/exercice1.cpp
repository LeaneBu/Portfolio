#include <cstdlib>
#include <iostream>
#include <string>
#include "Point.h"
using namespace std;

void testClassePoint(const string &nom, int x, int y){
    Point p(nom, x, y);
    cout << "Test de getX()"                    << endl
         << "Valeur attendue : " << x           << endl
         << "Valeur obtenue : " << p.getX()     << endl
         << (p.getX()==x ? "Succès" : "Echec")  << endl;
}



int main(int argc, char** argv) {

    // à compléter 
    
    return 0;
    
}

