#include <cstdlib>

using namespace std;


int main(int argc, char** argv) {
    
    // à compléter

    return 0;
}

