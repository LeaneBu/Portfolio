#include <cstdlib>
#include <iostream>
#include "EntierContraint.h"
using namespace std;

int main(int argc, char** argv) {
    
    // A Compléter
    // Il faut tester operator int, operator << et operator >> sur la classe EntierContraint

    cout << "----Test cast applé explicitement----\n";
    try {
        EntierContraint ec(50, 0, 100);
        int i;
        i = int(ec);
        cout << "i=" << i << "=" << ec;
    } catch (char const * exception) {
        cout << "Opérateurs non foctionnels";
    }

    cout << "\n----Test cast applé implicitement----\n";
    try {
        EntierContraint ec(60, 0, 100);
        int i;
        i = ec;
        cout << "i=" << i << "=" << ec;
    } catch (char const * exception) {
        cout << "Opérateurs non foctionnels";
    }

    cout << "\n----Test cast applé implicitement (avec addition)----\n";
    try {
        EntierContraint ec(60, 0, 100);
        int i;
        i = 1 + ec ;
        cout << "i=" << i << "=" << ec;
    } catch (char const * exception) {
        cout << "Opérateurs non foctionnels";
    }

    cout << "\n----Test lire un entier----\n";
    try {
        EntierContraint ec(70, 0, 100);
        cin >> ec;
        int i;
        i = ec;
        cout << "i=" << i << "=" << ec;
    } catch (char const * exception) {
        cout << "Opérateurs non foctionnels";
    }

    cout << "\n----Test affecter un entier à ec----\n";
    try {
        EntierContraint ec(70, 0, 100);
        int i = 30;
        ec = i;
        cout << "ec=" << ec << "=" << i;
    } catch (char const * exception) {
        cout << "Opérateurs non foctionnels";
    }

    return 0;
}

