#include "Groupe.h"
#include "Personne.h"
#include <string>
#include <iostream>

using namespace std;

// A COMPLETER
// Implémenter les méthodes nécessaires pour la forme canonique de COPLIEN

Groupe::Groupe() {

}

Groupe::Groupe(const std::string &intitule)
        : m_intitule(intitule) {
}

Groupe::Groupe(const Groupe &other) {
    copy(other);
}
Groupe::~Groupe() {
    clear();
}

///////////////////////////////////////////////////
void Groupe::setIntitule(const std::string &intitule) {
    this->m_intitule = intitule;
}

///////////////////////////////////////////////////
void Groupe::addPersonne(const std::string &nom) {
    this->m_effectif.push_back(new Personne(nom));
}

///////////////////////////////////////////////////
void Groupe::setNomPersonne(unsigned int i,
                            const std::string nom) {
    if (i < this->m_effectif.size())
        this->m_effectif[i]->setNom(nom);
}

///////////////////////////////////////////////////
void Groupe::affiche() const {
    cout << "Groupe " << this->m_intitule << " = { ";
    for (Personne *personne: this->m_effectif)
        cout << personne->getNom() << " ";
    cout << "}" << endl;
}

Groupe &Groupe::operator=(const Groupe &other) {
    clear();
    copy(other);
}

void Groupe::clear() {
    for (Personne * ptr : m_effectif){                                                  //parcours le vecteur de Personne m_effectif qui pointe sur des personnes
        delete (ptr);                                                                   //supprime la personne pointé par le pointeur
    }
    m_effectif.clear();                                                                 //supprime le pointeur
}

void Groupe::copy(const Groupe & other) {
    this->setIntitule(other.m_intitule);                                                  //copie l'intitulé du groupe
    for (Personne * ptr : other.m_effectif){
        this->addPersonne(ptr->getNom());
    }

}






