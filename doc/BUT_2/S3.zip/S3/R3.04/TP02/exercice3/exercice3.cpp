#include "ObjetContraint.h"
#include "Point.h"
#include <iostream>
using namespace std;

int main(int argc, char** argv) {

    // A COMPLETER : Testez ici le template ObjetContraint<T>

    return 0;
}

