#ifndef CONTENEUR_H
#define CONTENEUR_H

#include <vector>
#include <iostream>
#include <stdexcept>

template<class T>
class Conteneur {

// A COMPLETER : Spécifiez ici le template Conteneur<T>

};

// A COMPLETER : Implémentez ici les méthodes du template Conteneur<T> (pas de fichier .cpp pour un template)


#endif /* CONTENEUR_H */

