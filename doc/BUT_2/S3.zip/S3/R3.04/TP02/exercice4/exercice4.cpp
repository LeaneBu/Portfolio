#include "Conteneur.h"
#include <iostream>
#include <string>
#include <stdexcept>
using namespace std;

int main(int argc, char** argv) {

    // A COMPLETER : tester le template Conteneur<T>
    
    return 0;
}