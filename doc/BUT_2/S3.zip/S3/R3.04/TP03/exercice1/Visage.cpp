#include "Visage.h"
#include <iostream>
using namespace std;

// A COMPLETER : IMPLEMENTER LES METHODES DE LA CLASSE VISAGE (ET L'OPERATEUR <<)

Visage::Visage(int longueurNez, const Ethnie &uneEthnie): m_monNez(longueurNez), m_monEthnie(uneEthnie), m_monChapeau(
        nullptr), m_maMoustache(nullptr), m_mesBoutons(), m_mesBijoux(){
}

void Visage::setMoustache(int largeur) {
    if (m_maMoustache != nullptr){
        delete m_maMoustache;
    } else {
        this->m_maMoustache = new Moustache(largeur);
    }

}

void Visage::addBouton(int diametre) {
    m_mesBoutons.push_back(diametre);
}

void Visage::setChapeau(const Chapeau &unChapeau) {
    this->m_monChapeau = new Chapeau (unChapeau.getPoids());
}

void Visage::addBijou(const Bijou &unBijou) {
    m_mesBijoux.push_back(&unBijou);
}

const Visage &Visage::operator=(const Visage &unVisage) {
    if (this->m_maMoustache){                                                                               //CODE CLEAN
        delete m_maMoustache;
    }                                                                                                       //
    this->m_monNez=unVisage.m_monNez;                                                                       //CODE COPY
    this->m_monChapeau=unVisage.m_monChapeau;
    if (unVisage.m_maMoustache){
        this->setMoustache(unVisage.m_maMoustache->getLargeur());
    }
    this->m_mesBoutons=unVisage.m_mesBoutons;
    this->m_mesBijoux=unVisage.m_mesBijoux;                                                                 //
    //l'ethnie étant par reference on ne peut pas la modifier
}

Visage::Visage(const Visage &unVisage) : m_maMoustache(nullptr), m_monNez(unVisage.m_monNez.getLongueur()), m_monEthnie(
        unVisage.m_monEthnie), m_monChapeau(unVisage.m_monChapeau), m_mesBoutons(unVisage.m_mesBoutons), m_mesBijoux(unVisage.m_mesBijoux) {
    if (unVisage.m_maMoustache){
        this->setMoustache(unVisage.m_maMoustache->getLargeur());
    }
}

Visage::~Visage() {
    if (m_maMoustache != nullptr){
        delete m_maMoustache;
    }
}

std::ostream &operator<<(std::ostream &sortie, const Visage &visage) {
    sortie << "\n" << *(visage.m_monChapeau) << endl << visage.m_monNez << "\n" << visage.m_monEthnie;
    for (Bouton bouton : visage.m_mesBoutons){
        sortie << "\n" << bouton;
    }
    for (const Bijou *bijou: visage.m_mesBijoux){
        sortie << "\n" << *bijou;
    }
    if (visage.m_maMoustache ){
        sortie << "\n" << *(visage.m_maMoustache);
    }
    sortie << endl;
}