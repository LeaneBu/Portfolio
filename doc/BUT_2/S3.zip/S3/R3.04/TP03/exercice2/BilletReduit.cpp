#include <iostream>
#include "BilletReduit.h"
using namespace std;

// A COMPLETER
