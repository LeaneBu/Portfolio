#include <iostream>
#include "Element.h"

// à compléter

Element::Element(const std::string &nom, const Usager &proprio): m_nom(nom), m_proprio(&proprio) {

}

const std::string &Element::getNom() const {
    return this->m_nom;
}

void Element::setNom(const std::string &nom) {
    this->m_nom = nom;
}

const Usager & Element::getProprietaire() const {
    return *this->m_proprio;
}

void Element::setProprietaire(const Usager &proprietaire) {
    this->m_proprio = &proprietaire;
}

void Element::setDateModification(const std::string &date) {
    throw date;
}

void Element::afficher() const {
    std::cout << "Nom: " << getNom()
            << " - Proprietaire: " << &getProprietaire();
}

void Element::ajouter(Element *element) {
    throw element;
}

Element::~Element() {

}












