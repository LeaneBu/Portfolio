#ifndef ELEMENT_H
#define ELEMENT_H

#include <string>
#include "Usager.h"

class Element {
  // à compléter
public:
  Element(const std::string & nom, const Usager & proprio);

  const std::string &getNom() const;
  void setNom(const std::string & nom);
  const Usager & getProprietaire() const;
  void setProprietaire(const Usager & proprietaire);

  virtual unsigned int getTaille() const =0;                                                                //pure car on peut pas l'implémenter dans la classe mère (Element.cpp)
  virtual const std::string & getDateModification() const =0;
  virtual void setDateModification(const std::string & date);                                           //cette méthode n'est pas utilisable dans toutes les classes filles donc on ne la met pas pure pour l'implémenter et faire une levée d'exception
  virtual void afficher() const;                                                                        //const car quand t'affiche un truc tu modifies pas le truc
  virtual void ajouter(Element * element);

  virtual ~Element();

private:
    std::string m_nom;
    const Usager * m_proprio;

};

#endif /* ELEMENT_H */

