#include <iostream>
#include "Fichier.h"

// à compléter
Fichier::Fichier(const std::string &nom, const unsigned int &taille, const std::string &dateModif,  const Usager &proprio)
: Element(nom, proprio), m_dateModif(dateModif), m_taille(taille) {

}

unsigned int Fichier::getTaille() const {
    return this->m_taille;
}

const std::string &Fichier::getDateModification() const {
    return this->m_dateModif;
}

void Fichier::setDateModification(const std::string &date) {
    this->Element::setDateModification(date);
}

void Fichier::afficher() const {
    std::cout << "Fichier: ";
    this->Element::afficher();
    std::cout << " - Date de modification: " << getDateModification()
                << " - Taille: " << getTaille() << std::endl;
}

void Fichier::ajouter(Element *element) {
    throw "Pas possible sur un Fichier";
}

Fichier::~Fichier() {

}








