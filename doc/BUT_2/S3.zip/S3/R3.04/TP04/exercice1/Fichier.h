#ifndef FICHIER_H
#define FICHIER_H

#include "Element.h"

class Fichier : public Element {

    // à compléter
public:
    Fichier(const std::string &nom, const unsigned int &taille, const std::string &dateModif,  const Usager &proprio);
    unsigned int getTaille() const override;
    const std::string & getDateModification() const override;
    void setDateModification(const std::string &date) override;
    void afficher() const override;
    void ajouter(Element *element) override;

    virtual ~Fichier();

private:
    unsigned int m_taille;
    std::string m_dateModif;
};

#endif /* FICHIER_H */

