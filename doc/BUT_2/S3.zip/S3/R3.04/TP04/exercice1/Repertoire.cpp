#include <iostream>
#include "Repertoire.h"


// à compléter
const std::string Repertoire::DATE_DEFAUT = "1970-01-01";

Repertoire::Repertoire( const std::string &nom, const Usager &proprio)
: Element(nom, proprio), m_fichiers() {
}

unsigned int Repertoire::getTaille() const {
    unsigned int m_taille = 4;
    for (Element* fichier : m_fichiers) {
        m_taille += fichier->getTaille();
    }
    return m_taille;
}

const std::string & Repertoire::getDateModification() const {
    const std::string  * date_max = &DATE_DEFAUT; // date_max contient l'adresse de la plus grande date rencontrée
    for (Element* element : m_fichiers) {
         const std::string * date_elem = & (element->getDateModification()); // date_elem contient l'adresse de la date de l'élément courant
         if (*date_elem > *date_max){
             date_max = date_elem;
         }
    }
    return *date_max;
}

void Repertoire::setDateModification(const std::string &date) {
    this->Element::setDateModification(date);
}

void Repertoire::ajouter(Element *element) {
    this->m_fichiers.push_back(element);
}

void Repertoire::afficher() const {
    std::cout << "Répertoire: ";
    this->Element::afficher();
    std::cout << " - Date de modification: " << getDateModification()
                << " - Taille: " << getTaille() << std::endl;
}

Repertoire::~Repertoire() {
    for (Element* fichier : m_fichiers) {delete fichier;}
}







