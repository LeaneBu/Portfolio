#ifndef REPERTOIRE_H
#define REPERTOIRE_H

#include <vector>
#include "Element.h"

class Repertoire : public Element{

    // à compléter

public:
    Repertoire(const std::string &nom, const Usager &proprio);
    unsigned int getTaille() const override;
    const std::string & getDateModification() const override;
    void setDateModification(const std::string &date) override;
    void ajouter(Element *element) override;
    void afficher() const override;

    virtual ~Repertoire();

private:
    std::vector<Element *> m_fichiers;

    static const std::string DATE_DEFAUT;

};

#endif /* REPERTOIRE_H */

