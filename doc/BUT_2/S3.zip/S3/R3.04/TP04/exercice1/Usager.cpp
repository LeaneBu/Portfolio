#include "Usager.h"

// à compléter
Usager::Usager(const std::string &login, const std::string &groupe): m_groupe(groupe), m_login(login) {

}

const std::string &Usager::getLogin() const {
    return this->m_login;
}

const std::string &Usager::getGroupe() const {
    return this->m_groupe;
}

void Usager::setLogin(const std::string &login) {
    this->m_login = login;
}

void Usager::setGroupe(const std::string &groupe) {
    this->m_groupe = groupe;
}





