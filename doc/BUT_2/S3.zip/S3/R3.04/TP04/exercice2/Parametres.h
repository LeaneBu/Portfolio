#ifndef PARAMETRES_H
#define PARAMETRES_H
#include <string>
#include "Theme.h"
#include "Joueur.h"

class Parametres {

    // à compléter
    
};

#endif /* PARAMETRES_H */
