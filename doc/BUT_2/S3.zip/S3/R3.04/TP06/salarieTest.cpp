#include "gtest/gtest.h"
#include <map>
#include "Salarie.h"
#include <cctype>
#include<bits/stdc++.h>
#include "SalarieException.h"
using namespace std;

TEST(SalarieTest, Constructeur) {
    // A COMPLETER : tester Salarie::Salarie
}

TEST(SalarieTest, GetNom) {
    // A COMPLETER : test Salarie::getNom
    Salarie salarie;
    //Tester si getNom = le nom
    //Tester si nom est en majuscule
    string s = Salarie::NOM_DEF;
    transform(s.begin(), s.end(), s.begin(), ::toupper);
    EXPECT_EQ(salarie.getNom(),s) << "Vérifie que resultat=MARTIN si nom=Martin";
    Salarie salarie2("DUPONT");
    EXPECT_EQ(salarie2.getNom(),"DUPONT") << "Vérifie que resultat=DUPONT si nom=DUPONT";
    Salarie salarie3("DUPONT-durand");
    EXPECT_EQ(salarie3.getNom(),"DUPONT-DURAND") << "Vérifie que resultat=DUPONT-DURAND si nom=DUPONT-durand";
}

TEST(SalarieTest, SetNom) {
    // A COMPLETER : test Salarie::setNom
    //Tester si le nom pas vide
    //Tester si nom est un string
    Salarie salarie("John");
    EXPECT_NO_THROW(salarie.setNom("John")) << "Vérifie que le nom rentré est valide";
    EXPECT_NO_THROW(salarie.setNom("John-Connor")) << "Vérifie que le nom rentré avec le caractère \"-\" est valide";
    //EXPECT_NO_THROW(salarie.setNom("123")) << "Vérifie que le nom lève une exception car pas string";
    //EXPECT_NO_THROW(salarie.setNom("")) << "Vérifie que le nom lève une exception car nom vide";
    //EXPECT_THROW(salarie.setNom("John"), NomIncorrectException) << "Vérifie que le nom ne lève pas d'exception (nom valide)";
    EXPECT_THROW(salarie.setNom(""), NomIncorrectException) << "Vérifie que le nom lève une exception (nom vide)";
    EXPECT_THROW(salarie.setNom("123"), NomIncorrectException) << "Vérifie que le nom lève une exception (nom pas string)";
    EXPECT_THROW(salarie.setNom("-John"), NomIncorrectException) << "Vérifie que le nom lève une exception (nom commencant par un -)";
    EXPECT_THROW(salarie.setNom("John-"), NomIncorrectException) << "Vérifie que le nom lève une exception (nom terminant par un -)";
    EXPECT_THROW(salarie.setNom("6John"), NomIncorrectException) << "Vérifie que le nom lève une exception (nom commencant par un chiffre et non un caractère alphabétique)";
    EXPECT_THROW(salarie.setNom("John Connor"), NomIncorrectException) << "Vérifie que le nom rentré avec le caractère \" \" est invalide";

    //Tester si le nom est bien modifié
    Salarie salarie2;
    salarie2.setNom("Patate");
    EXPECT_EQ(salarie2.getNom(), "PATATE") << "Vérifie que le nom du salarié est modifié";

}

TEST(SalarieTest, SetNumeroSS) {
    // A COMPLETER : test Salarie::setNumeroSS
    Salarie salarie("John","1234567891234");
    EXPECT_NO_THROW(salarie.setNumeroSS("1112223334445")) << "Vérifie que le numeroSS rentré est valide";
    EXPECT_NO_THROW(salarie.setNumeroSS("2112223334445")) << "Vérifie que le numeroSS rentré est valide";
    EXPECT_THROW(salarie.setNumeroSS("123"), NumeroIncorrectException) << "Vérifie que le numeroSS rentré est de la bonne taille";
    EXPECT_THROW(salarie.setNumeroSS("0112223334445"), NumeroIncorrectException) << "Vérifie que le numeroSS rentré commence par 1 ou 2";
    EXPECT_THROW(salarie.setNumeroSS(""), NumeroIncorrectException) << "Vérifie que le numeroSS est pas vide";
    EXPECT_THROW(salarie.setNumeroSS("oui"), NumeroIncorrectException) << "Vérifie que le numeroSS est pas un string";
}

TEST(SalarieTest, SetSalaire) {
    // A COMPLETER : test Salarie::setSalaire
    Salarie salarie("John","1234567891234", 2000.0f);
    EXPECT_NO_THROW(salarie.setSalaireMensuel(2000.0f)) << "Vérifie que le salaire rentré est valide";
    EXPECT_NO_THROW(salarie.setSalaireMensuel(610500.0f)) << "Vérifie que le salaire rentré est valide";
    EXPECT_THROW(salarie.setSalaireMensuel(123), SalaireIncorrectException) << "Vérifie que le salaire rentré est au dessus du SMIC";
    EXPECT_THROW(salarie.setSalaireMensuel(700000), SalaireIncorrectException) << "Vérifie que le salaire rentré est en dessous de 500xSMIC";
}

TEST(SalarieTest, GetImpot) {
// A COMPLETER : tester Salarie::getImpot
}

