/*--------------------------------------------------------------------------
 * headers à inclure afin de pouvoir utiliser divers appels systèmes
 * -----------------------------------------------------------------------*/
#include <stdlib.h>	/* pour exit() et NULL*/
/* TODO--------- à compléter -----------TODO */

/*--------------------------------------------------------------------------
 * Fonction secondaire
 * -----------------------------------------------------------------------*/
static void executer_commande(char *arg[])
{
/* TODO--------- à remplacer -----------TODO */
(void)arg;
}

/*--------------------------------------------------------------------------
 * Fonction principale
 * -----------------------------------------------------------------------*/
int main(void)
{
  char *cmd1[]={"sl", "-F", NULL};

  executer_commande(cmd1) ;

  return EXIT_SUCCESS;
}
