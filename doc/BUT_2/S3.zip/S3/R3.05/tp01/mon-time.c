#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>

#define MILLION 1000000.0

int main(int argc, char* argv[])
{
  // on prend la mesure du temps avant le fork()
  // pour avoir des mesures plus stables
  // à compléter : déclaration de deux variables t1 et t2 de type struct timeval
  //               et 1ère mesure du temps dans t1

  // si une commande est passée en argument, on la fait exécuter par un fils
  if (argc>1)
  {
    // à compléter : création d'un processus fils et test d'échec

    // à corriger : test père/fils
    if (0==0)
    { // on est dans le fils
      // à remplacer : exécution de la commande passée en argument
      printf("exécution de %s\n", argv[1]);
    }
    else
    { // on est dans le père
      // à compléter : attente de la fin du fils et test d'échec
    }
  }

  // fin de la mesure du temps
  // à compléter : 2ème mesure du temps dans t2
  //               et calcul du temps écoulé
  double temps_ecoule = 0/MILLION;
  fprintf(stderr,"temps écoulé : %lf secondes\n", temps_ecoule);

  return EXIT_SUCCESS;
}
