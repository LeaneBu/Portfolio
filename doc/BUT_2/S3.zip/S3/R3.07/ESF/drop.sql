drop table inscrit;
drop table eleve;
drop table enseigne;
drop table moniteur;
drop table cours;
drop table typecours;

