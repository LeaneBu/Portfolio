TP1)
Exo 1:
1.
BEGIN;
INSERT INTO moniteur values (10,'lacroix','franck', 'courchevel', '0490584525');
SELECT * FROM moniteur WHERE nummono=10;
ROLLBACK;
SELECT * FROM moniteur WHERE nummono=10;

--> écrit la ligne dans la table puis annule et donc supprime la ligne complète

2.
BEGIN;
INSERT INTO moniteur values (10,'lacroix','franck', 'courchevel', '0490584525');
SELECT * FROM moniteur WHERE nummono=10;
COMMIT;
SELECT * FROM moniteur WHERE nummono=10;

--> écrit la ligne dans la table puis sauvgarde la ligne complète

Exo 2:
1.
BEGIN;
INSERT INTO moniteur values (null,'lapierre','éric', 'chamrousse', '0490584525');
SELECT * FROM moniteur;
COMMIT;
SELECT * FROM moniteur;

--> cette transaction évite les erreurs lorsque l'on rentre une nouvelle ligne ici elle empêche que le nummono soit null et que les numéro existent en 2 fois

BEGIN;
INSERT INTO eleve(nom, prenom, datenaissance, adressestation, mobile) values ( 'gigi', 'lebronze', '05/12/1971', 'sur le télésiège', '0789889988');
SELECT * FROM eleve;
INSERT INTO inscrit values ('gigi', 1);
COMMIT;
SELECT * FROM eleve;
SELECT * FROM inscrit;

--> évite les erreurs de type de valeur,, ici la valeur à rentrer est le numeleve de gigi et non pas son nom
