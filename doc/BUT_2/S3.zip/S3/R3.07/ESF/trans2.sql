--REMARQUE : En cas d'erreur dans une transaction, on ne peut plus rien y faire:
--on a toujours le message d'erreur suivant :
--	ERROR:  current transaction is aborted, commands ignored until end of transaction block
--Il faut donc finir par un ROLLBACK et recommencer

-- Les requetes sont a executer une par une
-- donc par des copier/coller et pas avec \i ....
-- dans l'ordre dans lequel elles sont indiquees
-- par l'utilisateur indique en commentaire

-- QUESTION 1-------------------------------------------------------------------
-- user1 fait des modifications validees, user2 des select
-- user1
begin;
    -- user2
    select * from COURS;
-- user1
insert into COURS values(12,'Le Centre',20,'26/12/2014','01/01/2015','14:30','16:30');
    -- user2
    select * from COURS;
-- user1
commit;
    -- user2
    select * from COURS;
-- RESULTAT : lecture non reproductible: lors de la lecture l'utilisateur2 observe un changement de valeur

-- QUESTION 2-------------------------------------------------------------------
-- user1 fait des modifications annulees, user2 des select
-- user1
begin;
    -- user2
    select * from COURS;
-- user1
insert into COURS values(13,'Le Centre',20,'01/01/2015','07/01/2015','14:30','16:30');
select * from COURS;
    -- user2
    select * from COURS;
-- user1
rollback;
    -- user2
    select * from COURS;
-- RESULTAT : tentative de modification par l'utilisateur1, abandon, et donc aucune modif dans la table du user2 

-- QUESTION 3-------------------------------------------------------------------
-- user1 et user2 insèrent des moniteurs différents (intercaler les requetes)
--user 1--
BEGIN; 
    --user 2--
    BEGIN;
    SELECT * FROM moniteur;
--user 1--
INSERT INTO moniteur values (11,'a','blblbl', 'prapoutel', '0666666666');
SELECT * FROM moniteur;
    --user 2--
    SELECT * FROM moniteur;
    INSERT INTO moniteur values (12,'b','mnmnmnmmnmn', 'chamrousse', '0655555555');
--user 1--
COMMIT;
    --user 2--
    COMMIT;

-- QU'OBSERVEZ-VOUS : les deux insertions se font sans problème


-- QUESTION 4-------------------------------------------------------------------
-- user1 et user2 insèrent le meme moniteur (intercaler les requetes) Cas ou user1 valide sa transaction
--user 1--
BEGIN; 
    --user 2--
    BEGIN;
    SELECT * FROM moniteur;
--user 1--
INSERT INTO moniteur values (11,'a','blblbl', 'prapoutel', '0666666666');
SELECT * FROM moniteur;
    --user 2--
    SELECT * FROM moniteur;
    INSERT INTO moniteur values (11,'a','blblbl', 'prapoutel', '0666666666');
--user 1--
COMMIT;
    --user 2--
    COMMIT;

-- QU'OBSERVEZ-VOUS : ça a tout cassé, la transaction s'arrête

-- user1 et user2 insèrent le meme moniteur (intercaler les requetes) Cas ou user1 annule sa transaction
--user 1--
BEGIN; 
    --user 2--
    BEGIN;
    SELECT * FROM moniteur;
--user 1--
INSERT INTO moniteur values (11,'a','blblbl', 'prapoutel', '0666666666');
SELECT * FROM moniteur;
    --user 2--
    SELECT * FROM moniteur;
--user 1--
ROLLBACK;
    --user 2--
    INSERT INTO moniteur values (11,'a','blblbl', 'prapoutel', '0666666666');
    COMMIT;

-- QU'OBSERVEZ-VOUS : cette fois-ci la transaction ne s'arrête pas et c'est la modification du user2 qui compte


-- QUESTION 5-------------------------------------------------------------------
-- user1 affecte les cours de JC Killy à Luc Alphand
--user2 les affecte a Marielle Goitschel 
--user1
begin;
    --user2
    begin;
--user1
update ENSEIGNE set nummono='2' where numcours=1;
    --user2
    update ENSEIGNE set nummono='4' where numcours = 11;
--user1
update ENSEIGNE set nummono='2' where numcours = 11;
    --user2
    update ENSEIGNE set nummono='4' where numcours=1 ;
-- QU'OBSERVEZ-VOUS ?
ERROR:  deadlock detected
--user1
commit;
    --user2
    commit; 

-- QU'OBSERVEZ-VOUS : le commit s'est transformé en rollback car à cause d'un interblockage la transaction s'est arrêté pour le user2

-- QUESTION 6-------------------------------------------------------------------
-- user1 lit les informations sur les cours du Centre, user2 les retarde
--user1
begin;
select * from COURS where lieurv= 'Le Centre';
--user2 
begin;
update COURS set heurefin = heurefin + interval '1 hours', heuredeb = heuredeb + interval '1 hours' where lieurv = 'Le Centre';
--user1
select * from COURS where lieurv = 'Le Centre';
-- QU'OBSERVEZ-VOUS ? les heures n'ont pas été modifiées
--user2 
commit;
--user1
select * from COURS where lieurv = 'Le Centre';
-- QU'OBSERVEZ-VOUS : ??? modification enregistrées
commit;

-- QUEL PROBLEME APPARAIT ICI ? POURQUOI ? lecture non reproductible car l'information donnée par le select se modifie entre temps
