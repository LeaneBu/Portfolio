TP01)
1.
CREATE TABLE compte (
numc numeric primary key,
nom varchar,
solde numeric
);

DROP TABLE compte;

2.
INSERT INTO compte values(1, 'Alice', 1000);
INSERT INTO compte values(2, 'Bob', 1000);

3.
--VERSION READ COMMITTED (defaut)
--user 1(Alice)--
BEGIN; 
    --user 2(Bob)--
    BEGIN;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = solde - 100.00 WHERE nom='Alice';
UPDATE compte SET solde = solde + 100.00 WHERE nom='Bob';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

--> la modification a lieu après le commit, il y a une différence entre les lectures

--------------------------------------------------------------
--VERSION REPEATABLE READ
--user 1(Alice)--
BEGIN;
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    --user 2(Bob)--
    BEGIN;
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = solde - 100.00 WHERE nom='Alice';
UPDATE compte SET solde = solde + 100.00 WHERE nom='Bob';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

-->Bob ne remarque aucun changement

--------------------------------------------------------------
--VERSION SERIALIZABLE
--user 1(Alice)--
BEGIN;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE ;
    --user 2(Bob)--
    BEGIN;
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = solde - 100.00 WHERE nom='Alice';
UPDATE compte SET solde = solde + 100.00 WHERE nom='Bob';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

-->Bob ne remarque aucun changement

4.
--VERSION READ COMMITTED (defaut)
--user 1(Alice)--
BEGIN; 
    --user 2(Bob)--
    BEGIN;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = 4000 WHERE nom='Alice';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
    UPDATE compte SET solde = 5000 WHERE nom='Alice';
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

--> Bob ne peut pas modifier en même temps que Alice => bloquage

--------------------------------------------------------------
--VERSION REPEATABLE READ
--user 1(Alice)--
BEGIN;
SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    --user 2(Bob)--
    BEGIN;
    SET TRANSACTION ISOLATION LEVEL REPEATABLE READ;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = 4000 WHERE nom='Alice';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
    UPDATE compte SET solde = 5000 WHERE nom='Alice';
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

--> Bob ne peut pas modifier en même temps que Alice => bloquage

--------------------------------------------------------------
--VERSION SERIALIZABLE
--user 1(Alice)--
BEGIN;
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE ;
    --user 2(Bob)--
    BEGIN;
    SET TRANSACTION ISOLATION LEVEL SERIALIZABLE;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = 4000 WHERE nom='Alice';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
    UPDATE compte SET solde = 5000 WHERE nom='Alice';
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

-->bloquage

5.
Non il n est pas résolu avec le mode sérializable (code question précédente);

6.
UPDATE compte SET solde = 2000 WHERE numc=1;
UPDATE compte SET solde = 1000 WHERE numc=2;

--VERSION READ COMMITTED (defaut)
--user 1(Alice)--
BEGIN; 
    --user 2(Bob)--
    BEGIN;
    SELECT * FROM compte;
--user 1--
UPDATE compte SET solde = solde + (SELECT solde FROM compte WHERE numc=2) WHERE nom='Alice';
SELECT * FROM compte;
    --user 2--
    SELECT * FROM compte;
    UPDATE compte SET solde = 100 WHERE nom='Bob';
    UPDATE compte SET solde = solde + (SELECT solde FROM compte WHERE numc=1)  WHERE nom='Bob';
--user 1--
COMMIT;
    --user 2--
    SELECT * FROM compte;
    COMMIT;

--> 

