# Mettre en place le projet :

## Godot
Tout d'abord, il faut télécharger [Godot](https://godotengine.org/) sur le site officiel.  
Ce projet utilise la vertsion 4.2.1  
  
Une fois dans Godot, vous pouver ouvrir le projet et le lancer avec F5

## Communication API et multijoueur
### API WEB
L'appliaction utilise notre API web, qui est sur la VM 192.168.14.130, il faut donc pouvoir la joindre.  
L'API est utilie pour pouvoir interagire avec la BDD, et notemment pour se connecter.  

Le multijoueur n'est pas fonctionnelle. Cependant, d'après ce qui avait été prévu, il aurait juste fallut pouvoir joindre le serveur (qui le serveur web) sur le port 6669  
Le service de multijoueur sur le serveur est disponible sur la page "serveur" du Gitlab  
