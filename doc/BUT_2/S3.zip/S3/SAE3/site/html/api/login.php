<?php

include __DIR__ . "/../../utils/api.php";

if ($_SERVER['REQUEST_METHOD'] != "POST") {
	send('{"message": "Invalid request login use POST instead"}', 400);
}

if (!isset($_POST["mail"]) || !isset($_POST["password"]) || !isset($_POST["type"])) {
	send('{"message": "missing argument"}', 400);
}

if ($_POST["type"] != "godot" && $_POST["type"] != "web") {
	send('{"message": "invalid type value"}', 400);
}

include __DIR__ . "/../../utils/DAO.php";
include __DIR__ . "/../../utils/password.php";

try {
	$dao = DAO::get();
	$query = $dao->query('SELECT id, name, firstname, password, salt, accountstate FROM users WHERE mail = ?', [$_POST["mail"]]);
} catch (\Throwable $th) {
	send('{"message": "DataBase not found"}', 500);
}

if (sizeof($query) == 0 || !passwordCkeck($_POST["password"], $query[0]["salt"], PEPPER, $query[0]["password"])) {
	send('{"message": "wrong account credential"}', 403);
}

$query = $query[0];

if ($query["accountstate"] == "delete") {
	$dao->query("UPDATE public.users SET accountstate = 'active' changestatedate = now() WHERE id = ?", [$query["id"]]);
}

switch ($_POST["type"]) {
	case 'godot':
		$token = randomStringGenerator(30);
		$dao->query("INSERT INTO \"session\" (token, userid) VALUES (?, ?)", [$token, $query["id"]]);
		$data = [
			"token" => $token,
			"firstname" => $query["firstname"],
			"name" => $query["name"],
		];
		send(json_encode($data));
		break;

	case 'web':
		$_SESSION["id"] = $query["id"];
		$_SESSION["mail"] = $query["mail"];
		$_SESSION["name"] = $query["name"];
		$_SESSION["firstname"] = $query["firstname"];
		send('{"message": "connected"}');
		break;
}
