<?php

session_start();

// TODO: loggin system to implement
if ($_POST['email'] == 'e@e' && $_POST['mdp'] == 'e') {
	$_SESSION["email"] = $_POST['email']; // FIXME: quand on utiliseras la BDD on utiliseras les donner compris dans la BDD
}

if (isset($_SESSION['email'])) {
	http_response_code("301");
	header("Location: /");
}

?>


<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="asset/css/style.css">
	<link rel="stylesheet" href="asset/css/nerd-fonts-generated.min.css">
	<title>Anatomic Mission</title>
</head>

<body>
	<header id="navForm">
		<a href="index.php"><i class="nf nf-oct-arrow_left"></i> back</a>
	</header>

	<main id="mainFormulaire">

		<form action="connexion.php" method="post" id="formulaireConnexion" class="formulaire">
			<h2>Connexion</h2>
			<?php
			if (isset($error)) {
				echo ('<p class="error">Identifiant ou mot de passe incorrect</p>');
			}
			?>
			<label for="email">E-mail :</label>
			<input required type="email" name="email" id="email" value=<?= $email ?>>

			<label for="mdp">Mot de passe :</label>
			<input required type="password" name="mdp" id="mdp">

			<button type="submit" id="btnConnexion" disabled>Connexion</button>
		</form>
		<p>Pas de compte ?</p>
		<a href="inscrire.php">Créer un compte</a>
	</main>
</body>

<script type="text/javascript">
	function lockUnlockConnexion() {
		const form = document.querySelector("#formulaireConnexion");
		if (form.checkValidity()) {
			document.querySelector("#btnConnexion").disabled = false;
		} else {
			document.querySelector("#btnConnexion").disabled = true;
		}
	}

	document.querySelector("#formulaireConnexion").addEventListener("input", lockUnlockConnexion);
</script>

</html>
