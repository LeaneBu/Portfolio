<?php

session_start();



http_response_code("301");
header("Location: /");
