<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="asset/css/style.css">
	<link rel="stylesheet" href="asset/css/nerd-fonts-generated.min.css">
	<title>Anatomic Mission</title>
</head>

<body>
	<?php
	include("../template/navBar.php");
	?>

	<main>
		<div id="heroImage"></div>
		<h1>Anatomic Mission</h1>
		<article class="paragraphe">
			<h2>Comment l'utiliser ?</h2>
			<p>Pour commencer il vous faudra un compte utilisateur, celui-ci créera un profil à votre image comortant vos scores.
				Dépassez vos limites et avancez en SVT en améliorant progressivement vos scores.</p>
		</article>
	</main>

	<?php
	include("../template/footer.html");
	?>
</body>

</html>
