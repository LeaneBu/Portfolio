<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="asset/css/style.css">
	<link rel="stylesheet" href="asset/css/nerd-fonts-generated.min.css">
	<title>Anatomic Mission</title>
</head>

<body>

	<?php
	include("../template/navBar.php");
	?>

	<main>
		<div id="heroImage"></div>
		<h1>Anatomic Mission</h1>
		<article class="paragraphe">
			<h2>Qu'est-ce que "Anatomic Mission" ?</h2>
			<section>
				<p> Le jeu "Anatomic Mission" est un jeu collaboratif où une équipe est chargée de mener à bien différentes
					missions pour maintenir un haut niveau de fonctionnement du corps humain. Les joueurs évoluent sur une carte
					à la forme humanoïde, et où les divers organes du corps sont dispersés. Les missions consistent en des tâches
					spécifiques liées au fonctionnement des organes et systèmes du corps.</p>
				<div id="illustration">
					<img src="./asset/img/heart.png" alt="imgMap?">
				</div>
			</section>
			<section>
				<p> Des événements dynamiques extérieurs viendront périodiquement modifier le fonctionnement global du corps. Ainsi, chacun
					des joueurs se voit assigné une liste de tâches au début de la partie, tâches qui doivent être
					accomplies parallèlement à la gestion d’événements ponctuels, évènements qui doivent être gérés en un temp
					imparti, sous peine de faire diminuer la barre de vie du corps humain. L’épuisement de cette barre avant l’accom-
					plissement de toutes les tâches conduit à la défaite, tandis que la victoire est acquise si les joueurs parviennent
					à relever ces défis dans les délais impartis.</p>
				<div id="illustration">
					<img src="./asset/img/bulbul.png" alt="imgTask?">
				</div>
			</section>

		</article>
		<section>
			<h2 id="majSTP">Télécharger</h2>
			<div>
				<a href="jeu.zip" download class="button btnDownload">
					<span class="button-content"><i class="nf nf-md-download"></i> Télécharger pour Linux </span>
				</a>
				<a href="jeu.zip" download class="button btnDownload">
					<span class="button-content"><i class="nf nf-md-download"></i> Télécharger pour Windows </span>
				</a>
			</div>
			<a href="help.php" class="button btnTuto">
				<span class="button-content"> Comment l'utiliser ? </span>
			</a>
		</section>
	</main>

	<?php
	include("../template/footer.html");
	?>
</body>

</html>
