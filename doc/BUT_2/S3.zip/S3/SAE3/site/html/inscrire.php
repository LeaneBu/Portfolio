<!DOCTYPE html>
<html lang="fr">

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="asset/css/style.css">
	<link rel="stylesheet" href="asset/css/nerd-fonts-generated.min.css">
	<title>Anatomic Mission</title>
</head>

<body id="bodyInscription">
	<header id="navForm">
		<a href="index.php"> <i class="nf nf-oct-arrow_left"></i> back</a>
	</header>

	<main id="mainFormulaire">

		<form action="connexion.php" method="post" id="formulaireInscription" class="formulaire">


			<h2>Inscription</h2>
			<section id="etape1" class="inscriEtape">
				<!-- Étape 1 -->
				<label for="email">Email : <span class="redStar">*</span></label>
				<input required type="email" name="email" id="email">

				<label for="name">Nom : <span class="redStar">*</span></label>
				<input required type="text" name="name" id="name">

				<label for="firstname">Prénom : <span class="redStar">*</span></label>
				<input required type="text" name="firstname" id="firstname">

				<label for="birth">Date de naissance : <span class="redStar">*</span></label>
				<input required type="date" name="birth" id="birth">
			</section>



			<section id="etape2" class="inscriEtape hidden">
				<!-- Étape 2 -->

				<!-- <13ans = Mettre fond en rouge-->
				<h3 id="tropJeune">Trop jeune !!!!! Grandit un peut et reviens.</h3>

				<!-- >13ans && <16ans -->
				<div id="entre13et16">
					<label for="tutorName">Nom du tuteur légal <span class="redStar">*</span></label>
					<input required type="text" id="tutorName">

					<label for="tutorSurame">Prénom du tuteur légal <span class="redStar">*</span></label>
					<input required type="text" id="tutorSurame">

					<span class="formSpan">
						<input required type="checkbox" id="parentalAuthorisation">
						<label for="parentalAuthorisation">Autorisation parentale <span class="redStar">*</span></label>
					</span>
				</div>


				<!-- >18ans -->
				<span class="formSpan" id="majeur">
					<input type="checkbox" id="prof">
					<label for="prof">Compte prof</label>
				</span>
			</section>

			<section id="etape3" class="inscriEtape hidden">
				<!-- Étape 3 -->
				<span class="formSpan">
					<input type="checkbox" id="conditions">
					<label required for="conditions">conditions d'utilisation<span class="redStar">*</span></label>
				</span>
			</section>



			<section id="etape4" class="inscriEtape hidden">
				<!-- Étape 4 -->

				<label for="mdp">Mot de passe : <span class="redStar">*</span></label>
				<input required type="password" id="mdp">

				<label for="mdp">Confirmer le mot de passe : <span class="redStar">*</span></label>
				<input required type="password" id="mdpconfirm">

				<label for="lierCompte">Lier compte dans une classe</label>
				<input type="text" id="lierCompte">
			</section>

			<button id="btnInscrire" type="submit" disabled="">S'inscrire</button>
		</form>
	</main>
</body>
<script type="text/javascript">
	function lockUnlockInscrire() {
		const form = document.querySelector("#formulaireInscription");
		if (form.checkValidity() && inscriptionForm.inputMdp.value == inscriptionForm.inputMdpConfirm.value && inscriptionForm.checkboxConditions.checked) {
			inscriptionForm.btnInscrire.disabled = false;
		} else {
			inscriptionForm.btnInscrire.disabled = true;
		}
	}



	function etape2() {
		const inputs = document.querySelector("#etape1").querySelectorAll("input");
		for (const obj of inputs) {
			if (!obj.checkValidity()) {
				document.querySelector("#etape2").style.display = "none";

				document.querySelector("#etape3").style.display = "none";
				return;
			}
		}
		document.querySelector("#etape2").style.display = "block";
		ageSelect();

	}

	function etape4() {
		const inputs = document.querySelector("#etape3").querySelectorAll("input");
		const cb = document.querySelector("#etape4").querySelector("input");
		for (const obj of inputs) {
			if (!obj.checkValidity() && !cb.checked) {
				document.querySelector("#etape4").style.display = "none";
				return;
			}
		}
		document.querySelector("#etape4").style.display = "block";

	}

	function activerDesactiverRequired(activate) {
		if (activate) {
			document.querySelector("#tutorName").setAttribute("required", true);
			document.querySelector("#tutorSurame").setAttribute("required", true);
			document.querySelector("#parentalAuthorisation").setAttribute("required", true);
		} else {
			document.querySelector("#tutorName").removeAttribute("required");
			document.querySelector("#tutorSurame").removeAttribute("required");
			document.querySelector("#parentalAuthorisation").removeAttribute("required");
		}
	}

	function ageSelect() {
		const naissance = document.querySelector("#birth").value;
		age = new Date(new Date(Date.now()) - new Date(naissance)).getFullYear() - 1970;
		const errorMessage = document.querySelector("#tropJeune");
		const entre13et16 = document.querySelector("#entre13et16");
		const majeur = document.querySelector("#majeur");

		errorMessage.style.display = "none";
		entre13et16.style.display = "none";
		majeur.style.display = "none";
		document.querySelector("#etape3").style.display = "block";

		console.log(age);

		if (age < 13) {
			activerDesactiverRequired(false);
			errorMessage.style.display = "block";
			document.querySelector("#etape3").style.display = "none";
		} else if (age >= 18) {
			activerDesactiverRequired(false);
			majeur.style.display = "block";
		} else if (age >= 13 && age < 16) {
			activerDesactiverRequired(true);
			entre13et16.style.display = "block";
		} else {
			activerDesactiverRequired(false);
		}
	}

	function recharge() {
		document.querySelector("#formulaireInscription").reset();
	}

	let inscriptionForm = {
		inputEmail: document.querySelector('#email'),
		inputUsername: document.querySelector('#username'),

		inputMdp: document.querySelector('#mdp'),
		inputMdpConfirm: document.querySelector('#mdpconfirm'),

		inputBirth: document.querySelector('#birth'),

		checkboxConditions: document.querySelector('#conditions'),
		btnInscrire: document.querySelector('#btnInscrire'),
	}

	recharge();
	document.querySelector("#etape1").addEventListener("input", etape2);
	document.querySelector("#etape2").addEventListener("input", etape4);
	document.querySelector("#etape3").addEventListener("input", etape4);
	document.querySelector("#etape4").addEventListener("input", lockUnlockInscrire);
</script>

</html>
