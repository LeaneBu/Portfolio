<?php

session_start();

include "../needConnected.php";

$nom = $_SESSION['nom'] ?? "N/A";
$email = $_SESSION['email'] ?? "N/A";

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<link rel="stylesheet" href="asset/css/style.css">
	<link rel="stylesheet" href="asset/css/nerd-fonts-generated.min.css">
	<title>Anatomic Mission</title>
</head>

<body>
	<?php
	include("../template/navBar.php");
	?>

	<main>
		<section id="sectionProfil">
			<button id="modifProfil">Modifier</button>
			<div id="avatar"></div>
			<h3> Nom d'utilisateur </h3>
			<label id="username"><?= $nom ?></label>
			<input type="text" placeholder="<?= $nom ?>">
			<h3>Email</h3>
			<label id="mail"><?= $email ?></label>
			<input type="text" placeholder="<?= $email ?>">

		</section>
		<section id="sectionScore">
			<h2>Statistiques personelles</h2>
			<table>
				<thead>
					<tr>
						<th colspan="1">Nom task</th>
						<th colspan="1">Nb try</th>
						<th colspan="1">Nb success</th>
						<th colspan="1">Nb loose</th>
						<th colspan="1">Moyenne réussite</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Réflechir</td>
						<td>50</td>
						<td>23</td>
						<td>27</td>
						<td>46%</td>
					</tr>
					<tr>
						<td>Réflechir</td>
						<td>50</td>
						<td>23</td>
						<td>27</td>
						<td>46%</td>
					</tr>
				</tbody>
			</table>
		</section>
	</main>

	<?php
	include("../template/footer.html");
	?>

</body>

<script type="text/javascript">
	function onBtnModif(){
		const labels = document.querySelectorAll("label");
		const tfs = document.querySelectorAll("input");
		const btn = document.querySelector("#modifProfil");
		for (const label of labels){
			if (label.style.display == "block") {
				label.style.display="none";
			} else {
				label.style.display="block";
			}
			
		}
		for (const tf of tfs){
			if (tf.style.display == "none") {
				tf.style.display="block";
			} else {
				tf.style.display="none";
			}

			
		}
		if (btn.textContent == "Modifier") {
			btn.textContent = "Valider";
		} else {
			btn.textContent = "Modifier";
		}

	}

	document.querySelector("#modifProfil").addEnventListener("click", onBtnModif);
</script>

</html>
