<?php

if (!isset($_SESSION['email'])) {
	http_response_code("301");
	header("Location: /");
}
