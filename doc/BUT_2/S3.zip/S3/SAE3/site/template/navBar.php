<?php
session_start();
?>

<header>
	<!-- TODO: trouver un vrais logo: header -->
	<a href="index.php"><img src="./asset/img/logo v2.png" alt="LOGO"></a>
	<input type="checkbox" id="menu">
	<script>
		function resetBox() {
			document.querySelector("#menu").checked = false;
		}

		resetBox();
		window.addEventListener('scroll', resetBox);
	</script>
	<nav>
		<a href="index.php" class="navBtn">Télécharger</a>

		<?php
		if (isset($_SESSION['email'])) {
		?>
			<a href="deconnected.php" class="navBtn">Déconnexion</a>
			<a href="profil.php" class="navBtn"> <i class="nf nf-fa-user_circle_o"></i></a>
		<?php
		} else {
		?>
			<a href="inscrire.php" class="navBtn">S'inscrire</a>
			<a href="connexion.php" class="navBtn">Se connecter</a>
		<?php
		}
		?>

	</nav>
	<label for="menu" class="hamburger"><span><i class="nf nf-md-menu"></i></span></label>
</header>
