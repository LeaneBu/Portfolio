<?php
include __DIR__ . "/test.php";
include __DIR__ . "/../utils/DAO.php";

try {
	$dao = DAO::get();
	test(true, "Open DAO");
} catch (\Throwable $th) {
	testAssert(false, "Open DAO -> " . $th);
}

$dao2 = DAO::get();
test($dao == $dao2, "DAO class give same DAO");

exit($error);
