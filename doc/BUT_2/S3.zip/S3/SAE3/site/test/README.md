# Test system
system pour faire des teste PHP

# Utilisation

Crée un fichier qui ce nomme `NOM_DU_GROUPE_DE_TESTE.test.php` qui inclue le fichier `test.php`
```php
include __DIR__ . "/test.php";
```

faite vos teste puis quité votre programe avec :
```php
exit($error);
```

# Docs
## `test()`
```php
function test(
	$boolean, // resultat d'un teste
	$message  // message a afficher
): void
```
Affiche un message commanssant par `UwU` si le test a reussi et `ÒwÓ` s'il a echouer

## `testAssert()`
```php
function testAssert(
	$boolean, // resultat d'un teste
	$message  // message a afficher
): void
```
Affiche un message commanssant par `UwU` si le test a reussi.

Si le teste a echouer il affiche `ÒwÓ` et renvoie une erreur
