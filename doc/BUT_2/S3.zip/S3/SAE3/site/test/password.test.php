<?php
include __DIR__ . "/test.php";
include __DIR__ . "/../utils/password.php";

test(
	passwordHash("1234", "salt", "pepper") == "a95e25eb2b97dd5e35136ebaae1b70127ec64971a70803586a5475f844ee74f20d15ae96e5bcbdbb510affaef2c063eb0a095426850b17b2542d64761471b334",
	"passwordHash(): password 1234 with salt salt and pepper pepper"
);

test(
	passwordHash("4321", "tlas", "reppep") == "6d33b43b9ffd67bf5f22cf9fb9af8841fc95ff5bcf2736359a001e1cb9933f4fa4b45903128292442af9ab011055ef038a459366e2a3f27b899fa89dc3dcd99b",
	"passwordHash(): password 4321 with tlas salt and reppep pepper"
);

test(
	passwordCkeck("1234", "salt", "pepper", "a95e25eb2b97dd5e35136ebaae1b70127ec64971a70803586a5475f844ee74f20d15ae96e5bcbdbb510affaef2c063eb0a095426850b17b2542d64761471b334"),
	"passwordCkeck(): password 1234 is good"
);

test(
	!passwordCkeck("4321", "salt", "pepper", "a95e25eb2b97dd5e35136ebaae1b70127ec64971a70803586a5475f844ee74f20d15ae96e5bcbdbb510affaef2c063eb0a095426850b17b2542d64761471b334"),
	"passwordCkeck(): password 4321 is not good"
);

exit($error);
