#!/usr/bin/env bash

die() {
	echo -e "\e[31;1mCRITIC:\e[m $*"
	exit 1
}

pushd "$(dirname "$0")" >/dev/null 2>&1 || die "Impossible d'allez dans le dossier $(dirname "$0")"

VERBOSE="yes"
if [ "$1" == "--quiet" ] || [ "$1" == "-q" ]; then
	VERBOSE="no"
fi

for f in *.test.php; do
	echo -e "\e[35;1m==>\e[0;1m Start test \e[34m${f%%.test.php}\e[m"

	if [ "$VERBOSE" == "yes" ]; then
		php "$f"
	else
		php "$f" >/dev/null
	fi

	# shellcheck disable=SC2181
	if [ $? -eq 0 ]; then
		echo -e "\e[32;1m ->\e[0;1m All test in \e[34m${f%%.test.php}\e[0;1m succeded! \e[33m>w<\e[m"
	else
		echo -e "\e[31;1m ->\e[0;1m some test in \e[34m${f%%.test.php}\e[0;1m failed! \e[31mÒwÓ\e[m" >&2
	fi
done
