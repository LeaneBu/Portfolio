<?php

$error = 0;

/**
 * afiche un message appret l'execution d'un teste et definit la valeur $error en fonction
 * 
 * @param bool $boolean resultat du teste
 * @param string $message message a afficher
 */
function test($boolean, $message): void {
	if ($boolean) {
		fprintf(STDOUT, "\e[32;1mUwU\e[m %s\n", $message);
	} else {
		fprintf(STDERR, "\e[31;1mÒwÓ\e[m %s\n", $message);
		global $error;
		$error = 1;
	}
}

/**
 * afiche un message appret l'execution d'un teste et definit la valeur $error en fonction
 * 
 * @param bool $boolean resultat du teste
 * @param string $message message a afficher
 * @throws Error si le test echoue
 */
function testAssert($boolean, $message): void {
	test($boolean, $message);
	if (!$boolean) {
		throw new Error($message);
	}
}
