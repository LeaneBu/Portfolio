<?php
include __DIR__ . "/test.php";

$exit_error = 0;

test(true, "must succed");
if ($error == 0) {
	printf("\e[32mvariable \$error corectement definie\e[m\n");
} else {
	printf("\e[31mvariable \$error incorecte\e[m\n");
	$exit_error = 1;
}

test(false, "must failed");
if ($error == 1) {
	printf("\e[32mvariable \$error corectement definie\e[m\n");
} else {
	printf("\e[31mvariable \$error incorecte\e[m\n");
	$exit_error = 1;
}

test(true, "must succed");
if ($error == 1) {
	printf("\e[32mvariable \$error corectement definie\e[m\n");
} else {
	printf("\e[31mvariable \$error incorecte\e[m\n");
	$exit_error = 1;
}

$error = 0;

try {
	testAssert(true, "must succed");
	if ($error == 0) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
		$exit_error = 1;
	}
} catch (\Throwable $th) {
	printf("\e[31mUne erreur a été throw ce qui n'est pas normal\e[m\n");
	if ($error == 0) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
	}
	$exit_error = 1;
}

try {
	testAssert(false, "must failed and crash");
	printf("\e[31mUne erreur n'a pas été throw ce qui n'est pas normal\e[m\n");
	$exit_error = 1;
	if ($error == 1) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
	}
} catch (\Throwable $th) {
	if ($error == 1) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
	}
}

try {
	testAssert(true, "must succed");
	if ($error == 1) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
		$exit_error = 1;
	}
} catch (\Throwable $th) {
	printf("\e[31mUne erreur a été throw ce qui n'est pas normal\e[m\n");
	if ($error == 1) {
		printf("\e[32mvariable \$error corectement definie\e[m\n");
	} else {
		printf("\e[31mvariable \$error incorecte\e[m\n");
	}
	$exit_error = 1;
}

exit($exit_error);
