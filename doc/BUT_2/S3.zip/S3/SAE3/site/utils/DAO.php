<?php
include __DIR__ . "/../config.php";

class DAO {
	private static $instance = null;
	private PDO $db;

	private string $database = 'pgsql:host=' . DB_CONFIG["IP"] . ";port=" . DB_CONFIG["PORT"] . ";dbname=" . DB_CONFIG["database"] . ";user=" . DB_CONFIG["username"] . ";password=" . DB_CONFIG["password"];

	private function __construct() {
		try {
			$this->db = new PDO($this->database);
			if (!$this->db) {
				throw new Exception("Impossible d'ouvrir " . $this->database);
			}
			$this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch (PDOException $e) {
			throw new PDOException(__METHOD__ . " at " . __LINE__ . ": " . $e->getMessage() . " DataBase=\"" . $this->database . '"');
		}
	}

	public static function get(): DAO {
		if (is_null(self::$instance)) {
			self::$instance = new DAO();
		}
		return self::$instance;
	}

	public function query(string $query, array $data): array {
		try {
			$s = $this->db->prepare($query);
			$s->execute($data);
		} catch (Exception $e) {
			throw new PDOException(__METHOD__ . " at " . __LINE__ . ": " . $e->getMessage() . " Query=\"" . $query . '"');
		}

		if ($s === false) {
			throw new PDOException(__METHOD__ . " at " . __LINE__ . ": " . implode('|', $this->db->errorInfo()) . " Query=\"" . $query . '"');
		}
		$table = $s->fetchAll();
		return $table;
	}
}
