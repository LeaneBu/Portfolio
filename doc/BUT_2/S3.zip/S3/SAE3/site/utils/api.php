<?php
header("Content-Type: application/json; charset: utf-8");

if (!isset($_SERVER['HTTPS'])) {
	send('{"message": "You must use HTTPS"}', 400);
}

function send($body, $code = 200): void {
	http_response_code($code);
	print($body);
	exit();
}
