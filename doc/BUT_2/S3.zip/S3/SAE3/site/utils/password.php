<?php

function passwordHash($password, $salt, $pepper) {
	return hash("sha512", $salt . $password . $pepper);
}

function passwordCkeck($password, $salt, $pepper, $hash) {
	return passwordHash($password, $salt, $pepper) == $hash;
}

function randomStringGenerator($lenght = 50) {
	$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!#%&()*+,-./:;<=>?@[]^_`{}|~';
	$randomString = '';
	for ($i = 0; $i < $lenght; $i++) {
		$randomString .= $characters[random_int(0, strlen($characters) - 1)];
	}
	return $randomString;
}
