package fr.iut2.saeprojet;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import fr.iut2.saeprojet.api.APIClient;
import fr.iut2.saeprojet.api.APIService;
import fr.iut2.saeprojet.api.ResultatAppel;
import fr.iut2.saeprojet.entity.Candidature;
import fr.iut2.saeprojet.entity.CandidaturesResponse;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListCandidaturesActivity extends StageAppActivity {
    // View
    private TextView retourSyntheseView;
    private ListView candidaturesView;
    private ListView candidaturesRefuseesView;

    private ArrayList<Candidature> candidatures = new ArrayList<>();

    // data
    private CandidatureAdapter adapter;
    private CandidatureAdapter adapterNO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_candidatures);

        // Init view
        retourSyntheseView = findViewById(R.id.retourSynthese);
        candidaturesView = findViewById(R.id.candidatures);
        candidaturesRefuseesView =  findViewById(R.id.refusees);

        // Lier l'adapter au listView
/*
        adapter = new CandidatureAdapter(this, candidatures);
        candidaturesView.setAdapter(adapter);
        adapterNO = new CandidatureAdapter(this, candidatures);
        candidaturesRefuseesView.setAdapter(adapterNO);
*/

        //
        retourSyntheseView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        candidaturesView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                // Récupération de la tâche cliquée à l'aide de l'adapter
                Candidature candidature = adapter.getItem(position);


                //
                Intent intent = new Intent(ListCandidaturesActivity.this, CandidatureActivity.class);
                intent.putExtra(CandidatureActivity.CANDIDADURE_KEY, candidature);
                startActivity(intent);
            }
        });
        candidaturesRefuseesView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Candidature refus = adapterNO.getItem(position);

                Intent intent = new Intent(ListCandidaturesActivity.this, CandidatureActivity.class);
                intent.putExtra(CandidatureActivity.CANDIDADURE_KEY, refus);
                startActivity(intent);
            }
        });

        //
        refreshMesInformations();
    }

    private void refreshMesInformations() {
        APIClient.getCandidatures(this, new ResultatAppel<CandidaturesResponse>() {
            @Override
            public void traiterResultat(CandidaturesResponse candidatures) {


                // Mettre à jour l'adapter avec la liste de taches
                ArrayList<Candidature> lcEC = new ArrayList<>();
                ArrayList<Candidature> lcNO = new ArrayList<>();
                for (Candidature candidature : candidatures.candidatures){
                    if (candidature.etatCandidature.compareTo("/api/etat_candidatures/3") == 0){
                        lcNO.add(candidature);
                    } else if (candidature.etatCandidature.compareTo("/api/etat_candidatures/3") != 0) {
                        lcEC.add(candidature);
                    }
                }



                adapterNO = new CandidatureAdapter(ListCandidaturesActivity.this, lcNO);
                candidaturesRefuseesView.setAdapter(adapterNO);
//                adapterNO.clear();
//                adapterNO.addAll(lcNO);

                adapter = new CandidatureAdapter(ListCandidaturesActivity.this, lcEC);
                candidaturesView.setAdapter(adapter);
//                adapter.clear();
//                adapter.addAll(lcEC);

                // Now, notify the adapter of the change in source
                adapter.notifyDataSetChanged();
                adapterNO.notifyDataSetChanged();
            }

            @Override
            public void traiterErreur() {

            }
        });
    }
}