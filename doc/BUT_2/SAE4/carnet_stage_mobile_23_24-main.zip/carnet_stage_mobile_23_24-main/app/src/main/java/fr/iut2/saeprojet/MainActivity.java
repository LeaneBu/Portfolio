package fr.iut2.saeprojet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

import fr.iut2.saeprojet.api.APIClient;
import fr.iut2.saeprojet.api.ResultatAppel;
import fr.iut2.saeprojet.entity.Candidature;
import fr.iut2.saeprojet.entity.CandidaturesResponse;
import fr.iut2.saeprojet.entity.CompteEtudiant;
import fr.iut2.saeprojet.entity.CompteEtudiantRequete;
import fr.iut2.saeprojet.entity.OffresResponse;

public class MainActivity extends StageAppActivity {

    // View
    private LinearLayout offresView;
    private LinearLayout candidaturesView;

    private LinearLayout offreView;
    private Button deconnexion;
    private StageAppActivity act = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // init View
        offresView = findViewById(R.id.offres);
        candidaturesView = findViewById(R.id.candidatures);
        deconnexion = findViewById(R.id.deconnexion);

        //
        offresView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListOffresActivity.class);
                startActivity(intent);
            }
        });

        deconnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        candidaturesView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, ListCandidaturesActivity.class);
                startActivity(intent);
            }
        });

        //
        refreshLogin();
        refreshNBOffres();
        refreshCandidatures();
    }

    private void refreshLogin() {
        TextView loginView = findViewById(R.id.login);
        loginView.setText(getLogin());
        refreshMesInformations();
    }

    private void refreshNBOffres() {
        APIClient.getOffres(this, new ResultatAppel<OffresResponse>() {

            @Override
            public void traiterResultat(OffresResponse offres) {
                TextView nbOffresView = findViewById(R.id.textView8);
                nbOffresView.setText(String.valueOf(offres.offres.size()) + " " + nbOffresView.getText().toString());
            }

            @Override
            public void traiterErreur() {
            }
        });
    }

    private void refreshMesInformations() {
        APIClient.getCompteEtudiant(this, getCompteId(), new ResultatAppel<CompteEtudiant>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void traiterResultat(CompteEtudiant compteEtudiant) {
                TextView mesOffresConsulteesView = findViewById(R.id.textView10);
                TextView mesOffresRetenuesView = findViewById(R.id.textView11);
                TextView mesCandidaturesView = findViewById(R.id.textView12);
                TextView derniereConnexionView = findViewById(R.id.derniereCo);
                mesOffresConsulteesView.setText(String.valueOf(compteEtudiant.offreConsultees.size()) + " " + mesOffresConsulteesView.getText().toString());
                mesOffresRetenuesView.setText(String.valueOf(compteEtudiant.offreRetenues.size()) + " " + mesOffresRetenuesView.getText().toString());
                mesCandidaturesView.setText(String.valueOf(compteEtudiant.candidatures.size()) + " " + mesCandidaturesView.getText().toString());
                updateCompte(compteEtudiant);
                derniereConnexionView.setText(compteEtudiant.derniereConnexion);
            }

            @Override
            public void traiterErreur() {
            }
        });
    }

    public void updateCompte(CompteEtudiant compteEtudiant) {
        CompteEtudiantRequete compteReq = new CompteEtudiantRequete();
        compteReq.login = compteEtudiant.login;
        compteReq.roles = compteEtudiant.roles;
        compteReq.password = compteEtudiant.password;
        compteReq.parcours = compteEtudiant.parcours;
        compteReq.derniereConnexion = String.format("%1$tY-%1$tm-%1$tdT%1$tH:%1$tM:00.000Z", Calendar.getInstance().getTime());
        compteReq.etatRecherche = compteEtudiant.etatRecherche;
        compteReq.etudiant = compteEtudiant.etudiant;
        compteReq.offreConsultees = compteEtudiant.offreConsultees;
        compteReq.offreRetenues = compteEtudiant.offreRetenues;
        compteReq.candidatures = compteEtudiant.candidatures;
        APIClient.updateCompteEtudiant(this, APIClient.getCompteId(compteEtudiant._id), compteReq, new ResultatAppel<CompteEtudiant>() {
            @Override
            public void traiterResultat(CompteEtudiant response) {

            }

            @Override
            public void traiterErreur() {

            }
        });
    }

    private void refreshCandidatures() {
        APIClient.getCandidatures(this, new ResultatAppel<CandidaturesResponse>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void traiterResultat(CandidaturesResponse candidatures) {
                TextView nbCandidaturesView = findViewById(R.id.textView13);
                TextView nbCandidaturesRefuseesView = findViewById(R.id.textView14);

                int count = 0;
                for (Candidature c : candidatures.candidatures) {
                    if (c.etatCandidature.compareTo("/api/etat_candidatures/3") == 0) {
                        count++;
                    }
                }
                nbCandidaturesRefuseesView.setText(String.valueOf(count) + " " + nbCandidaturesRefuseesView.getText().toString());
                nbCandidaturesView.setText(String.valueOf(candidatures.candidatures.size() - count) + " " + nbCandidaturesView.getText().toString());
            }

            @Override
            public void traiterErreur() {

            }
        });
    }
}