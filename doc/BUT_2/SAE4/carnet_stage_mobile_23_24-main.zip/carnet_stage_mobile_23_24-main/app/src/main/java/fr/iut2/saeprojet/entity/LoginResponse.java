package fr.iut2.saeprojet.entity;

public class LoginResponse {

    public String token;
}
