# I/ Installation de Docker sur la machine virtuelle

## 1. Se connecter au serveur de stages en ssh depuis une station :

$ ssh stage@IP.station.hôte -p 2222

user@pc-dg-037-11:~$ ssh stage@pc-dg-027-02 -p 2222
stage@Serveur-SAE:~$

## 2. Installer Docker (avec le apt repository : https://docs.docker.com/engine/install/debian/#install-using-the-repository)

## Passer de l'utilisateur stage (mdp: stage) à l'utilisateur root (mdp: root)

    stage@Serveur-SAE:~$ su
    Password: root
    root@Serveur-SAE:/home/stage#

## Désinstaller les paquets conflictuels

    $ for pkg in docker.io docker-doc docker-compose podman-docker containerd runc; do sudo apt-get remove $pkg; done

## Mettre à jour les paquets actuels sur le système

    $ sudo apt update

## Installer les paquets requis pour l'utilisation de Docker

    $ sudo apt install apt-transport-https ca-certificates curl gnupg2 software-properties-common

## Ajout de la clé GPG pour le repository officiel de Docker

    $ sudo install -m 0755 -d /etc/apt/keyrings
    $ sudo curl -fsSL https://download.docker.com/linux/debian/gpg -o /etc/apt/keyrings/docker.asc
    $ sudo chmod a+r /etc/apt/keyrings/docker.asc

## Ajout du repository Docker aux sources apt

    $ echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian $(. /etc/os-release && echo "$VERSION_CODENAME") stable"

    Résultat :
    deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian bullseye stable

    $ sudo add-apt-repository "deb [arch=amd64 signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/debian bullseye stable"

    $ sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/debian $(lsb_release -cs) stable"

    $ sudo apt update

## Installation de la dernière version des paquets Docker

    $ sudo apt-get install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

## Verification de l'installation en testant avec l'image hello-world

    $ sudo docker run hello-world

## Ajouter un utilisateur non-root (stage) au groupe docker pour qu'il ait les accès nécessaires pour pouvoir parler avec le daemon Docker (dockerd)

    $ sudo usermod -aG docker stage

# II/ Installation des conteneurs

## 1. Récupérer les images PHP et Postgres

    $ docker pull php
    $ docker pull postgres

    Vérifier que les images sont bien présentes :

    $ docker images

    Résultat :
    REPOSITORY    TAG       IMAGE ID       CREATED         SIZE
    php           latest    b47bdcbdbd0c   2 weeks ago     537MB
    postgres      latest    b9390dd1ea18   5 weeks ago     431MB
    hello-world   latest    d2c94e258dcb   11 months ago   13.3kB

## 2. Créer un réseau virtuel

    Pour que nos 2 conteneurs puissent communiquer entre eux plus facilement (en utilisant des noms plutôt que des adresse IP), nous allons créer un réseau virtuel pour les héberger.

    $ docker network create mon-reseau

    Résultat :
    70c49babd8d7e23af7f779388c157a58683212ebc80ea103dea82c5096eab93d

    Vérifier que le réseau virtuel a bien été créé :

    $ docker network ls

    Résultat :
    NETWORK ID     NAME         DRIVER    SCOPE
    08e5bfa26e2c   bridge       bridge    local
    2ecd6e96bbfa   host         host      local
    70c49babd8d7   mon-reseau   bridge    local
    4e0992943de3   none         null      local

## A - Installation manuelle

### Conteneur Symfony

Nous allons maintenant créer le conteneur principal dans lequel tournera Symfony. Ce conteneur aura accès à un répertoire de la VM dans lequel le code de l'application sera stocké.

Dans notre VM, le chemin vers le répertoire de notre application Sympfony est :
/home/stage/mc2s-serveur

1.  Lancement du conteneur

    Symfony utilisera le port 8000 à l'intérieur du conteneur et l'application sera aussi accessible sur le port 8001 de la VM. Le répertoire mc2s-serveur de la VM sera visible dans le répertoire /mc2s-serveur du conteneur.
    Pour l'instant, on lance un shell bash dans le conteneur pour y réaliser toutes les opérations d'installation.

         $ docker run --network mon-reseau --name symfony \
         --publish 8001:8000 \
         --mount type=bind,source=/home/stage/mc2s-serveur,target=/mc2s-serveur \
         -ti php bash

    Résultat :
    Passage de root@Serveur-SAE:/home/stage# à root@b97c0f875dbf:/# (mode intéractif)
    root@4b1dc1b34882:/# docker ps --all
    bash: docker: command not found
    root@b97c0f875dbf:/# ls
    bin dev home lib64 media opt root sbin sys usr
    boot etc lib mc2s-serveur mnt proc run srv tmp var
    root@b97c0f875dbf:/# docker-php-
    docker-php-entrypoint docker-php-ext-enable docker-php-source  
    docker-php-ext-configure docker-php-ext-install

    Ouvrir un nouveau terminal ou quitter le mode inéractif et vérifier que le conteneur est bien créé :
    $ docker ps --all
    Résultat :
    CONTAINER ID IMAGE COMMAND CREATED STATUS PORTS NAMES
    b97c0f875dbf php "docker-php-entrypoi…" 11 minutes ago Up About a minute 0.0.0.0:8001->8000/tcp, :::8001->8000/tcp symfony

2.  Configuration de PHP

    On va utiliser un fichier de configuration de PHP (fourni dans l'image) pour que PHP soit en mode développement. On se place dans le conteneur (-i).

    $ docker start -i symfony
    $ mv "$PHP_INI_DIR/php.ini-development" "$PHP_INI_DIR/php.ini"

    On vérifie que PHP est fonctionnel.

    $ php -v
    Résultat :
    PHP 8.3.4 (cli) (built: Mar 15 2024 23:59:35) (NTS)
    Copyright (c) The PHP Group
    Zend Engine v4.3.4, Copyright (c) Zend Technologies

3.  Installation des logiciels nécessaires à Symfony dans le conteneur

    Installer git.

    $ apt update
    $ apt install git --no-install-recommends

    Verifier que git fonctionne.

    $ git --version
    Résultat :
    git version 2.39.2

    Installer Composer avec les 4 lignes se trouvant ici : https://getcomposer.org/download/

    Déplacer Composer dans un répertoire du PATH.

    $ mv composer.phar /usr/local/bin/composer

    Vérifier que Composer fonctionne.

    $ composer
    Résultat :
    Composer version 2.7.2 2024-03-11 17:12:18

4.  Installation de l'utilitaire en ligne de commande (CLI) de Symfony

    Télécharger et exécuter un script d'installation.

    $ curl -sS https://get.symfony.com/cli/installer | bash

    Déplacer Symfony CLI dans un répertoire du PATH.

    $ mv /root/.symfony5/bin/symfony /usr/local/bin/

    Vérifier que Symfony fonctionne.

    $ symfony
    Résultat :
    Symfony CLI version 5.8.14 (c) 2021-2024 Fabien Potencier

5.  Installation de modules PHP complémentaires pour Symfony

    Lister les modules déjà actifs dans notre installation de PHP.

    $ php -m

    Demander à Symfony de lister les modules PHP dont il aura besoin.

    $ symfony check:requirements
    Résultat :
    Optional recommendations to improve your setup

    ```
    * intl extension should be available
    > Install and enable the intl extension (used for validators).

    * a PHP accelerator should be installed
    > Install and/or enable a PHP accelerator (highly recommended).

    Installer le module intl.

    $ apt install libicu-dev
    $ docker-php-ext-install intl

    Installer le module opcache.

    $ docker-php-ext-install opcache

    Installer et activer le module xdebug.

    $ pecl install xdebug
    $ docker-php-ext-enable xdebug

    Installer les modules pgsql et PDO-pgsql.

    $ apt install libpq-dev 
    $ docker-php-ext-install pgsql
    $ docker-php-ext-install pdo_pgsql

6. Démarrer le serveur Symfony

    $ cd mc2s-serveur
    $ symfony server:start --no-tls

    Vérifier que le serveur est disponible à l'URL http://ADRESSE_IP_VM:8000/

7. Configurer git dans la VM

    $ git config --global user.email "johaina.boudiaf@etu.univ-grenoble-alpes.fr"
    $ git config --global user.name "boudiafj"
    $ git init
    $ git remote add origin https://gricad-gitlab.univ-grenoble-alpes.fr/iut2-info-stud/2024-s4/sae-4a/team_08/carnet_stage_serveur_23_24.git
    $ git config pull.rebase false
    $ git pull
    $ ls -a


### Conteneur SGBD

Nous allons maintenant créer un 2ème conteneur pour faire tourner PostgreSQL. Ce conteneur utilisera un volume Docker pour stocker les données persistantes (celle de votre BD). 

1. Créer un volume Docker

    $ docker volume create ma-bd

    Vérifier que le volume a bien été créé.

    $ docker volume ls

2. Lancement du conteneur

    Le conteneur doit être lancé en tâche de fond. Le mot de passe de l'utilisateur postgres du SGBD est fixé dans la ligne de commande. Le volume est monté dans le répertoire où PostgreSQL stocke les BD. 

    $ docker run \
        --detach \
        --network mon-reseau --name mon-sgbd \
        --env POSTGRES_PASSWORD="mon-mdp" \
        --volume ma-bd:/var/lib/postgresql/data \
        postgres
    Résultat : 
    28e9c2991ef63cc18ea4e8aa1381603d51bb4c6acdb6340158b043725ae83355

3. Récupérer l'adresse IP de ce conteneur

    $ docker inspect mon-sgbd | grep IPAddress
    Résultat :
     "SecondaryIPAddresses": null,
            "IPAddress": "",
                    "IPAddress": "172.18.0.3",

4. Lancer un client psql pour se connecter au SGBD

    $ docker run -ti --network mon-reseau postgres psql -h 172.18.0.3 -U postgres
    Résultat : 
    postgres=#

5. Dans le SGBD, créer un utilisateur et donner le droit à cet utilisateur de créer des BD

    $ create user "stage" with password 'mon-mdp';
    $ alter user "stage" createdb ;

Vérifier que ce nouvel utilisateur a bien été créé.

    $ select * from pg_user;


### Connexion Symfony - SGBD

Nous allons maintenant configurer notre projet pour qu'il utilise la BD créée précédemment. 

1. Depuis la VM, éditer le fichier .env

    $ vim .env

2. docker run -ti --network mon-reseau postgres psql -h 172.18.0.3 -U stage ma-bd




## B - Installation automatique avec un Dockerfile

---

## Commandes utiles

### Lister tous les conteneurs :

    $ docker ps --all

### Lister toutes les images :

    $ docker images

### Supprimer un conteneur :

    $ docker rm NOM_CONTENEUR
    OU
    $ docker rm IDENTIFIANT_HEXADÉCIMAL

### Démarrer un conteneur :

    $ docker start <nom conteneur>

### Démarrer un conteneur en mode intéractif :

    $ docker start -i <nom conteneur>

### Se connecter à un conteneur en mode intéractif :

    $ docker exec -ti symfony bash
    OU
    $ docker exec -it <CONTAINER ID> sh

### Quitter le mode intéractif :

    ctr + d
    OU
    $ exit

### Arrêter un conteneur :

    $ docker stop <nom conteneur>

### Redémarrer le service Docker :

    $ sudo systemctl daemon-reload
    $ sudo systemctl restart docker

### Informations sur un port précis <num port>

    $ sudo lsof -i:<num port>
    OU
    $ sudo lsof -i -P -n | grep <num port>

### Lister les ports ouverts

    $ sudo lsof -i -P -n | grep LISTEN

### Afficher arborescence jusqu'au niveau 2

    $ tree -d -L 2