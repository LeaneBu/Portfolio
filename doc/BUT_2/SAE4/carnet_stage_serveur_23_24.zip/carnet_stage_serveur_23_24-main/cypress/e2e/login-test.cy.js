describe('template spec', () => {
  beforeEach('passes', () => {
    cy.visit('http://192.168.141.144:8000/')
  })

  it('TF1: Connexion valide', () => {
    //Aller à la page authentification
    cy.get('.card.clickable').click();
    //Saisie valide
    cy.get('#inputLogin').type('borealea');
    cy.get('#inputPassword').type('aurore');
    //Simuler clic sur btn
    cy.get('.btn').click();
    //Vérification affichage de la page d'acceuil
    cy.get('.alert.alert-danger').should('not.exist')
    cy.contains('(Rôle : etudiant)').should('exist')

  });
    
  //tolerance aux fautes
  it('TF2: Erreur de connexion', () => {
    cy.get('.card.clickable').click();
    //Saisie non-valide
    cy.get('#inputLogin').type('test');
    cy.get('#inputPassword').type('test');
    cy.get('.btn').click();
    //Vérification affichage de la page d'acceuil
    cy.contains('Bienvenue').should('not.exist')
  });

  it('TF3: Connexion a un compte étudiant ', () => {
    //Aller à la page authentification
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('borealea');
    cy.get('#inputPassword').type('aurore');
    cy.get('.btn').click();
    //Vérification rôle étudiant
    cy.contains('(Rôle : etudiant)').should('exist')
  });

  it('TF4: Connexion a un compte admin ', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Vérification affichage de la page d'acceuil
    cy.contains('(Rôle : admin)').should('exist')
  });

})

