const red ='rgb(220, 53, 69)';


describe('template spec', () => {
  beforeEach('passes', () => {
    cy.visit('http://192.168.141.144:8000/')
  })

  //test
  it('TF1: Connexion a un compte admin ', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Vérification page acceuil admin
    cy.contains('(Rôle : admin)').should('exist');
  });;

  it('TF2: Accéder à la page Etudiant ', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Vérification bonne page avec url
    cy.url().should('include','/admin/etudiant/');
  });;

  //Nouvel etudiant non-valide
  it('TF3: Numero INE invalide', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Ajouter nouvel etudiant
    cy.get('.btn-sm').click();
    //Formulaire  avec numéro INE invalide
    cy.get('#etudiant_numeroINE').type('00000000000');
    cy.get('#etudiant_nom').type('Test');
    cy.get('#etudiant_prenom').type('Test');
    cy.get('#etudiant_email').type('test@test.com');
    cy.contains('Enregistrer').click();
    cy.get('.invalid-feedback.d-block').should('exist');
    cy.get('.invalid-feedback.d-block').should('have.class', 'd-block');
    //Vérifier que c'est bien une erreur = rouge
    cy.get('.invalid-feedback.d-block').should('have.css', 'color',red);
  });


  it('TF4: Email invalide', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Ajouter nouvel etudiant
    cy.get('.btn-sm').click();
    //Formulaire  avec email invalide
    cy.get('#etudiant_numeroINE').type('1111111111E');
    cy.get('#etudiant_nom').type('Test');
    cy.get('#etudiant_prenom').type('Avatar');
    cy.get('#etudiant_email').type('test@provider');
    cy.contains('Enregistrer').click();
    cy.get('.invalid-feedback.d-block').should('exist');
    cy.get('.invalid-feedback.d-block').should('have.class', 'd-block');
    //Vérifier que c'est bien une erreur = rouge
    cy.get('.invalid-feedback.d-block').should('have.css', 'color',red);

  });

  it.only('TF5: Numero INE invalide', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Ajouter nouvel etudiant
    cy.get('.btn-sm').click();
    cy.get('#etudiant_numeroINE').type('1234567890E');
    cy.get('#etudiant_nom').type('Aavatar');
    cy.get('#etudiant_prenom').type('Avatar');
    cy.get('#etudiant_email').type('test@test.com');
    cy.contains('Enregistrer').click();
    //Vérifier qu'il est bien dans le tableau
    cy.get('.MyDataTable').contains('td','Avatar').should('exist');
    cy.get('.MyDataTable').contains('td','Avatar').parent().get('td').eq(1).should('have.text','1234567890E');
    cy.get('.MyDataTable').contains('td','Avatar').parent().get('td').eq(2).should('have.text','Aavatar');
    cy.get('.MyDataTable').contains('td','Avatar').parent().get('td').eq(4).should('have.text','test@test.com');
  });

  it('TF5: Creer un eleve avec meme numero INE', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Ajouter nouvel etudiant
    cy.get('.btn-sm').click();
    cy.get('#etudiant_numeroINE').type('1234567890E');
    cy.get('#etudiant_nom').type('Aavatar');
    cy.get('#etudiant_prenom').type('Avatar');
    cy.get('#etudiant_email').type('test@test.com');
    cy.contains('Enregistrer').click();
    //Vérifier qu'il est bien dans le tableau
    cy.get('.invalid-feedback.d-block').should('have.text','L\'étudiant avec ce numéro INE éxiste déjà.');
  });


  it.only('TF7: Supprimer l eleve', () => {
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('fontenae');
    cy.get('#inputPassword').type('eric');
    cy.get('.btn').click();
    //Navbar --> Interface
    cy.get('.nav-item').eq(1).click();
    cy.get('.dropdown-item').eq(2).click();
    //Ajouter nouvel etudiant
    cy.contains('1234567890E').parent().contains('éditer').click();
    cy.get('.btn-danger.col-md-1').click()

  });
  
})