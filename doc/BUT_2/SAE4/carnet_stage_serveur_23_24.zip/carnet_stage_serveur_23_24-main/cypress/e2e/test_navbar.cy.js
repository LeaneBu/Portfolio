describe('template spec', () => {
  beforeEach('passes', () => {
    cy.visit('http://192.168.141.144:8000/')
  })

  it('TF1: accéder à Offre de Stages', () => {
    //Connexion
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('borealea');
    cy.get('#inputPassword').type('aurore');
    cy.get('.btn').click();
    //Navbar direction --> Offre de Stage
    cy.get('.nav-item').first().click();
    //Vérifier qu'on est sur la bonne page
    cy.get('.text-center').eq(0).should('have.text','Candidatures Etudiant');
    cy.get('.text-center').eq(1).should('have.text','Offres de Stage');
  });

  it.only('TF2: accéder au tableau de bord', () => {
    //Connexion
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('borealea');
    cy.get('#inputPassword').type('aurore');
    cy.get('.btn').click();
    //Navbar direction --> Tableau de bord
    cy.get('.nav-item').eq(1).click();
    //Vérifier qu'on est sur la bonne page
    cy.get('.card-header').find('h4').invoke('text').then((text) =>{
      expect(text.trim()).equal('BOREALE Aurore')
    });
  });

  it('TF3: déconnexion', () => {
    //Connexion
    cy.get('.card.clickable').click();
    cy.get('#inputLogin').type('borealea');
    cy.get('#inputPassword').type('aurore');
    cy.get('.btn').click();
    //Navbar direction --> Déconnexion
    cy.get('.nav-item').eq(2).click();
    //Vérifier qu'on est sur la bonne page
    cy.get('.card.clickable').should('exist') 
  });
  
})