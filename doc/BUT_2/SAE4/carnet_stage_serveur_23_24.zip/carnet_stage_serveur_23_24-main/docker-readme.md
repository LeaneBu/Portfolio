# Installer docker compose

$ apt install docker-compose

# Lancer les conteneurs

$ docker-compose up --build

Une fois le conteneur symfony lancé, connectez vous à l'URL suivante :

```
https://[URL_DE_VOTRE_MACHINE]:8001/
```