<?php

namespace App\Controller\Etudiant;

use App\Repository\CompteEtudiantRepository;
use App\Repository\OffreRepository;
use App\Entity\CompteEtudiant;
use App\Controller\Shared\TableauDeBordGeneralController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Security;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/etudiant/tableau_de_bord')]
class TableauDeBordController extends AbstractController
{

    #[Route('/', name: 'app_etudiant_tableau_de_bord_index', methods: ['GET'])]
    public function index(Security $security): Response
    {
        return $this->render('Tableau_de_bord/index.html.twig', [
            'comptes' => [$security->getUser()],
        ]);
    }

    #[Route('/show', name: 'app_etudiant_tableau_de_bord_show', methods: ['GET'])]
    public function show(Security $security, OffreService $offreService): Response
    {
        $compte = $security->getUser();
        return $this->render('Tableau_de_bord/show.html.twig', [
            'compte' => $compte,
            'offresByCompte' => $offreService->getOffreByCompte($compte),
        ]);
    }
    #[Route('/offre/{id}', name: 'app_url', methods: ['GET'])]
    public function view(Security $security, Offre $offre, OffreConsulteeRepository $offreConsulteeRepository): Response
    {
        $compte = $security->getUser();
        $offreConsultee = new OffreConsultee();
        $offreConsultee->setCompteEtudiant($compte);
        $offreConsultee->setOffre($offre);
        $url=$offre->getUrlPieceJointe();
        $offreConsulteeRepository->save($offreConsultee, true);
        return $this->redirect("$url");
    }
}
