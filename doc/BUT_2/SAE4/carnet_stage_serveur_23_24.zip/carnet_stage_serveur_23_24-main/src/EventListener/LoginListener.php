<?php
// src/EventListener/LoginListener.php

namespace App\EventListener;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\Security\Http\Event\InteractiveLoginEvent;
use Symfony\Component\Security\Http\SecurityEvents;
use Symfony\Component\Security\Core\Security;
use App\Repository\CompteEtudiantRepository;
use Doctrine\ORM\EntityManagerInterface;

class LoginListener implements EventSubscriberInterface
{
    private $security; private $entityManager;

    public function __construct(Security $security, EntityManagerInterface $entityManager)
    {
        $this->security = $security;
        $this->entityManager = $entityManager;
    }

    public static function getSubscribedEvents()
    {
        return [
            SecurityEvents::INTERACTIVE_LOGIN => 'onSecurityInteractiveLogin',
        ];
    }

    public function onSecurityInteractiveLogin(InteractiveLoginEvent $event )
    {
        $user = $this->security->getUser();
             
        // Enregistrez la date de connexion de l'utilisateur
        $user->setDerniereConnexion(new \DateTime());
        $this->entityManager->flush(); 
    }
}