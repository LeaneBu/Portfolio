<?php

namespace App\Form;

use App\Entity\Candidature;
use App\Entity\CompteEtudiant;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Doctrine\ORM\EntityManagerInterface;
class CandidatureType extends AbstractType {
    private EntityManagerInterface $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
    }
    public function buildForm(FormBuilderInterface $builder, array $options): void {
        $builder
                ->add('compteEtudiant', EntityType::class, [
                    'class' => CompteEtudiant::class,
                    'choice_label' => function (CompteEtudiant $compteEtudiant) {
                        return $compteEtudiant->getEtudiant(); // Remplacez par la méthode appropriée pour obtenir le nom complet de l'étudiant
                    },
                    'choices' => $this->getFilteredStudentAccounts(),
                ])
                ->add('offre')
                ->add('typeAction', null, [
                    'attr' => [
                        'placeholder' => 'Entrez le type d\'action',
                        // Ajoutez d'autres attributs HTML si nécessaire
                    ]
                ])
                ->add('etatCandidature')
        ;
    }
    private function getFilteredStudentAccounts(): array
    {
        $studentAccounts = $this->entityManager->getRepository(CompteEtudiant::class)->findAll();

        $filteredAccounts = [];
        foreach ($studentAccounts as $account) {
            // Ajouter le compte étudiant uniquement s'il n'a pas le rôle "admin"
            if (!in_array('ROLE_ADMIN', $account->getRoles(), true)) {
                $filteredAccounts[$account->getId()] = $account;
            }
        }

        return $filteredAccounts;
    }
    public function configureOptions(OptionsResolver $resolver): void {
        $resolver->setDefaults([
            'data_class' => Candidature::class,
        ]);
    }
}
