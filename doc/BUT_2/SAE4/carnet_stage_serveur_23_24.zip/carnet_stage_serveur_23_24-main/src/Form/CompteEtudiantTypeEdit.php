<?php

namespace App\Form;

use App\Entity\CompteEtudiant;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Regex;
use Symfony\Component\Validator\Constraints\GreaterThanOrEqual;

class CompteEtudiantTypeEdit extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options): void {
        $builder
                ->add('etudiant', EntityType::class, [
                    'class' => CompteEtudiant::class,
                    'data' => $options['data'], // Pass the current CompteEtudiant object
                    'disabled' => true, // Disable the field to prevent selection
                    'required' => true, // Make the field required
                ])
                ->add('login', null, [
                    'constraints' => [
                        new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                    ],
                    'attr' => [
                        'placeholder' => 'Ex : duponta',
                        // Ajoutez d'autres attributs HTML si nécessaire
                    ]
                ])
                ->add('role', ChoiceType::class, ["mapped" => false, "choices" => ["Etudiant·e" => "ROLE_ETUDIANT", "Administrateur" => "ROLE_ADMIN"]])
                ->add('password', PasswordType::class, [
                    'constraints' => [
                        new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                        new Regex([
                            'pattern' => '/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/',
                            'message' => 'Le mot de passe doit comporter au moins 8 caractères, dont au moins une majuscule, une minuscule, un chiffre et un caractère spécial.'
                        ]),
                    ],
                    'attr' => [
                        'placeholder' => 'Entrez le mot de passe',
                        // Ajoutez d'autres attributs HTML si nécessaire
                    ]
                ])
                ->add('parcours', ChoiceType::class, ["choices" => ["Indéfini" => "*", "Parcours A" => "A", "Parcours B" => "B"]])
                ->add('etatRecherche')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void {
        $resolver->setDefaults([
            'data_class' => CompteEtudiant::class,
        ]);
    }

}
