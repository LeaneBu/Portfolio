<?php

namespace App\Form;

use App\Entity\Entreprise;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;
class EntrepriseType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('raisonSociale', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex : NomEntreprise',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ])
            ->add('ville', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex : Grenoble',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ])
            ->add('pays', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex : France',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Entreprise::class,
        ]);
    }
}
