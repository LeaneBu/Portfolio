<?php

namespace App\Form;

use App\Entity\Etudiant;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\Email;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Regex;
use Symfony\Component\Validator\Constraints\Length;

class EtudiantType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('numeroINE', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                    new Length(['min' => 11, 'max' => 11, 'exactMessage' => 'Le numéro INE doit comporter exactement {{ limit }} caractères.']),
                    new Regex([
                        'pattern' => '/^[0-9]{10}[a-zA-Z]{1}$/',
                        'message' => 'Le numéro INE doit être au format correct ( dix chiffres suivis de 1 lettre).',
                    ]),
                ],
                'attr' => [
                    'placeholder' => 'Ex : 1234567890E',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ])
            ->add('nom', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex :  Dupont',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ])
            ->add('prenom', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex : Antoine',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ])
            ->add('email', null, [
                'constraints' => [
                    new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                    new Email(['message' => 'Veuillez entrer une adresse email valide.']),
                ],
                'attr' => [
                    'placeholder' => 'Ex: dupontantoine@mail.com',
                    // Ajoutez d'autres attributs HTML si nécessaire
                ],
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Etudiant::class,
        ]);
    }
}
