<?php

namespace App\Form;

use App\Entity\Offre;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Validator\Constraints\Url;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\GreaterThanOrEqual;

class OffreType extends AbstractType {

    public function buildForm(FormBuilderInterface $builder, array $options): void {
        $builder
                ->add('entreprise')
                ->add('intitule', null, [
                    'constraints' => [
                        new NotBlank(['message' => 'Ce champ ne peut pas être vide.'])],
                        ])
                ->add('descriptif')
                ->add('dateDepot', DateType::class, [
                    'widget' => 'single_text',
                    'constraints' => [
                        new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                        new GreaterThanOrEqual([
                            'value' => new \DateTime(),
                            'message' => 'La date doit être postérieure ou égale à aujourd\'hui.'
                        ]),
                    ],
                ])
                ->add('parcours', ChoiceType::class, ["choices" => ["Indéfini" => "*", "Parcours A" => "A", "Parcours B" => "B"]])
                ->add('motsCles')
                ->add('urlPieceJointe', null, [
                    'constraints' => [
                        new NotBlank(['message' => 'Ce champ ne peut pas être vide.']),
                        new Url(['message' => 'Veuillez entrer une URL valide.']),
                    ],
                ])
                ->add('etatOffre')

        ;
    }

    public function configureOptions(OptionsResolver $resolver): void {
        $resolver->setDefaults([
            'data_class' => Offre::class,
        ]);
    }

}
