# API Gestion des Participants, Groupes, Parcours et Destinations

## 1. Spécification du système

### Entités principales

- **Participant** :
  - **Attributs** :
    - `id` : Identifiant unique du participant.
    - `firstname` : Prénom.
    - `lastname` : Nom.
    - `email` : Adresse email.
    - `status` : Statut parmi `student`, `worker`, `jobless`, ou `leader`.
    - `hometown` : Ville d'origine avec code pays (ex. : `"Paris (FR)"`).
    - `id_groupe` : Identifiant du groupe auquel le participant est rattaché.
  - **Relations** :
    - Chaque participant est lié à un groupe.

- **Groupe** :
  - **Attributs** :
    - `groupe` : Identifiant unique du groupe.
    - `leader` : Nom complet du leader (participant ayant le statut `leader`).
    - `list_participant` : Liste des participants appartenant au groupe.
    - `dest_country` : Liste des pays présents dans le parcours du groupe.
    - `parcours` : Liste des trajets attribués au groupe.
  - **Relations** :
    - Un groupe contient plusieurs participants et un parcours.

- **Parcours** :
  - **Attributs** :
    - `dest` : Liste de destinations.
    - `date_debut` : Date de début du parcours.
    - `date_fin` : Date de fin du parcours.
  - **Relations** :
    - Chaque parcours est associé à un groupe.

- **Destination** :
  - **Attributs** :
    - `id` : Identifiant unique de la destination
    - `dest_city` : Nom de la ville.
    - `dest_country` : Pays correspondant.

### Relations entre entités

- Un **participant** appartient à un **groupe**.
- Un **groupe** peut avoir plusieurs **participants** et un **parcours** unique.
- Un **parcours** est constitué de **destinations**.

---

## 2. Spécification OpenAPI

Le fichier OpenAPI est disponible dans le fichier **`swagger.yaml`**.

### Aperçu des routes :

- **Participants** :
  - `GET /participants` : Récupérer tous les participants.
  - `POST /participants` : Ajouter un participant.
- **Groupes** :
  - `GET /groupes` : Récupérer tous les groupes.
  - `POST /groupes` : Ajouter un groupe.
  - `GET /groupes/:id/participants` : Récupérer les participants d'un groupe spécifique.
  - `GET /groupes/:id/parcours` : Récupérer le parcours d'un groupe spécifique.
  - `DELETE /groupes/:id/parcours` : Supprimer le parcours d'un groupe spécifique.
- **Parcours** :
  - `GET /parcours` : Récupérer tous les parcours.
  - `POST /parcours` : Ajouter un parcours.
- **Destinations** :
  - `GET /destinations` : Récupérer toutes les destinations.
  - `POST /destinations` : Ajouter une destination.

---

## 3. Instructions pour exécuter le serveur

### Prérequis

1. **Node.js** :
   - Installez Node.js (version 14 ou supérieure).
2. **Fichiers nécessaires** :
   - `server.js` : Serveur principal.
   - `router.js` : Gestion des routes.
   - `mime-types.js` : Gestion des types MIME.
   - `travel.json` : Jeu de données.
   - `swagger.yaml` : Spécification OpenAPI.

### Lancer le serveur

1. Clonez le projet ou téléchargez les fichiers.
2. Placez-vous dans le répertoire du projet.
3. Exécutez la commande suivante :

   ```bash
   node server.js
   ```


## 4. Jeu de données utilisés
### Exemple de participants

```json
[
  {
    "id": 1,
    "firstname": "Fredericka",
    "lastname": "Roxanna",
    "email": "fredericka.roxanna@gmail.com",
    "status": "student",
    "hometown": "Paris (FR)",
    "id_groupe": 1
  },
  {
    "id": 2,
    "firstname": "Barbara",
    "lastname": "Harday",
    "email": "barbara.harday@gmail.com",
    "status": "jobless",
    "hometown": "Berlin (DE)",
    "id_groupe": 1
  }
]
```

### Exemple de groupes

```json
[
  {
    "groupe": 1,
    "leader": "Annaliese Tybald",
    "list_participant": [],
    "dest_country": "Japan",
    "parcours": [
      {
        "dest": [
          { "dest_city": "Tokyo", "dest_country": "Japan" },
          { "dest_city": "Kyoto", "dest_country": "Osaka" },
          { "dest_city": "Marseille", "dest_country": "Japan" }
        ],
        "date_debut": "2024-12-20",
        "date_fin": "2024-12-30"
      }
    ]
  }
]

```

## 5. Méthodologie suivie
### Étapes suivies

**Spécification OpenAPI avant le développement:**  
- La spécification OpenAPI a été rédigée en premier.
- Cela a permis de structurer et valider les routes et les données avant d'écrire le code.

**Développement du serveur Node.js :**  
- Le serveur a été implémenté en suivant strictement la spécification OpenAPI.
- Chaque route a été testée avec les données du fichier travel.json.

### Pourquoi cette approche ?

- **Clarté** : La spécification OpenAPI agit comme un plan détaillé de l'API, facilitant la compréhension et la validation.
- **Collaboration** : Partager la spécification avec d'autres membres ou parties prenantes avant le développement garantit que les besoins sont bien compris.
- **Conformité** : Respecter la spécification réduit les risques de divergence entre la documentation et l'implémentation.

## 6. Documentation Swagger

La documentation Swagger complète est accessible ici : http://localhost:3800/api-docs