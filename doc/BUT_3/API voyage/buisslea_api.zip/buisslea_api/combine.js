const fs = require('fs');
const path = require('path');

const participantsPath = path.join(__dirname, 'participants.json');
const groupesPath = path.join(__dirname, 'groupes.json');
const destinationsPath = path.join(__dirname, 'destinations.json');

function readJSON(filePath) {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, 'utf-8', (err, data) => {
            if (err) reject(err);
            resolve(JSON.parse(data));
        });
    });
}

function addIdToDestinations(destinations) {
    return destinations.map((destination, index) => ({
        id: index + 1,
        ...destination
    }));
}

function generateParcours(destinations) {
    const shuffledDestinations = destinations.sort(() => 0.5 - Math.random());
    const selectedDestinations = shuffledDestinations.slice(0, 3);

    return {
        dest: selectedDestinations,
        date_debut: "2024-12-01",
        date_fin: "2024-12-10"
    };
}

function updateDestCountry(group) {
    const countries = new Set();

    group.parcours.forEach(parcours => {
        parcours.dest.forEach(destination => {
            countries.add(destination.dest_country);
        });
    });

    group.dest_country = Array.from(countries).join(", ");
}

async function generateCombinedJSON() {
    try {
        const participants = await readJSON(participantsPath);
        const groupes = await readJSON(groupesPath);
        let destinations = await readJSON(destinationsPath);

        destinations = addIdToDestinations(destinations);

        console.log("Participants chargés :", participants.length);
        console.log("Groupes chargés :", groupes.length);
        console.log("Destinations chargées :", destinations.length);

        groupes.forEach(group => {
            group.list_participant = participants.filter(p => p.id_groupe === group.groupe);

            const leader = group.list_participant.find(p => p.status === 'leader');
            group.leader = leader ? leader.firstname + " " + leader.lastname : "Non défini";

            const parcours = generateParcours(destinations);
            group.parcours = [parcours];

            updateDestCountry(group);
        });

        const combinedData = {
            participants,
            groupes,
            destinations
        };

        const outputPath = path.join(__dirname, 'travel.json');
        fs.writeFile(outputPath, JSON.stringify(combinedData, null, 2), (err) => {
            if (err) throw err;
            console.log('Fichier JSON combiné créé : travel.json');
        });
    } catch (error) {
        console.error('Erreur lors de la génération du fichier combiné :', error);
    }
}

generateCombinedJSON();
