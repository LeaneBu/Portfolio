const express = require('express');
const fs = require('fs');
const swaggerUi = require('swagger-ui-express');
const yaml = require('yamljs');

const app = express();
const port = 3800;

const travelData = JSON.parse(fs.readFileSync('./travel.json', 'utf-8'));
app.use(express.json()); 

/* Swagger */
const swaggerDocument = yaml.load('./swagger.yaml');
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

// Main route
app.get('/', (req, res) => {
    res.json({
        message: "Bienvenue dans l'API pour gérer les participants, les groupes, les parcours et les destinations.",
        routes: {
            "/participants": {
                methods: ["GET", "POST", "DELETE"],
                description: "Retourne la liste des participants, ajoute ou supprime un participant."
            },
            "/groupes": {
                methods: ["GET", "POST", "DELETE"],
                description: "Retourne la liste des groupes, ajoute ou supprime un groupe."
            },
            "/parcours": {
                methods: ["GET", "POST", "PUT"],
                description: "Retourne tous les parcours, ajoute ou met à jour un parcours."
            },
            "/destinations": {
                methods: ["GET", "POST"],
                description: "Retourne toutes les destinations ou ajoute une destination."
            }
        }
    });
});

// Participants
app.get('/participants', (req, res) => {
    res.json(travelData.participants);
});

app.get('/participants/:id', (req, res) => {
    const participantId = parseInt(req.params.id, 10);
    const participant = travelData.participants.find(p => p.id === participantId);

    if (!participant) {
        return res.status(404).json({ error: 'Participant non trouvé' });
    }

    res.status(200).json(participant);
});

app.post('/participants', (req, res) => {
    const lastId = travelData.participants.length
        ? Math.max(...travelData.participants.map(p => p.id))
        : 0;

    const newParticipant = { id: lastId + 1, ...req.body };

    const groupId = newParticipant.id_groupe;
    const groupe = travelData.groupes.find(group => group.groupe === groupId);

    if (!groupe) {
        return res.status(404).json({ error: 'Groupe non trouvé pour cet id_groupe' });
    }

    travelData.participants.push(newParticipant);
    groupe.list_participant.push(newParticipant);

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(201).json(newParticipant);
});

app.put('/participants/:id', (req, res) => {
    const participantId = parseInt(req.params.id, 10);
    const participantIndex = travelData.participants.findIndex(p => p.id === participantId);

    if (participantIndex === -1) {
        return res.status(404).json({ error: 'Participant non trouvé' });
    }

    const existingParticipant = travelData.participants[participantIndex];
    const updatedData = { ...req.body };

    delete updatedData.id;

    travelData.participants[participantIndex] = {
        ...existingParticipant,
        ...updatedData
    };

    if (existingParticipant.id_groupe !== updatedData.id_groupe) {
        if (existingParticipant.id_groupe) {
            const oldGroup = travelData.groupes.find(g => g.groupe === existingParticipant.id_groupe);
            if (oldGroup) {
                oldGroup.list_participant = oldGroup.list_participant.filter(p => p.id !== participantId);
            }
        }

        if (updatedData.id_groupe) {
            const newGroup = travelData.groupes.find(g => g.groupe === updatedData.id_groupe);
            if (newGroup) {
                newGroup.list_participant.push(travelData.participants[participantIndex]);
            }
        }
    }

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({
        message: `Participant ${participantId} mis à jour avec succès`,
        participant: travelData.participants[participantIndex]
    });
});



app.delete('/participants/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    const participantIndex = travelData.participants.findIndex(p => p.id === id);

    if (participantIndex !== -1) {
        const participant = travelData.participants[participantIndex];
        const groupe = travelData.groupes.find(group => group.groupe === participant.id_groupe);
        if (groupe) {
            groupe.list_participant = groupe.list_participant.filter(p => p.id !== id);
        }

        travelData.participants.splice(participantIndex, 1);

        fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));
        res.status(200).json({ message: `Participant ${id} supprimé avec succès` });
    } else {
        res.status(404).json({ error: 'Participant non trouvé' });
    }
});

// Groupes
app.get('/groupes', (req, res) => {
    res.json(travelData.groupes);
});

app.get('/groupes/:id', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const group = travelData.groupes.find(g => g.groupe === groupId);

    if (!group) {
        return res.status(404).json({ error: 'Groupe non trouvé' });
    }

    res.status(200).json(group);
});

app.post('/groupes', (req, res) => {
    const lastId = travelData.groupes.length
        ? Math.max(...travelData.groupes.map(g => g.groupe))
        : 0;

    const newGroup = { groupe: lastId + 1, ...req.body, list_participant: [] };

    travelData.groupes.push(newGroup);

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(201).json(newGroup);
});

app.get('/groupes/:id/participants', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const groupe = travelData.groupes.find(group => group.groupe === groupId);
    if (groupe) {
        res.json(groupe.list_participant);
    } else {
        res.status(404).json({ error: 'Groupe non trouvé' });
    }
});

app.delete('/groupes/:groupId/participants/:participantId', (req, res) => {
    const groupId = parseInt(req.params.groupId, 10);
    const participantId = parseInt(req.params.participantId, 10);

    const groupe = travelData.groupes.find(group => group.groupe === groupId);
    if (!groupe) {
        return res.status(404).json({ error: 'Groupe non trouvé' });
    }

    const participantIndex = groupe.list_participant.findIndex(p => p.id === participantId);
    if (participantIndex === -1) {
        return res.status(404).json({ error: 'Participant non trouvé dans ce groupe' });
    }

    groupe.list_participant.splice(participantIndex, 1);

    const participant = travelData.participants.find(p => p.id === participantId);
    if (participant) {
        participant.id_groupe = 0;
    }

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({
        message: `Participant ${participantId} retiré du groupe ${groupId} avec succès`,
        participant
    });
});


app.get('/groupes/:id/parcours', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const groupe = travelData.groupes.find(group => group.groupe === groupId);
    if (groupe && groupe.parcours) {
        res.json(groupe.parcours);
    } else {
        res.status(404).json({ error: 'Parcours non trouvé pour ce groupe' });
    }
});

app.post('/groupes/:id/parcours', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const { dest_ids, date_debut, date_fin } = req.body;

    if (!dest_ids || !Array.isArray(dest_ids) || dest_ids.length === 0) {
        return res.status(400).json({ error: "Le champ 'dest_ids' est requis et doit être un tableau d'IDs de destinations." });
    }

    if (!date_debut || !date_fin) {
        return res.status(400).json({ error: "Les champs 'date_debut' et 'date_fin' sont requis." });
    }

    const group = travelData.groupes.find(g => g.groupe === groupId);

    if (!group) {
        return res.status(404).json({ error: 'Groupe non trouvé.' });
    }

    const destinations = dest_ids.map(id => {
        const destination = travelData.destinations.find(dest => dest.id === id);
        if (!destination) {
            res.status(400).json({ error: `La destination avec l'ID ${id} n'existe pas.` });
            throw new Error(`Invalid destination ID: ${id}`); // Stop execution
        }
        return destination;
    });

    if (!group.parcours) {
        group.parcours = [];
    }

    const newParcours = {
        dest: destinations,
        date_debut,
        date_fin
    };

    group.parcours.push(newParcours);

    const countries = new Set(destinations.map(dest => dest.dest_country));
    group.dest_country = Array.from(countries).join(", ");

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(201).json({
        message: `Parcours ajouté au groupe ${groupId} avec succès.`,
        parcours: newParcours
    });
});


app.put('/groupes/:id', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const groupIndex = travelData.groupes.findIndex(g => g.groupe === groupId);

    if (groupIndex === -1) {
        return res.status(404).json({ error: 'Groupe non trouvé' });
    }

    const existingGroup = travelData.groupes[groupIndex];
    const updatedData = { ...req.body };

    delete updatedData.groupe;

    travelData.groupes[groupIndex] = {
        ...existingGroup,
        ...updatedData
    };

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({
        message: `Groupe ${groupId} mis à jour avec succès`,
        groupe: travelData.groupes[groupIndex]
    });
});


app.delete('/groupes/:id', (req, res) => {
    const id = parseInt(req.params.id, 10);
    const groupIndex = travelData.groupes.findIndex(g => g.groupe === id);

    if (groupIndex !== -1) {
        travelData.groupes.splice(groupIndex, 1);

        travelData.participants.forEach(p => {
            if (p.id_groupe === id) {
                p.id_groupe = null;
            }
        });

        fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));
        res.status(200).json({ message: `Groupe ${id} supprimé avec succès` });
    } else {
        res.status(404).json({ error: 'Groupe non trouvé' });
    }
});

// Parcours possibles
app.get('/parcours', (req, res) => {
    const parcours = travelData.parcours || [];
    res.json(parcours);
});

app.put('/parcours/:id', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const updatedParcours = req.body;

    if (!updatedParcours.date_debut || !updatedParcours.date_fin) {
        return res.status(400).json({ error: "Les champs 'date_debut' et 'date_fin' sont requis" });
    }

    const group = travelData.groupes.find(g => g.groupe === groupId);

    if (!group) {
        return res.status(404).json({ error: 'Groupe non trouvé' });
    }
    const parcours = group.parcours[0]; 

    if (!parcours) {
        return res.status(404).json({ error: 'Parcours non trouvé pour ce groupe' });
    }
    parcours.date_debut = updatedParcours.date_debut;
    parcours.date_fin = updatedParcours.date_fin;

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({
        message: `Parcours du groupe ${groupId} mis à jour avec succès`,
        parcours
    });
});



app.post('/parcours/:id/dest', (req, res) => {
    const groupId = parseInt(req.params.id, 10);
    const { destinationId } = req.body;

    if (!destinationId) {
        return res.status(400).json({ error: "L'attribut 'destinationId' est requis" });
    }

    const group = travelData.groupes.find(g => g.groupe === groupId);
    if (!group) {
        return res.status(404).json({ error: 'Groupe non trouvé' });
    }

    const parcours = group.parcours[0];
    if (!parcours) {
        return res.status(404).json({ error: 'Parcours non trouvé pour ce groupe' });
    }

    const destination = travelData.destinations.find(dest => dest.id === destinationId);
    if (!destination) {
        return res.status(404).json({ error: 'Destination non trouvée' });
    }

    parcours.dest.push(destination);

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(201).json({
        message: `Destination ${destinationId} ajoutée au parcours du groupe ${groupId} avec succès`,
        parcours
    });
});




// Destinations
app.get('/destinations', (req, res) => {
    res.json(travelData.destinations);
});

app.post('/destinations', (req, res) => {
    const newDestination = req.body;
    travelData.destinations.push(newDestination);
    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));
    res.status(201).json(newDestination);
});

app.get('/destinations/:id', (req, res) => {
    const destinationId = parseInt(req.params.id, 10);
    const destination = travelData.destinations.find(dest => dest.id === destinationId);

    if (!destination) {
        return res.status(404).json({ error: 'Destination non trouvée' });
    }

    res.status(200).json(destination);
});

app.put('/destinations/:id', (req, res) => {
    const destinationId = parseInt(req.params.id, 10);
    const updatedDestination = req.body;

    const destinationIndex = travelData.destinations.findIndex(dest => dest.id === destinationId);
    if (destinationIndex === -1) {
        return res.status(404).json({ error: 'Destination non trouvée' });
    }

    travelData.destinations[destinationIndex] = { id: destinationId, ...updatedDestination };

    travelData.groupes.forEach(group => {
        group.parcours.forEach(parcours => {
            parcours.dest.forEach(dest => {
                if (dest.id === destinationId) {
                    dest.dest_city = updatedDestination.dest_city || dest.dest_city;
                    dest.dest_country = updatedDestination.dest_country || dest.dest_country;
                }
            });
        });
    });

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({ message: `Destination ${destinationId} mise à jour avec succès` });
});

app.delete('/destinations/:id', (req, res) => {
    const destinationId = parseInt(req.params.id, 10);

    const destinationIndex = travelData.destinations.findIndex(dest => dest.id === destinationId);
    if (destinationIndex === -1) {
        return res.status(404).json({ error: 'Destination non trouvée' });
    }

    const [removedDestination] = travelData.destinations.splice(destinationIndex, 1);

    travelData.groupes.forEach(group => {
        group.parcours.forEach(parcours => {
            parcours.dest = parcours.dest.filter(dest => dest.id !== destinationId);
        });
    });

    fs.writeFileSync('./travel.json', JSON.stringify(travelData, null, 2));

    res.status(200).json({
        message: `Destination avec l'ID ${destinationId} supprimée avec succès`,
        destination: removedDestination
    });
});




app.listen(port, () => {
    console.log(`Serveur en écoute sur http://localhost:${port}`);
    console.log(`Documentation Swagger disponible sur http://localhost:${port}/api-docs`);
});
