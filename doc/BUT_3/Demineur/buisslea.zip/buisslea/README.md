# README Léane Buisson A11

## Avancée

TP5 avec tentative sur la persistence du TP6

## Fonctionnalités
- Formulaire avec vérification des champs
- Selection d'un niveau de difficultés avec une barre slider
- Grille de jeu
- Score
- Navigation entre les pages

