import 'dart:math';
import 'package:tp02/modele/case.dart';
import 'package:tp02/modele/coup.dart';

/// [Grille] de démineur
class Grille {
  /// Dimension de la grille carrée : [taille]x[taille]
  final int taille;

  /// Nombre de mines présentes dans la grille
  final int nbMines;

  /// Attribut privé (_), liste composée [taille] listes de chacune [taille] cases
  final List<List<Case>> _grille = [];

  /// Construit une [Grille] comportant [taille] lignes, [taille] colonnes et [nbMines] mines
  Grille({required this.taille, required this.nbMines}) {
    int nbCasesACreer = nbCases; // Le nombre de cases qu'il reste à créer
    int nbMinesAPoser = nbMines; // Le nombre de mines qu'il reste à poser
    Random generateur = Random(); // Générateur de nombres aléatoires
    // Pour chaque ligne de la grille
    for (int lig = 0; lig < taille; lig++) {
      // On va ajouter à la grille une nouvelle Ligne (liste de 'cases')
      List<Case> uneLigne = []; //
      for (int col = 0; col < taille; col++) {
        // S'il reste nBMinesAPoser dans nbCasesACreer, la probabilité de miner est nbMinesAPoser/nbCasesACreer
        // Donc on tire un nombre aléatoire a dans [1..nbCasesACreer] et on pose une mine si a <= nbMinesAposer
        bool isMinee = generateur.nextInt(nbCasesACreer) < nbMinesAPoser;
        if (isMinee) nbMinesAPoser--; // une mine de moins à poser
        uneLigne.add(Case(isMinee)); // On ajoute une nouvelle case à la ligne
        nbCasesACreer--; // Une case de moins à créer
      }
      // On ajoute la nouvelle ligne à la grille
      _grille.add(uneLigne);
    }
    // Les cases étant créées et les mines posées, on calcule pour chaque case le 'nombre de mines autour'
    calculeNbMinesAutour();
  }

  /// Getter qui retourne le nombre de cases
  int get nbCases => taille * taille;

  /// Retourne la [Case] de la [Grille] située à [coord]
  Case getCase(Coordonnees coord) {
    return _grille[coord.ligne][coord.colonne];
  }

  /// Retourne la liste des [Coordonnees] des voisines de la case située à [coord]
  List<Coordonnees> getVoisines(Coordonnees coord) {
    List<Coordonnees> listeVoisines = [];
    // A Compléter
    for (int decalageLigne = -1; decalageLigne <= 1; decalageLigne++) {
      for (int decalageColonne = -1; decalageColonne <= 1; decalageColonne++) {
        if (decalageLigne == 0 && decalageColonne == 0) continue;
        int nouvelleLigne = coord.ligne + decalageLigne;
        int nouvelleColonne = coord.colonne + decalageColonne;
        if (nouvelleLigne >= 0 && nouvelleLigne < taille && nouvelleColonne >= 0 && nouvelleColonne < taille) {
          listeVoisines.add((ligne: nouvelleLigne, colonne : nouvelleColonne));
        }
      }
    }
    return listeVoisines;
  }

  /// Assigne à chaque [Case] le nombre de mines présentes dans ses voisines
  void calculeNbMinesAutour() {
  for (int ligne = 0; ligne < taille; ligne++) {
    for (int colonne = 0; colonne < taille; colonne++) {
      Coordonnees coordonnees = (ligne: ligne, colonne: colonne);
      var caseActuelle = getCase(coordonnees);
      if (!caseActuelle.minee) {
        caseActuelle.nbMinesAutour = getVoisines(coordonnees)
            .where((voisine) => getCase(voisine).minee)
            .length;
      }
    }
  }
}


  /// - Découvre récursivement toutes les cases voisines d'une case située à [coord]
  /// - La case située à [coord] doit être découverte
  void decouvrirVoisines(Coordonnees coord) {
    // A Compléter
    Case caseActuelle = getCase(coord);
    if (caseActuelle.etat == Etat.decouverte || caseActuelle.minee || caseActuelle.etat == Etat.marquee) {
      return;
    }
    caseActuelle.decouvrir();
    if (caseActuelle.nbMinesAutour == 0) {
      for (Coordonnees voisine in getVoisines(coord)) {
        if (getCase(voisine).etat != Etat.decouverte && getCase(voisine).etat != Etat.marquee) {
          decouvrirVoisines(voisine);
        }
      }
    }
  }

  /// Met à jour la Grille en fonction du [coup] joué
  void mettreAJour(Coup coup) {
  if (coup.action == Action.decouvrir) {
    // Découvrir la case (et ses voisines si nécessaire)
    getCase(coup.coordonnees).decouvrir();
    
    if (getCase(coup.coordonnees).nbMinesAutour == 0) {
      for (Coordonnees voisine in getVoisines(coup.coordonnees)) {
        if (getCase(voisine).etat != Etat.decouverte && getCase(voisine).etat != Etat.marquee && !getCase(coup.coordonnees).minee) {
          decouvrirVoisines(voisine);
        }
      }
    }
  } else if (coup.action == Action.marquer) {
    // Marquer la case (mettre un drapeau)
    getCase(coup.coordonnees).inverserMarque();
  }
}


  /// Renvoie vrai si [Grille] ne comporte que des cases soit minées soit découvertes (mais pas les 2)
  bool isGagnee() {
    // A Corriger
    for (int ligne = 0; ligne < taille; ligne++) {
      for (int colonne = 0; colonne < taille; colonne++) {
        Case caseCourante = _grille[ligne][colonne];
        if (!caseCourante.minee && caseCourante.etat != Etat.decouverte) {
          return false;
        }
      }
    }
    return true;
  }

  /// Renvoie vrai si [Grille] comporte au moins une case minée et découverte
bool isPerdue() {
  for (int ligne = 0; ligne < taille; ligne++) {
    for (int colonne = 0; colonne < taille; colonne++) {
      Case caseCourante = _grille[ligne][colonne];
      // Si une case minée est découverte, la partie est perdue
      if (caseCourante.minee == true && caseCourante.etat == Etat.decouverte) {
        return true; // Partie perdue
      }
    }
  }
  return false; // Si aucune case minée n'est découverte, la partie n'est pas perdue
}


  /// Renvoie vrai si la partie est finie, gagnée ou perdue
  bool isFinie() {
    // A Corriger
    return isGagnee() || isPerdue();
  }
}
