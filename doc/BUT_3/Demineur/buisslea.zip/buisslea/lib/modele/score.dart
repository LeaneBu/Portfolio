import 'dart:convert';

class Score {
  final String nom;
  final int score;
  final double temps;

  Score({required this.nom, required this.score, required this.temps});

  // Convertir un score en format JSON (String)
  String toJson() {
    final data = {'nom': nom, 'score': score, 'temps': temps};
    return jsonEncode(data);
  }

  // Créer un score depuis une chaîne JSON
  factory Score.fromJson(String jsonString) {
    final Map<String, dynamic> data = jsonDecode(jsonString);
    return Score(
      nom: data['nom'],
      score: data['score'],
      temps: data['temps'],
    );
  }
}
