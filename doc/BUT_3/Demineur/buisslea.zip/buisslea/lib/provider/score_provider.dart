import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tp02/modele/score.dart';

// Classe pour gérer l'état des scores
class ScoreRepository {
  List<Score> scores;

  ScoreRepository({required this.scores});

  // Sauvegarder les scores dans shared_preferences
  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    final scoreList = scores.map((score) => score.toJson()).toList();
    await prefs.setStringList('scores', scoreList);
  }

  // Charger les scores depuis shared_preferences
  static Future<ScoreRepository> load() async {
    final prefs = await SharedPreferences.getInstance();
    final scoreList = prefs.getStringList('scores') ?? [];

    // Vérifier que la liste n'est pas vide
    if (scoreList.isEmpty) {
      return ScoreRepository(scores: []);  // Retourner une instance vide si pas de scores enregistrés
    }

    // Tenter de décoder les scores depuis la liste de chaînes
    final scores = scoreList.map((scoreStr) {
      try {
        return Score.fromJson(scoreStr);
      } catch (e) {
        // Si une erreur se produit lors du décodage, on l'ignore
        print("Erreur de décodage des scores : $e");
        return null;
      }
    }).whereType<Score>().toList();  // Filtrer les valeurs nulles si une erreur de décodage s'est produite

    return ScoreRepository(scores: scores);
  }
}

// Classe pour le Notifier
class ScoreRepositoryNotifier extends StateNotifier<ScoreRepository> {
  // Constructeur du Notifier
  ScoreRepositoryNotifier() : super(ScoreRepository(scores: [])) {
    _loadScores();
  }

  // Méthode asynchrone pour charger les scores
  Future<void> _loadScores() async {
    try {
      final repository = await ScoreRepository.load();
      state = repository;  // Mettre à jour l'état initialement
    } catch (e) {
      print("Erreur de chargement des scores : $e");
      state = ScoreRepository(scores: []); // Assurez-vous que l'état reste valide
    }
  }

  // Ajouter un score à la liste des scores
  void addScore(Score score) {
    // Vérifier si le score existe déjà dans la liste avant d'ajouter
    if (!state.scores.contains(score)) {
      state.scores.add(score);
      state = ScoreRepository(scores: List.from(state.scores)); // Créer une nouvelle instance pour notifier les abonnés
      state.save(); // Sauvegarder les scores dans shared_preferences
    }
  }

  // Supprimer un score de la liste des scores
  void removeScore(Score scoreToRemove) {
    // Vérifier si le score existe avant de le supprimer
    if (state.scores.contains(scoreToRemove)) {
      state.scores.removeWhere((score) => score.nom == scoreToRemove.nom);
      state = ScoreRepository(scores: List.from(state.scores)); // Créer une nouvelle instance pour notifier les abonnés
      state.save(); // Sauvegarder les scores
    }
  }
}


// Provider pour accéder au ScoreRepositoryNotifier
final scoreRepositoryProvider = StateNotifierProvider<ScoreRepositoryNotifier, ScoreRepository>(
  (ref) => ScoreRepositoryNotifier(),
);
