import 'package:flutter/material.dart';
import 'package:tp02/screens/ecran_grille.dart';

class EcranAccueil extends StatefulWidget {
  const EcranAccueil({super.key});

  @override
  _EcranAccueilState createState() => _EcranAccueilState();
}

class _EcranAccueilState extends State<EcranAccueil> {
  final TextEditingController nomController = TextEditingController();
  double difficultySliderValue = 1;
  int taille = 10;
  int nbMines = 15;

  final List<String> difficultyLevels = ['Facile', 'Moyen', 'Difficile', 'Expert'];

  final List<Map<String, int>> difficultySettings = [
    {'taille': 8, 'nbMines': 10},  // facile
    {'taille': 10, 'nbMines': 15},  // moyen
    {'taille': 12, 'nbMines': 20},  // difficile
    {'taille': 15, 'nbMines': 30},  // expert
  ];

  void lancerPartie() {
    String nomJoueur = nomController.text.isNotEmpty ? nomController.text : "";

    if (nomJoueur.isEmpty) {
      _showNomVideDialog();
      return;
    }

    int selectedDifficulty = difficultySliderValue.toInt();
    taille = difficultySettings[selectedDifficulty]['taille']!;
    nbMines = difficultySettings[selectedDifficulty]['nbMines']!;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EcranGrille(
          taille: taille,
          nbMines: nbMines,
          nomJoueur: nomJoueur, 
        ),
      ),
    );
  }

  void _showNomVideDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Nom manquant'),
          content: const Text('Veuillez entrer votre pseudo pour démarrer la partie.'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Accueil - Démineur")),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              "Bienvenue dans le Démineur !",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nomController,
              decoration: const InputDecoration(
                labelText: "Votre nom",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Choisissez la difficulté"),
                Slider(
                  value: difficultySliderValue,
                  min: 0,
                  max: 3,
                  divisions: 3,
                  label: difficultyLevels[difficultySliderValue.toInt()],
                  onChanged: (value) {
                    setState(() {
                      difficultySliderValue = value;
                    });
                  },
                ),
                Text(
                  "Difficulté: ${difficultyLevels[difficultySliderValue.toInt()]}",
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: lancerPartie,
              child: const Text("Démarrer la partie"),
            ),
          ],
        ),
      ),
    );
  }
}
