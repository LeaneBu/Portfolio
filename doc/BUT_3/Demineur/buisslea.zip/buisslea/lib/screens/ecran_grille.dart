import 'package:flutter/material.dart';
import 'package:tp02/screens/ecran_score.dart';
import 'package:tp02/widgets/grille_demineur.dart';

class EcranGrille extends StatefulWidget {
  final String nomJoueur;
  final int taille;
  final int nbMines;

  const EcranGrille({
    required this.nomJoueur,
    required this.taille,
    required this.nbMines,
    super.key,
  });

  @override
  _EcranGrilleState createState() => _EcranGrilleState();
}

class _EcranGrilleState extends State<EcranGrille> {
  late DateTime startTime;
  int score = 0;
  double tempsEcoule = 0.0;
  bool partieTerminee = false;
  bool victoire = false;

  @override
  void initState() {
    super.initState();
    startTime = DateTime.now();
  }

  void onGameEnd(bool gagne) {
    setState(() {
      partieTerminee = true;
      victoire = gagne;
    });

    tempsEcoule = DateTime.now().difference(startTime).inSeconds.toDouble();
  }

  void onScoreUpdated(int updatedScore) {
    setState(() {
      score = updatedScore;
    });
  }

  void allerVersScore() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EcranScore(
          nom: widget.nomJoueur,
          score: score,
          temps: tempsEcoule,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Jeu du Démineur")),
      body: Column(
        children: [
          Expanded(
            child: GrilleDemineur(
              taille: widget.taille,
              nbMines: widget.nbMines,
              onGameUpdate: () => setState(() {}),
              onGameEnd: onGameEnd,
              onScoreUpdated: onScoreUpdated,
            ),
          ),
          if (partieTerminee)
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: ElevatedButton(
                onPressed: allerVersScore,
                child: const Text("Voir le Score"),
              ),
            ),
        ],
      ),
    );
  }
}
