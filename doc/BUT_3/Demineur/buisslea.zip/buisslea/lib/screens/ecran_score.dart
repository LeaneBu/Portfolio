import 'package:flutter/material.dart';

class EcranScore extends StatelessWidget {
  final String nom;
  final int score;
  final double temps;

  const EcranScore({
    required this.nom,
    required this.score,
    required this.temps,
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Score final")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Bravo $nom !",
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text("Score : $score", style: const TextStyle(fontSize: 20)),
            Text("Temps : ${temps.toStringAsFixed(1)}s", style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.popUntil(context, (route) => route.isFirst);
              },
              child: const Text("Rejouer"),
            ),
          ],
        ),
      ),
    );
  }
}
