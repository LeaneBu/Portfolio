import 'package:flutter/material.dart';
import 'package:tp02/modele/grille.dart' as modele;
import 'package:tp02/modele/case.dart' as modele;
import 'package:tp02/modele/coup.dart' as modele;

class GrilleDemineur extends StatefulWidget {
  final int taille, nbMines;
  final void Function() onGameUpdate;
  final void Function(bool victoire) onGameEnd;
  final void Function(int score) onScoreUpdated;

  const GrilleDemineur({
    required this.taille,
    required this.nbMines,
    required this.onGameUpdate,
    required this.onGameEnd,
    required this.onScoreUpdated,
    super.key,
  });

  @override
  State<GrilleDemineur> createState() => _GrilleDemineurState();
}

class _GrilleDemineurState extends State<GrilleDemineur> {
  late modele.Grille grille;
  bool partieTerminee = false;

  @override
  void initState() {
    super.initState();
    grille = modele.Grille(taille: widget.taille, nbMines: widget.nbMines);
  }

  void jouerCoup(int ligne, int colonne, bool marquer) {
    setState(() {
      final coup = modele.Coup(ligne, colonne, marquer ? modele.Action.marquer : modele.Action.decouvrir);
      grille.mettreAJour(coup);
    });

    widget.onGameUpdate();

    if (grille.isFinie() && !partieTerminee) {
      setState(() {
        partieTerminee = true;
      });
      widget.onGameEnd(grille.isGagnee());
      
      int score = calculerScore();
      widget.onScoreUpdated(score);
    }
  }

  int calculerScore() {
    int nbCasesDecouvertes = 0;

    for (int i = 0; i < widget.taille; i++) {
      for (int j = 0; j < widget.taille; j++) {
        final caseActuelle = grille.getCase((ligne: i, colonne: j));
        if (caseActuelle.etat == modele.Etat.decouverte) {
          nbCasesDecouvertes++;
        }
      }
    }

    int score = nbCasesDecouvertes * 10;
    return score;
  }

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;
    double screenHeight = MediaQuery.of(context).size.height * 0.7;
    double gridSize = screenWidth < screenHeight ? screenWidth : screenHeight;
    double caseSize = gridSize / widget.taille;

return Scaffold(
  appBar: AppBar(
    title: const Text('Jeu de grille'),
  ),
  body: Center(
    child: Container(
      width: gridSize,
      height: gridSize,
      child: GridView.builder(
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: widget.taille,
          childAspectRatio: 1,
          crossAxisSpacing: 1,
          mainAxisSpacing: 1,
        ),
        itemCount: widget.taille * widget.taille,
        itemBuilder: (context, index) {
          int ligne = index ~/ widget.taille;
          int colonne = index % widget.taille;
          final caseActuelle = grille.getCase((ligne: ligne, colonne: colonne));

          return GestureDetector(
            onTap: () => jouerCoup(ligne, colonne, false),
            onDoubleTap: () => jouerCoup(ligne, colonne, true),
            child: Container(
              width: caseSize,
              height: caseSize,
              decoration: BoxDecoration(
                color: caseToColor(caseActuelle),
              ),
              child: Center(
                child: Text(
                  caseToText(caseActuelle, grille.isFinie()),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          );
        },
      ),
    ),
  ),
);

  }

  String caseToText(modele.Case laCase, bool isFini) {
    if (isFini) {
      if (laCase.minee) return "💣";
      return laCase.nbMinesAutour > 0 ? "${laCase.nbMinesAutour}" : "";
    }
    if (laCase.etat == modele.Etat.marquee) return "🚩";
    if (laCase.etat == modele.Etat.decouverte) return laCase.nbMinesAutour > 0 ? "${laCase.nbMinesAutour}" : "";
    return "";
  }

  Color caseToColor(modele.Case laCase) {
    if (laCase.etat == modele.Etat.couverte) return const Color.fromARGB(185, 74, 163, 161);
    if (laCase.etat == modele.Etat.marquee) return const Color.fromARGB(255, 232, 170, 190);
    return laCase.minee ? const Color.fromARGB(255, 202, 60, 103) : Color.fromARGB(255, 167, 224, 224);
  }
}
