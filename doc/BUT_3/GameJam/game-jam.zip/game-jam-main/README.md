# Start the game

Executer la commande 
```
pip install -r requirements.txt
```

puis lancer le jeu avec 
```
python3 client/main.py
```
 
pour jouer tout seule cliquer sur start

et une fois dans le lobby appuyer sur retour chariot

pour rejoindre le premier joueur cliquer sur join 
et entrer l'ip affcihée dans le lobby du premier joueur