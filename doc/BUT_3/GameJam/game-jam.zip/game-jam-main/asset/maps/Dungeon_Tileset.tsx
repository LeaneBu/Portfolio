<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Dungeon_Tileset" tilewidth="32" tileheight="32" tilecount="320" columns="16">
 <image source="Dungeon_Tileset.png" width="512" height="640"/>
</tileset>
