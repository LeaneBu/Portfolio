<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="Interiors_free_32x32" tilewidth="32" tileheight="32" tilecount="1424" columns="16">
 <image source="Interiors_free_32x32.png" width="512" height="2848"/>
</tileset>
