import pygame
from camera import Camera

class Animation :

    all_animation = []

    vfx_animation = []

    def __init__(self, spritesheet : pygame.Surface, nb_of_frame = 5 , scale = 1, yIndex = 0,tile_width : int = 16, tile_height : int = 16, is_VFX = False, position_vfx_tuple=0) :
        self.sprite_sheet = spritesheet
        self.tile_width = tile_width
        self.tile_height = tile_height
        self.scale = scale
        self.current_frame = 0
        self.yIndex = yIndex
        self.number_of_frame = nb_of_frame
        self.clock = pygame.time.get_ticks()
        self.isActive = True
        self.speed = self.number_of_frame*1.5
        self.position_vfx_tuple = position_vfx_tuple

        self.is_vfx = is_VFX

        Animation.all_animation.append(self) if not is_VFX else Animation.vfx_animation.append(self)

    def get_specific_frame(self, frame_index=0) :
        image = pygame.Surface((self.tile_width, self.tile_height), pygame.SRCALPHA)
        image.blit(self.sprite_sheet.convert_alpha(), (0,0), (frame_index*self.tile_width, self.yIndex*self.tile_height, self.tile_width, self.tile_height))
        image = pygame.transform.scale(image, (self.tile_width * self.scale, self.tile_height * self.scale))
        return image
    
    def get_current_frame(self) : 
        return self.get_specific_frame(self.current_frame)
    

    def stop(self) :
        self.isActive = False

    def play(self) :
        self.isActive = True

    @staticmethod
    def update() :
        my_anime_list = Animation.all_animation.copy()
        my_anime_list.extend(Animation.vfx_animation)
        for anim in my_anime_list :
            if anim.isActive == False : return 

            if pygame.time.get_ticks() >= anim.clock + (1000/anim.speed):
                anim.clock = pygame.time.get_ticks()
                anim.current_frame += 1

                if anim.is_vfx and anim.current_frame >= anim.number_of_frame :
                    Animation.vfx_animation.remove(anim)

                anim.current_frame = anim.current_frame % anim.number_of_frame

    @staticmethod
    def draw_vfx(screen : pygame.Surface) :
        for anim in Animation.vfx_animation :
            screen.blit( anim.get_current_frame(), (int(anim.position_vfx_tuple[0] - Camera.posX), int(anim.position_vfx_tuple[1] - Camera.posY)) )