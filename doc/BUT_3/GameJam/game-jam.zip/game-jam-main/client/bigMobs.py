from random import randint

import pygame

from animation import Animation
from difficultyHandler import DifficultyHandler
from imageLoaded import ImageLoaded
from entity import Entity
from weapons import *
from camera import Camera


class Boss1(Entity):

    def __init__(self, listPlayers):
        Entity.__init__(self, 0, 0, 3)

        self.listPlayers = listPlayers

        self.team = "mobs"
        self.name = ("Fantôme Antique")

        self.base_scale = 1
        self.scale = self.base_scale + int(DifficultyHandler.indice_difficulty / 15)

        self.animation: Animation = Animation(ImageLoaded.boss_sprite, 1, self.scale, tile_width=226, tile_height=317)
        self.frame = ImageLoaded.ennemy_sprite

        self.height = self.animation.tile_height * self.scale - 1
        self.width = self.animation.tile_width * self.scale - 1

        self.collider = pygame.Rect(self.position.x, self.position.y, self.width, self.height)


        self.pvMax = 10000 * DifficultyHandler.indice_difficulty
        self.pv = self.pvMax
        self.team = "mobs"

        self.enemyCible = self.getAnEnemy()

        self.cooldown = 200

        self.tempsChangerDeCible = 400
        self.attaqueEnCours = "fusil"
        self.tirsNormaux()
        self.tempsRestantAttaqueEnCours = 500
        self.canShot = True

        self.nbDeVaguesPossibles = 4
        self.vagueEnCours = 1

        self.phase = 1

    def changementDePhase(self):
        self.phase += 1

    def getAnEnemy(self):
        player = self.listPlayers[randint(0, len(self.listPlayers) - 1)]
        while not player.isAlive:
            player = self.listPlayers[randint(0, len(self.listPlayers) - 1)]
        return player

    def getMovement(self):
        dx = 0
        dy = 0
        if (self.position.x < self.enemyCible.position.x):
            dx += 1
            self.direction = 1
        if (self.position.x > self.enemyCible.position.x):
            dx -= 1
            self.direction = 2
        if (self.position.y < self.enemyCible.position.y):
            dy += 1
            self.direction = 3
        if (self.position.y > self.enemyCible.position.y):
            dy -= 1
            self.direction = 4
        return dx, dy

    def tirsNormaux(self):
        self.changerDarme("fusil")
        self.isMovable = True
        self.tempsRestantAttaqueEnCours = 400

        self.weapon.color = "#bfced6"
        self.weapon.height *= 3
        self.weapon.width *= 3
        self.weapon.lifeTime *= 3
        self.weapon.quickness *= 3
        self.weapon.damage = 15 * DifficultyHandler.valeurDeDifficulte


    def vagueDenergie(self):
        self.changerDarme("sonar")
        self.isMovable = False
        self.tempsRestantAttaqueEnCours = 100

        Camera.shake(duration=17, strenght=25)

        self.position.x, self.position.y = 1090, 786
        self.collider.update(self.position.x, self.position.y, self.width, self.height)


        self.weapon.damage = 0.5  * DifficultyHandler.valeurDeDifficulte

    def vagueTriangle(self):
        self.changerDarme("pompe")
        self.isMovable = True
        self.speed = 1.5
        self.tempsRestantAttaqueEnCours = 300

        self.weapon.lifeTime = 100
        self.weapon.cooldown = 5
        self.weapon.damage = 1.5
        self.weapon.damage = self.weapon.damage * DifficultyHandler.valeurDeDifficulte

    def traineeBlessante(self):
        self.changerDarme("trainee")
        self.isMovable = True
        self.speed = 7
        self.tempsRestantAttaqueEnCours = 300

        self.weapon.lifeTime *= 4
        self.weapon.damage = self.weapon.damage * DifficultyHandler.valeurDeDifficulte

    def changerLaVague(self):

        self.speed = 3

        valeur = randint(1, self.nbDeVaguesPossibles)
        while valeur == self.vagueEnCours:
            valeur = randint(1, self.nbDeVaguesPossibles)

        match valeur:
            case 1:
                self.tirsNormaux()

            case 2:
                self.vagueDenergie()

            case 3:
                self.vagueTriangle()

            case 4:
                self.traineeBlessante()

    def changerDarme(self, arme):
        match arme:
            case "fusil":
                self.weapon = Fusil()

            case "sonar":
                self.weapon = Sonar()

            case "pompe":
                self.weapon = Pompe()

            case "trainee":
                self.weapon = Trainee()

    def update(self, dt, listAll):
        if self.pv > self.pvMax / 3 * self.phase :
            self.changementDePhase()

        self.cooldown = max(self.cooldown - 1/dt, 0)

        self.tempsChangerDeCible = max(self.tempsChangerDeCible - 1/dt, 0)
        if self.tempsChangerDeCible == 0:
            self.getAnEnemy()
            self.tempsChangerDeCible = 400

        self.tempsRestantAttaqueEnCours =  max(self.tempsRestantAttaqueEnCours - 1/dt, 0)

        if self.tempsRestantAttaqueEnCours == 0:
            self.changerLaVague()

        self.shot((self.enemyCible.position.x + self.enemyCible.width / 2,
                   self.enemyCible.position.y + self.enemyCible.height / 2))

        if(self.isMovable):
            self.getMove(dt, listAll)

        # for bullet in self.bullets:
        #     if bullet.getLifeTime() < 0:
        #         self.bullets.remove(bullet)
        # else:
        #     bullet.move(listAll, dt)

    def getMove(self, dt, listAll):
        self.cooldown = max(self.cooldown - 1 / dt, 0)

        dx, dy = self.getMovement()

        self.orientation = pygame.math.Vector2(dx, dy)

        collision = self.collision(listAll, dt)

        match collision:
            case(True, True):
                self.orientation = pygame.math.Vector2(0, 0)

            case(False, True):
                self.orientation = pygame.math.Vector2(dx, 0)

            case(True, False):
                self.orientation = pygame.math.Vector2(0, dy)

            case(False, False):
                pass

        if dx != 0 and dy != 0:
            self.orientation /= 1.41421

        self.move(dt)

        self.collider.update(self.position.x, self.position.y, self.width, self.height)

    def shot(self, positionEnemy):
        if self.cooldown < 1:
            xEnemy, yEnemy = positionEnemy
            xPos = self.position.x
            yPos = self.position.y
            vecteur = (xEnemy - xPos, yEnemy - yPos)

            position = pygame.Vector2(self.position.x + self.width / 2, self.position.y + self.height / 2)
            bulletsShot = self.weapon.shot(position, vecteur, self.team)
            for bullet in bulletsShot:
                self.bullets.append(bullet)

            self.cooldown = self.weapon.getCooldown()

    def add_bullet(self, bullet):
        self.bullets.append(bullet)

    #RESEAU
    def to_dict(self):
        return {
            "x": self.position.x,
            "y": self.position.y,
            "pv": self.pv,
            "team": self.team,
            "bullets": [bullet.to_dict() for bullet in self.bullets], 
            "weapon": self.weapon.getName()
        }

    @classmethod
    def from_dict(cls, data):
        # Créer une instance vide de Player
        player = cls()
        # Réinitialiser les attributs en fonction des données reçues
        player.id = data["id"]
        player.position.x = data["x"]
        player.position.y = data["y"]
        player.width = data["width"]
        player.height = data["height"]
        player.pv = data["pv"]
        player.pvMax = data["pvMax"]
        player.team = data["team"]
        player.direction = data["direction"]
        player.cooldown = data["cooldown"]
        #player.weapon = data["weapon"]

        # Recréer les projectiles à partir des données reçues
        #player.bullets = [Bullets.from_dict(bullet_data,get_weapon_by_name(player.weapon)) for bullet_data in data["bullets"]]

        return player