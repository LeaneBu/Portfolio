import math
import pygame
from camera import Camera

# from entityManager import EntityManager

class Bullets(pygame.sprite.Sprite):

    def __init__(self, position, vecteur, weapon, team = "players"):
        pygame.sprite.Sprite.__init__(self)
        height = weapon.height
        width = weapon.width

        self.position : pygame.Vector2 = pygame.Vector2(position.x, position.y)

        self.image = pygame.Surface([width, height])

        self.collider : pygame.Rect = pygame.Rect((0,0), (0,0))

        self.rect = self.image.get_rect()
        self.rect.update(self.position.x - self.rect.width/2, self.position.y-self.rect.height/2, self.rect.width, self.rect.height)

        self.weapon = weapon
        self.team = team
        self.image.fill(self.weapon.getColor())

        self.lifeTime = self.weapon.getLifeTime()
        self.damage = self.weapon.getDamage()

        self.angleDeTir = math.atan2(vecteur[1], vecteur[0])

        self.dx = math.cos(self.angleDeTir)
        self.dy = math.sin(self.angleDeTir) 
        #1 = right, 2 = left, 3 = bottom, 4 = up

        if(team == "players") :
            sound = pygame.mixer.Sound('asset/music/shoot.mp3')
            pygame.mixer.Sound.set_volume(sound, 0.05)
            sound.play()

    def update(self, listEntity, listObject,dt):

        self.position.x += self.dx * dt * self.weapon.quickness 
        self.position.y += self.dy * dt * self.weapon.quickness  

        self.lifeTime -= dt

        self.collider = pygame.Rect(self.position.x, self.position.y, self.rect.width, self.rect.height)

        for obj in listObject : 
            if self.collider.colliderect(obj.collider) :
                self.lifeTime = 0

        for entity in listEntity:
            if entity.getTeam() == self.team :
                continue
            if self.collider.colliderect(entity.collider):
                    entity.takeDamage(self.damage)
                    self.lifeTime = 0
                    self.rect.update(0, 0, 0, 0)

    def getLifeTime(self):
        return self.lifeTime

    def draw(self,screen):
        if self.lifeTime > 0:
            if (self.position.x > Camera.posX and self.position.x < Camera.posX + screen.get_width()) and (self.position.y > Camera.posY and self.position.y < Camera.posY + screen.get_width() ) :
                screen.blit(self.image, (self.position.x - Camera.posX, self.position.y - Camera.posY))

    

    def to_dict(self):
        return {
            "x": self.position.x,
            "y": self.position.y,
            "weapon": self.weapon.getName(),
            "team": self.team, 
            "lifeTime": self.lifeTime
        }

    @staticmethod
    def from_dict(data, weapon):
        # Récupère les informations du dictionnaire
       
        bullet = Bullets(pygame.Vector2(data['x'],data['x']), (0,0), weapon, data['team'])
        bullet.lifeTime = data['lifeTime']

        return bullet