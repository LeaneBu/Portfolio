import pygame
import random

class Camera :

    posX = 0
    posY = 0

    baseDurationShake = 0.150
    baseRandomnessShake = 15

    shakeDuration = 0.5
    clock = -shakeDuration * 1000
    randomness = 15

    def __init__ (self) :
        None
    
    @staticmethod
    def center_on_entity(player , screen : pygame.Surface) :
        offsetShake = pygame.Vector2(0,0)

        if (pygame.time.get_ticks() < Camera.clock + Camera.shakeDuration *1000) :
            offsetShake.x = random.randint(-Camera.randomness, Camera.randomness)
            offsetShake.y = random.randint(-Camera.randomness, Camera.randomness)

        Camera.posX = (player.position.x - screen.get_width()/2) + offsetShake.x
        Camera.posY = (player.position.y - screen.get_height()/2) + offsetShake.y
        
    @staticmethod
    def shake(duration= -1, strenght= -1):
        if duration > 0 :
            Camera.shakeDuration = duration
        else :
            Camera.shakeDuration = Camera.baseDurationShake
            
        if strenght > 0 :
            Camera.randomness = strenght
        else :
            Camera.randomness = Camera.baseRandomnessShake
        
        Camera.clock = pygame.time.get_ticks()