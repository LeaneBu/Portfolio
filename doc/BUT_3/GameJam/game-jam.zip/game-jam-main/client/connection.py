
from player import Player
from network import Network
import socket


#script pour avoir son adresse ip local
def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0)
    try:
        # n a même pas besoin d'être joignable
        s.connect(('10.254.254.254', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP



def launch_game_connection(isHost, ip ):
    if ip == "":
        ip = get_ip()

    if isHost:

        #execute une fonction pour retourner son adresse ip local

        port = 5555

        n = Network(ip, port)

        n.start_server()
        
    else :
        #le port par défault pour rejoindre une game est le port 55555
        port = 5555
        n = Network(ip,port)


    player = Player()
    #envoie du joueur au client pour sa première connexion
    id_player = n.connect(player)

    #set l'id du joueur 
    n.id_player = id_player

    print(f"Ton id player est {id_player}")


    return n



