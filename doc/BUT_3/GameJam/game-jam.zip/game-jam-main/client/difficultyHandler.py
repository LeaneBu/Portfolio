
import pygame

class DifficultyHandler:

    indice_difficulty = 0
    timeBegin = pygame.time.get_ticks()
    container_image = pygame.Surface((350, 50))
    image = pygame.image.load("./asset/difficultybarre.png")
    x = 0
    offset = 0
    clock = pygame.time.get_ticks()

    valeurDeDifficulte = 1
        
    @staticmethod
    def update() :
        DifficultyHandler.x = (pygame.time.get_ticks() - DifficultyHandler.timeBegin) / (1000 * 60)
        DifficultyHandler.indice_difficulty = (DifficultyHandler.x * DifficultyHandler.x) / 15 + 1
        return

    @staticmethod
    def draw(screen : pygame.Surface) :
        DifficultyHandler.container_image.blit( DifficultyHandler.image.convert(), (0,0), ((
                                                    pygame.time.get_ticks() - DifficultyHandler.timeBegin) * ( (DifficultyHandler.image.get_width() - DifficultyHandler.container_image.get_width()) / (1000*60*10) ), 0, 350, 50
                                                ))
        screen.blit(DifficultyHandler.container_image, (1450,100))
    
    @staticmethod
    def spawnMob() :
        if (pygame.time.get_ticks() - DifficultyHandler.clock) > 10 * 1000 :
            DifficultyHandler.clock = pygame.time.get_ticks()
            return True
        return False