import pygame

from camera import Camera
from weapons import *
from animation import Animation
import math

class Entity(pygame.sprite.Sprite):

    def __init__(self, x, y, speed):
        pygame.sprite.Sprite.__init__(self)
        self.team = None
        self.base_scale = 1
        self.scale = 1
        self.direction = 1
        self.orientation = pygame.math.Vector2()
        # 1 = right, 2 = left, 3 = bottom, 4 = up

        self.weapon = Weapon()
        self.cooldown = 0
        self.pvMax = 100
        self.pv = 100

        self.collider :pygame.Rect = pygame.Rect((0,0), (0,0))

        self.animation : Animation
        self.frame : pygame.Surface

        self.speed = speed

        self.position = pygame.Vector2(x,y)

        self.bullets = []

        self.isMovable = True
        self.isAlive = True

        self.rect = pygame.Rect((0,0), (0,0))

    def move(self, dt):
        if not self.isMovable :
            return

        self.position += self.orientation * dt * self.speed

    def draw(self,screen):

        frame = self.animation.get_current_frame()

        if (self.position.x + frame.get_width() > Camera.posX and self.position.x< Camera.posX + screen.get_width()) and (self.position.y + frame.get_height() > Camera.posY and self.position.y < Camera.posY + screen.get_width() ) :
            
            screen.blit( pygame.transform.flip(frame, (self.orientation.x < 0),False ), (self.position.x - Camera.posX, self.position.y - Camera.posY) )

        for bullet in self.bullets:
            bullet.draw(screen)

    def getTopLeft(self):
        return self.rect.topleft

    def getTeam(self):
        return self.team

    def getPV(self):
        return self.pv

    def getIsAlive(self):
        return self.isAlive

    def setIsAlive(self, state):
        self.isAlive = state
        if state == False:
            self.deleteEntity()
    
    def updateBullet(self, listEntity, listObject,dt) :
        for bullet in self.bullets:
                if bullet.getLifeTime() < 0:
                    self.bullets.remove(bullet)
                else :
                    bullet.update(listEntity, listObject,dt)

    def deleteEntity(self):
        self.rect.update(0, 0, 0, 0)

    def takeDamage(self, damage):
        if(self.team == "players"):
            damage *= self.boost
        self.pv -= damage

    def collision(self, listEntity, dt):
        retCollision = False, False  # Variable de retour

        for entity in listEntity:

            self.collider.update(self.position.x + self.orientation.x*dt*self.speed,
                                 self.position.y + self.orientation.y*dt*self.speed,
                                 self.width, self.height)

            if self.collider.colliderect(entity.collider) and not(entity == self):

                self.collider.update(self.position.x - self.orientation.x*dt*self.speed,
                                     self.position.y - self.orientation.y*dt*self.speed,
                                     self.width, self.height)

                #Teams Adverses = dégats
                if entity.getTeam() != self.team and entity.getTeam() != "objet":
                    entity.takeDamage(1)
                    self.pv -= 1

                #Collision en X
                self.collider.update(self.position.x + self.orientation.x * dt * self.speed,
                                     self.position.y, self.width, self.height)

                if self.collider.colliderect(entity.collider):
                    retCollision = True, retCollision[1]
                # Annulation en X
                self.collider.update(self.position.x - self.orientation.x * dt * self.speed,
                                     self.position.y, self.width, self.height)

                # Collision en Y
                self.collider.update(self.position.x,
                                     self.position.y + self.orientation.y * dt * self.speed,
                                     self.width, self.height)

                if self.collider.colliderect(entity.collider):
                    retCollision = retCollision[0], True
                # Annulation en Y
                self.collider.update(self.position.x,
                                     self.position.y - self.orientation.y * dt * self.speed,
                                     self.width, self.height)

            else :
                self.collider.update(self.position.x - self.orientation.x*dt*self.speed,
                                     self.position.y - self.orientation.y*dt*self.speed,
                                     self.width, self.height)

        return retCollision