from random import randint

import pygame

from bigMobs import Boss1
from gestionLobby import GestionLobby
from objet import Objet
from utils import random_of_ranges
from difficultyHandler import DifficultyHandler
from mobs import Mobs
from player import Player
import random
from bullets import Bullets
from weapons import get_weapon_by_name

from animation import Animation
from imageLoaded import ImageLoaded
# from entity import Entity

class EntityManager:

    
    def __init__(self, screen, isHost = False):
        self.players = []
        self.entities = []
        self.mobs = []
        self.pantins = []
        self.objets = []
        self.boostMobs = 1
        self.network = None
        self.isHost = isHost
        self.boss = None

        self.bossTime = False
        self.bossIsSpawn = False
        self.cooldown = 50

        self.gestionLobby = GestionLobby(screen)

        self.partieFinie = False
        self.victoire = False

    def load(self):
        self.addPantin()
        self.addPlayer(True, self.network.id_player)

    def update(self, dt, modeDeJeu):
        if modeDeJeu == "lobby":
            for player in self.players:
                player.pv = 100
            keys = pygame.key.get_pressed()
            if keys[pygame.K_RETURN]: #self.gestionLobby.verifLancement(self.players):
                return "antiquite"
        else:

            if self.players[0].soulSaved >= 30 and self.bossTime == False:

                pygame.mixer_music.unload()
                pygame.mixer.music.load("./asset/music/BossMusic.mp3")
                pygame.mixer_music.play()
                self.bossTime = True


            if (self.isHost and DifficultyHandler.spawnMob() and not self.bossTime):
                for i in range(int(DifficultyHandler.indice_difficulty * 5)):
                    self.addMob()

            if self.isHost and self.bossTime and not self.bossIsSpawn:
                self.addBoss()
                self.bossIsSpawn = True

            isDefeat = True
            for player in self.players:
                if player.isAlive:
                    isDefeat = False
            if isDefeat:
                self.partieFinie = True


        listCollision = self.objets.copy()
        listCollision.extend(self.entities)


        for i in range(len(listCollision) - 1) :

            if isinstance(listCollision[len(listCollision) - 1], Objet) :
                break

            theNewOneEntity = listCollision[ len(listCollision) - 1 ]

            if  theNewOneEntity.getPV() <= 0 :
                theNewOneEntity.setIsAlive(False)


                if isinstance(theNewOneEntity, Mobs) :

                    Animation(ImageLoaded.vfx63 , nb_of_frame=7, scale=2, yIndex=randint(0,8),tile_width=64, tile_height=64 ,position_vfx_tuple=(theNewOneEntity.position.x, theNewOneEntity.position.y) , is_VFX=True)
                    pygame.mixer.Sound("./asset/music/mobDeath.mp3").play()

                    self.mobs.remove(theNewOneEntity)
                    self.entities.remove(theNewOneEntity)
                    listCollision.remove(theNewOneEntity)
                    if self.isHost:
                        self.players[0].soulSaved += 1
                elif isinstance(theNewOneEntity, Boss1) :
                    self.partieFinie = True
                    self.victoire = True

                continue

            theNewOneEntity.update(dt, listCollision)
            if self.isHost and isinstance(theNewOneEntity, Mobs):
                theNewOneEntity.shot( (theNewOneEntity.enemyCible.position.x+theNewOneEntity.enemyCible.width/2, theNewOneEntity.enemyCible.position.y+theNewOneEntity.enemyCible.height/2))
            theNewOneEntity.updateBullet(self.entities, self.objets ,dt)

            listCollision.pop()
            i+=1

        dataToSend = {}
        dataToSend['players'] = self.players[0].to_dict()
        if self.isHost:
            dataToSend['mobs'] = []
            for i in range(len(self.mobs)):
                if isinstance(self.mobs[i], Mobs):
                    dataToSend['mobs'].append(self.mobs[i].to_dict())
            dataToSend["boss"] = {}
            if self.bossIsSpawn:
                dataToSend["boss"] = self.boss.to_dict()

        data = self.network.exchange_with_server(dataToSend)
        if len(data) > 0:
            playerData = data['players']

            if not self.isHost:
                self.players[0].soulSaved = playerData[0]["soulSaved"]
            
            i = 1
            j = 0
            for player in playerData:
                if player["pv"] <= 0:
                    self.players[i].isAlive = False
                if len(playerData) > len(self.players) -1:
                    self.addPlayer(id_player=playerData[-1]["id"])
                self.players[i].position.x = player["x"]
                self.players[i].position.y = player["y"]
                self.players[i].weapon = get_weapon_by_name(player["weapon"])
                for bullet in player["bullets"]:
                    if len(self.players[i].bullets) <= j:
                        weapon = get_weapon_by_name(bullet["weapon"])
                        self.players[i].add_bullet(Bullets.from_dict(bullet, weapon = weapon))

                    self.players[i].bullets[j].position.x = bullet["x"]
                    self.players[i].bullets[j].position.y = bullet["y"]

                    j += 1
                j = 0
                i += 1

            if not self.isHost:
                modData = data['mobs']
                i = 0
                j = 0
                for mob in modData:
                    if i >= len(self.mobs):
                        self.addMob()
                        self.mobs[i].weapon = get_weapon_by_name(mob["weapon"])
                    self.mobs[i].position.x = mob["x"]
                    self.mobs[i].position.y = mob["y"]

                    for bullet in mob["bullets"]:
                        if len(self.mobs[i].bullets) <= j:
                            weapon = get_weapon_by_name(bullet["weapon"])
                            weapon.damage *= DifficultyHandler.indice_difficulty
                            self.mobs[i].add_bullet(Bullets.from_dict(bullet, weapon = weapon))

                        self.mobs[i].bullets[j].position.x = bullet["x"]
                        self.mobs[i].bullets[j].position.y = bullet["y"]
                        j += 1

                    j = 0

                    i += 1

                bossData = data['boss']
                if bossData and not self.bossIsSpawn:
                    self.addBoss()
                    self.bossIsSpawn = True
                if self.bossIsSpawn:
                    self.boss.position.x = bossData["x"]
                    self.boss.position.y = bossData["y"]
                    j = 0
                    for bullet in bossData["bullets"]:
                            if len(self.boss.bullets) <= j:
                                weapon = get_weapon_by_name(bullet["weapon"])
                                self.boss.add_bullet(Bullets.from_dict(bullet, weapon = weapon))

                            self.boss.bullets[j].position.x = bullet["x"]
                            self.boss.bullets[j].position.y = bullet["y"]
                            j += 1




    def set_players(self, list_players):
        self.players = list_players

    def draw(self, screen, modeDeJeu):
        for oneEntity in self.entities:
            if oneEntity.getIsAlive():
                oneEntity.draw(screen)
        if modeDeJeu == "lobby":
            for pantin in self.pantins:
                pantin.draw(screen)
            self.gestionLobby.drawIP()
        else :
            screen.blit(pygame.font.Font(None, 50).render("Soul saved : " + str(self.players[0].soulSaved), True, "White"), (900,900))
            screen.blit(pygame.font.Font(None, 50).render("Sanity : " + str(self.players[0].pv), True, "White"), (0,0))

        

    def addPlayer(self, mainPlayer = False, id_player=0):
        player = Player(mainPlayer=mainPlayer, id=id_player)
        self.players.append(player)
        self.entities.append(player)
        player.position.x, player.position.y = 1190, 886

    def addPlayerExterieur(self):
        player = Player()
        self.players.append(player)
        self.entities.append(player)

    def addMob(self):
        mob = Mobs(self.players)
        min_min = int(256 + mob.width )
        min_max = int(384 + mob.width )
        max_min = int(3456 - mob.width )
        max_max = int(3584 - mob.width )

        mob.position.x , mob.position.y = random.choice([(random.choice(list(range(min_min, max_max))), random.choice(list(range(min_min, min_max)))),
                                                          (random.choice(list(range(max_min, max_max))), random.choice(list(range(min_min, max_max)))),
                                                          (random.choice(list(range(min_min, min_max))), random.choice(list(range(min_min, max_max)))),
                                                          (random.choice(list(range(min_min, max_max))), random.choice(list(range(max_min, max_max))))])


        self.mobs.append(mob)
        self.entities.append(mob)

    def addPantin(self):
        for i in range(0,5):
            pantin = Mobs([None])
            pantin.position.x , pantin.position.y = 266 + 128*i,906
            pantin.pv = 1000000000
            pantin.collider.update(pantin.position.x+ 128*i , pantin.position.y, pantin.width, pantin.height)

            self.pantins.append(pantin)

    def addBoss(self):
        boss = Boss1(self.players)
        boss.position.x, boss.position.y = (590, 786)
        self.mobs.append(boss)
        self.entities.append(boss)
        self.boss = boss

    def addDecorCollision(self, xObjet, yObjet, widthObjet, heightObjet):
        objet = Objet(xObjet, yObjet, widthObjet, heightObjet)
        self.objets.append(objet)
