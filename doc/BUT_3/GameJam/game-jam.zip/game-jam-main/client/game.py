import pygame

from camera import Camera
from menuEnum import MenuEnum
from mapManager import MapManager
from entityManager import EntityManager
from menu import Menu
from camera import Camera
from difficultyHandler import DifficultyHandler
from network import Network 
from imageLoaded import ImageLoaded
from animation import Animation
from connection import launch_game_connection

import time


class Game:

    def __init__(self,screen: pygame.Surface):
        self.screen = screen
        self.background = pygame.Surface(self.screen.get_size())
        self.nbPlayers = 1
        self.isRunning = True
        self.mode = False #False= Menu, True = Jeu
        self.modeDeJeu = "lobby" #ou antiquite
        self.menu = Menu(screen)
        self.mapManager = MapManager(screen)
        self.entityManager = EntityManager(screen)

        self.camera = Camera()
        self.isHost = True
        self.ip = ""
        self.networkIsInatialize = False

    def load(self):
        if not self.mode:
            self.menu.load()
            pygame.mixer.music.load("./asset/music/8-bit-arcade-138828.mp3")
            pygame.mixer_music.play(-1)


            ImageLoaded.load()
        else :
            if not self.networkIsInatialize:
                self.entityManager.network = launch_game_connection(self.isHost, self.ip)
                self.entityManager.isHost = self.isHost
                self.networkIsInatialize = True


            if self.modeDeJeu == "lobby":
                self.mapManager.load("lobby")
                self.entityManager.load()
                pygame.mixer.music.unload()
                pygame.mixer.music.load("./asset/music/8-bit-dream-land-142093.mp3")
                pygame.mixer_music.play(-1)

            else:
                pygame.mixer.music.unload()
                pygame.mixer.music.load("./asset/music/mapSound.mp3")
                pygame.mixer_music.play(-1)

                self.mapManager.load("antiquite")

            self.mapManager.addCollisionMap(self.entityManager)
                

    def update(self, dt):
        for event in pygame.event.get():
            match event.type:
                case pygame.QUIT: self.isRunning = False
                case pygame.KEYDOWN:
                    if event.key == pygame.K_w:
                        Camera.shake()
                    
                    if event.key == pygame.K_x:
                        #Animation(ImageLoaded.vfx04 , nb_of_frame=14, scale=2, yIndex=0,tile_width=64, tile_height=64 ,position_vfx_tuple=(1190, 886) , is_VFX=True)
                        Animation(ImageLoaded.vfx63 , nb_of_frame=7, scale=2, yIndex=0 ,tile_width=64, tile_height=64 ,position_vfx_tuple=(1190, 886) , is_VFX=True)

        if not self.mode:
            self.menu.update(self)

        else :
            if self.entityManager.partieFinie :
                self.mode = False
                if self.entityManager.victoire :
                    self.menu.wantedMenu = MenuEnum.WINNINGSCREEN
                else:
                    self.menu.wantedMenu = MenuEnum.DEFEATSCREEN

            if self.modeDeJeu != "lobby":
                DifficultyHandler.update()
            
            modeDeJeu = self.entityManager.update(dt, self.modeDeJeu)
            if modeDeJeu == "antiquite":
                self.switchModeDeJeu("antiquite")
            Animation.update()

            Camera.center_on_entity( self.entityManager.players[0] , self.screen) # Askip le 0 c'est le player


    def draw(self):
        if not self.mode:
            self.menu.draw()
        else:
            self.mapManager.draw()
            self.entityManager.draw(self.screen, self.modeDeJeu)
            self.mapManager.drawPart2()
            Animation.draw_vfx(self.screen)
            if self.modeDeJeu != "lobby":
                DifficultyHandler.draw(self.screen)

    def switchMode(self, newMode):
        self.mode = newMode
        self.load()

    def switchModeDeJeu(self, newMode):
        self.modeDeJeu = newMode
        self.entityManager.pantins.clear()
        self.entityManager.objets.clear()
        self.mapManager.objet.clear()
        self.mapManager.scaled_images.clear()
        self.load()
