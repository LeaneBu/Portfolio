import pygame

from connection import get_ip


class GestionLobby:

    def __init__(self, screen: pygame.Surface):
        self.screen = screen

        #self.zoneDeLancement = pygame.Rect(556, 32, 311, 87)
        #self.zoneDeLancement.update(556, 32, 311, 87)

    def verifLancement(self, listPlayers):
        pass
        #for player in listPlayers:
        #    if not player.collider.colliderect(self.zoneDeLancement):
        #        return False
        #return True

    def drawIP(self):

        self.screen.blit(pygame.font.Font(None, 100).render(get_ip(), True, "Black"), (0,0))