import pygame

class ImageLoaded :
    
    ennemy_sprite : pygame.Surface
    sprite_singe : pygame.Surface
    players_sprite_sheet = []
    boss_sprite : pygame.Surface

    vfx04 : pygame.Surface 
    vfx63 : pygame.Surface 

    @staticmethod
    def load():
        ImageLoaded.ennemy_sprite = pygame.image.load('./asset/amoiamoi.png').convert_alpha()
        ImageLoaded.sprite_singe = pygame.image.load('./asset/loose_sprites.png').convert_alpha()
        ImageLoaded.boss_sprite = pygame.image.load('./asset/bibendum_mini.png').convert_alpha()

        ImageLoaded.vfx04 = pygame.image.load("./asset/vfx/04.png").convert_alpha()
        ImageLoaded.vfx63 = pygame.image.load("./asset/vfx/63.png").convert_alpha()


        ImageLoaded.players_sprite_sheet.append(pygame.image.load('./asset/Blue_Player_Walk.png').convert_alpha())
        ImageLoaded.players_sprite_sheet.append(pygame.image.load('./asset/Pink_Player_Walk.png').convert_alpha())
        ImageLoaded.players_sprite_sheet.append(pygame.image.load('./asset/White_Player_Walk.png').convert_alpha())