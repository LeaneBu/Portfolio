import pygame

from connection import launch_game_connection
from game import Game

def main():
    pygame.init()

    pygame.display.set_caption("Pacify Souls")
    screen = pygame.display.set_mode((1920, 1080), vsync=1)
    clock = pygame.time.Clock()
    pygame.mixer.init()

    game = Game(screen)
    game.load()
    #game.network = launch_game_connection(game.entityManager)
    #game.entityManager.network = game.network
    #game.entityManager.players[0].id = game.network.id_player

    while game.isRunning:
        dt = clock.tick(60) / 10
        game.update(dt)
        screen.fill((0,0,0))
        game.draw()
        pygame.display.flip()

    pygame.quit()


if __name__ == "__main__":
    main()