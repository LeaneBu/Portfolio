from enum import Enum

class MapEnum(Enum):
    ANTIQUITE = "antiquite"
    PRESENT = "present"
    FUTUR = "futur"
