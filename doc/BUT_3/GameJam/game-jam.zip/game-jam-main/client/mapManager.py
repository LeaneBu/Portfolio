from mapEnum import MapEnum
from camera import Camera
import pygame
from random import random
from pytmx import load_pygame
import pytmx

class MapManager:

    def __init__(self, screen):
        self.screen = screen
        self.currentMap = MapEnum.ANTIQUITE
        self.tmxdata = None
        self.objet = []
        self.scaled_images = {}  # Dictionnaire pour stocker les images redimensionnées
        self.scale_factor = 4

    def load(self, map):
        if map == "lobby":
            # Chargement du lobby .tmx
            self.tmxdata = load_pygame("./asset/maps/lobby.tmx")
        else:
            # Chargement de la carte antiquite .tmx
            self.tmxdata = load_pygame("./asset/maps/antiquite.tmx")

        self.scale_and_store_tiles()

    def scale_and_store_tiles(self):
        """
        Fonction pour redimensionner toutes les tuiles lors du chargement de la carte et les stocker.
        """
        tile_width = self.tmxdata.tilewidth * self.scale_factor
        tile_height = self.tmxdata.tileheight * self.scale_factor

        # Parcours des couches et redimensionnement de toutes les tuiles
        for layer_index in range(len(self.tmxdata.layers)):
            for y in range(self.tmxdata.height):
                for x in range(self.tmxdata.width):
                    image = self.tmxdata.get_tile_image(x, y, layer_index)
                    if image:
                        # Redimensionner et stocker l'image redimensionnée dans scaled_images
                        scaled_image = pygame.transform.scale(image, (tile_width, tile_height))
                        self.scaled_images[(x, y, layer_index)] = scaled_image

    def draw(self):
        tile_width = self.tmxdata.tilewidth * self.scale_factor
        tile_height = self.tmxdata.tileheight * self.scale_factor
        screen_width, screen_height = self.screen.get_size()

        # Calcul des limites des tuiles visibles (optimisation)
        start_x = int(max(0, Camera.posX // tile_width))
        start_y = int(max(0, Camera.posY // tile_height))
        end_x = int(min(self.tmxdata.width, (Camera.posX + screen_width) // tile_width + 1))
        end_y = int(min(self.tmxdata.height, (Camera.posY + screen_height) // tile_height + 1))

        # Création de la surface tampon avec la taille de l'écran
        buffer_surface = pygame.Surface((screen_width, screen_height))

        # Parcours des couches et affichage des tuiles visibles
        for layer_index in range(len(self.tmxdata.layers)):
            for y in range(start_y, end_y):
                for x in range(start_x, end_x):
                    # Récupération de l'image redimensionnée depuis scaled_images
                    scaled_image = self.scaled_images.get((x, y, layer_index))
                    if scaled_image:
                        # Calcul des positions sur la surface tampon
                        xx = x * tile_width - Camera.posX
                        yy = y * tile_height - Camera.posY

                        # Dessiner l'image sur la surface tampon
                        buffer_surface.blit(scaled_image, (xx, yy))

        # Blit de la surface tampon sur l'écran
        self.screen.blit(buffer_surface, (0, 0))

    def drawPart2(self):

        tile_width = self.tmxdata.tilewidth * self.scale_factor
        tile_height = self.tmxdata.tileheight * self.scale_factor
        screen_width, screen_height = self.screen.get_size()

        start_x = int(max(0, Camera.posX // tile_width))
        start_y = int(max(0, Camera.posY // tile_height))
        end_x = int(min(self.tmxdata.width, (Camera.posX + screen_width) // tile_width + 1))
        end_y = int(min(self.tmxdata.height, (Camera.posY + screen_height) // tile_height + 1))

        # Parcours des couches et affichage des tuiles visibles
        for layer_index in range(len(self.tmxdata.layers)):
            if(layer_index == 2) :
                for y in range(start_y, end_y):
                    for x in range(start_x, end_x):
                        # Récupération de l'image redimensionnée depuis scaled_images
                        scaled_image = self.scaled_images.get((x, y, layer_index))
                        if scaled_image:
                            # Calcul des positions sur la surface tampon
                            xx = x * tile_width - Camera.posX
                            yy = y * tile_height - Camera.posY

                            # Dessiner l'image sur la surface tampon
                            self.screen.blit(scaled_image, (xx, yy))


    def addCollisionMap(self, entityManager):
        for layer in self.tmxdata.visible_layers:
            if layer.id == 2 or layer.id == 4 :
                for objet in layer:
                    if(objet[2] != 0):
                        entityManager.addDecorCollision(objet[0]*32*self.scale_factor, objet[1]*32*self.scale_factor, 32*4, 32*4)
