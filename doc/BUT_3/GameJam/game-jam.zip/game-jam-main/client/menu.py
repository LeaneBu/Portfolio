import pygame

from menuEnum import MenuEnum

class Menu:

    def __init__(self, screen: pygame.Surface):
        self.screen = screen
        self.currentMenu = MenuEnum.HOMEMENU
        self.wantedMenu = MenuEnum.HOMEMENU
        self.background = pygame.image.load("./asset/menu/homeMenu.png")

        self.font = pygame.font.Font(None, 100)

        self.backButtonRect = pygame.Rect((77, 58), (110, 32))



        #Boutons HOMEMENU
        self.playButtonRect = pygame.Rect((803, 325), (311, 87))
        self.joinButtonRect = pygame.Rect((843, 456), (241, 87))
        self.creditsButtonRect= pygame.Rect((750, 579), (422, 87))
        self.settingsButtonRect = pygame.Rect((723, 712), (476, 87))
        self.leaveButtonRect = pygame.Rect((850, 840), (226, 87))

        #Boutons JOINMENU
        self.joinMenuButtonRect = pygame.Rect((798,704),(324,130))
        self.phraseJoin = ""
        self.inputBox = pygame.Rect((623,456),(500,100))
        self.lenPhrase=15
        self.nbDePoints = 0
        self.canPrint = True


    def load(self):
        self.background = pygame.image.load("./asset/menu/homeMenu.png")

    def changeMenu(self, menu):
        self.wantedMenu = menu

    def update(self, game):
        if(self.currentMenu != self.wantedMenu):
            self.background = pygame.image.load("./asset/menu/"+self.wantedMenu.value+".png")
            self.currentMenu = self.wantedMenu

        if self.currentMenu == MenuEnum.WINNINGSCREEN or self.currentMenu == MenuEnum.DEFEATSCREEN:
            if pygame.mouse.get_pressed()[0]:
                pass
        if(self.currentMenu == MenuEnum.HOMEMENU):
            if pygame.mouse.get_pressed()[0]:
                if self.playButtonRect.collidepoint(pygame.mouse.get_pos()):
                    game.switchMode(True)
                    #
                elif self.joinButtonRect.collidepoint(pygame.mouse.get_pos()):
                    self.wantedMenu = MenuEnum.JOINMENU
                elif self.creditsButtonRect.collidepoint(pygame.mouse.get_pos()):
                    self.wantedMenu = MenuEnum.CREDITMENU
                elif self.settingsButtonRect.collidepoint(pygame.mouse.get_pos()):
                    self.wantedMenu = MenuEnum.SETTINGSMENU
                elif self.leaveButtonRect.collidepoint(pygame.mouse.get_pos()):
                    game.isRunning = False

        elif self.currentMenu == MenuEnum.JOINMENU:
            if pygame.mouse.get_pressed()[0] and self.backButtonRect.collidepoint(pygame.mouse.get_pos()):
                self.wantedMenu = MenuEnum.HOMEMENU

            keys = pygame.key.get_pressed()

            if keys.count(False) == len(keys):
                self.canPrint = True

            if self.canPrint:

                if keys[pygame.K_BACKSPACE]:
                    self.phraseJoin = self.phraseJoin[:-1]
                    self.canPrint = False

                if len(self.phraseJoin) < self.lenPhrase:
                    if keys[pygame.K_1 or pygame.K_KP1]:
                        self.phraseJoin += "1"
                        self.canPrint = False

                    elif keys[pygame.K_2 or pygame.K_KP2]:
                        self.phraseJoin += "2"
                        self.canPrint = False

                    elif keys[pygame.K_3 or pygame.K_KP3]:
                        self.phraseJoin += "3"
                        self.canPrint = False

                    elif keys[pygame.K_4 or pygame.K_KP4]:
                        self.phraseJoin += "4"
                        self.canPrint = False

                    elif keys[pygame.K_5 or pygame.K_KP5]:
                        self.phraseJoin += "5"
                        self.canPrint = False

                    elif keys[pygame.K_6 or pygame.K_KP6]:
                        self.phraseJoin += "6"
                        self.canPrint = False

                    elif keys[pygame.K_7 or pygame.K_KP7]:
                        self.phraseJoin += "7"
                        self.canPrint = False

                    elif keys[pygame.K_8 or pygame.K_KP8]:
                        self.phraseJoin += "8"
                        self.canPrint = False

                    elif keys[pygame.K_9 or pygame.K_KP9]:
                        self.phraseJoin += "9"
                        self.canPrint = False

                    elif keys[pygame.K_0 or pygame.K_KP0]:
                        self.phraseJoin += "0"
                        self.canPrint = False

                    elif keys[pygame.K_PERIOD] or keys[pygame.K_KP_PERIOD] or keys[pygame.K_COMMA]:
                        self.phraseJoin += "."
                        self.canPrint = False

            if pygame.mouse.get_pressed()[0]:
                if self.joinMenuButtonRect.collidepoint(pygame.mouse.get_pos()):
                    #TODO : donner l'ip
                    game.isHost = False
                    game.ip = self.phraseJoin
                    game.switchMode(True)

        elif self.currentMenu == MenuEnum.CREDITMENU:
            if pygame.mouse.get_pressed()[0] and self.backButtonRect.collidepoint(pygame.mouse.get_pos()):
                self.wantedMenu = MenuEnum.HOMEMENU

        elif self.currentMenu == MenuEnum.SETTINGSMENU:
            if pygame.mouse.get_pressed()[0] and self.backButtonRect.collidepoint(pygame.mouse.get_pos()):
                self.wantedMenu = MenuEnum.HOMEMENU



    def draw(self):
        self.screen.blit(self.background, (0,0))

        if self.currentMenu == MenuEnum.JOINMENU:
            txt_surface = self.font.render(self.phraseJoin, True, "Black")
            self.screen.blit(txt_surface, txt_surface.get_rect(center = self.inputBox.center))

        #pygame.draw.rect(self.screen, "white", self.joinMenuButtonRect, 1)