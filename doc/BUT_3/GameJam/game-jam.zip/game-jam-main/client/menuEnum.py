from enum import Enum

class MenuEnum(Enum) :
    HOMEMENU = "homeMenu"
    JOINMENU = "joinMenu"
    CREDITMENU = "creditsMenu"
    SETTINGSMENU = "settingsMenu"
    WINNINGSCREEN = "winningScreen"
    DEFEATSCREEN = "defeatScreen"