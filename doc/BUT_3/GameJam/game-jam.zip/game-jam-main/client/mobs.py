from random import randint

import pygame

from entity import Entity
from weapons import *
from animation import Animation
from difficultyHandler import DifficultyHandler
from imageLoaded import ImageLoaded


class Mobs(Entity):

    def __init__(self, listPlayers):
        Entity.__init__(self, 0, 0, 2)

        # self.scale = int( 4 * DifficultyHandler.indice_difficulty ) 

        self.base_scale = 1
        self.scale = self.base_scale + int(DifficultyHandler.indice_difficulty / 8)

        self.animation : Animation = Animation(ImageLoaded.ennemy_sprite, 1, self.scale, tile_width=105, tile_height=96)
        self.frame = ImageLoaded.ennemy_sprite

        self.height = self.animation.tile_height * self.scale - 1
        self.width = self.animation.tile_width * self.scale - 1

        self.collider = pygame.Rect(self.position.x, self.position.y,  self.width, self.height)

        self.pvMax = 50 * DifficultyHandler.indice_difficulty
        self.pv = self.pvMax
        self.team = "mobs"

        self.weapon = Fusil()

        self.weapon.color = "red"
        self.weapon.damage *= DifficultyHandler.indice_difficulty
        # self.weapon.cooldown *= DifficultyHandler.indice_difficulty

        self.enemyCible = self.getAnEnemy(listPlayers)

        self.cooldown = 100

    def getAnEnemy(self, listPlayers):
        if listPlayers[randint(0, len(listPlayers) - 1)] is None:
            return None
        player = listPlayers[randint(0,len(listPlayers)-1)]
        while not player.isAlive:
            player = listPlayers[randint(0, len(listPlayers) - 1)]
        return player


    def update(self, dt, listAll):

        self.cooldown = max(self.cooldown - 1/dt, 0)

        dx, dy = self.getMovement()

        self.orientation = pygame.math.Vector2(dx, dy)

        collision = self.collision(listAll, dt)

        match collision:
            case (True, True):
                self.orientation = pygame.math.Vector2(0, 0)

            case (False, True):
                self.orientation = pygame.math.Vector2(dx, 0)

            case (True, False):
                self.orientation = pygame.math.Vector2(0, dy)

            case (False, False):
                pass

        if dx != 0 and dy != 0:
            self.orientation /= 1.41421

        self.move(dt)

        self.collider.update(self.position.x, self.position.y,  self.width, self.height)

        
        #self.shot((self.enemyCible.position.x+self.enemyCible.width/2,self.enemyCible.position.y+self.enemyCible.height/2))

    def shot(self, positionEnemy):
        if self.cooldown < 1:
            xEnemy, yEnemy = positionEnemy
            xPos = self.position.x
            yPos = self.position.y
            vecteur = (xEnemy - xPos, yEnemy - yPos)

            position = pygame.Vector2(self.position.x + self.width / 2, self.position.y + self.height / 2)
            bulletsShot = self.weapon.shot(position, vecteur, self.team)
            for bullet in bulletsShot:
                self.bullets.append(bullet)

            self.cooldown = self.weapon.getCooldown()

    def getMovement(self):
        dx = 0
        dy = 0

        if (self.position.x < self.enemyCible.position.x):
            dx += 1
            self.direction = 1
        if (self.position.x > self.enemyCible.position.x):
            dx -= 1
            self.direction = 2
        if (self.position.y < self.enemyCible.position.y):
            dy += 1
            self.direction = 3
        if (self.position.y > self.enemyCible.position.y):
            dy -= 1
            self.direction = 4

        return dx, dy
    
    def add_bullet(self, bullet):
        self.bullets.append(bullet)


    def to_dict(self):
        return {
            "x": self.position.x,
            "y": self.position.y,
            "pv": self.pv,
            "team": self.team,
            'weapon': self.weapon.getName(),
            'bullets': [bullet.to_dict() for bullet in self.bullets],
        }

    @classmethod
    def from_dict(cls, data):
        # Créer une instance vide de Player
        mob = cls()
        # Réinitialiser les attributs en fonction des données reçues
        mob.position.x = data["x"]
        mob.position.y = data["y"]
        mob.team = data["team"]
        mob.cooldown = data["cooldown"]

        return mob