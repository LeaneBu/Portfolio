import socket
import json

import bullets
from server import Server
from multiprocessing import Process
import time
import os
import signal

class Network:
    def __init__(self,server_ip = "127.0.0.1", port=5555):
        self.server_process = None
        self.server_ip = server_ip
        self.server_port = port
        self.socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.player = None
        self.id_player = 0

    def connect(self, player):
        try:
            self.socket_client.connect((self.server_ip, self.server_port))
            self.send_data(self.format_player_data(player, full_data=True))  # Envoi des données complètes lors de la connexion
            return self.receive_data()  # reception de l'id du joueur
        except Exception as e:
            print("[ERROR] Error trying to connect to server", e)
            return False

    def exchange_with_server(self, data):
        try:
            # Envoie uniquement les données dynamiques (comme la position) après la connexion
            self.send_data(data)
            return self.receive_data() # Réception des autres joueurs
        except Exception as e:
            print("[ERROR] Error trying to send data to server.", e)

    def send_data(self, data):
        try:
            message = json.dumps(data) + "\n"  # Ajout d'un délimiteur pour la fin du message
            self.socket_client.send(message.encode('utf-8'))
        except Exception as e:
            print(f"[ERROR] Failed to send data: {e}")

    def receive_data(self):
        buffer = ""
        while True:
            try:
                # Réception des données du client
                data = self.socket_client.recv(2048).decode('utf-8')
                buffer += data

                # Afficher les données brutes reçues pour le débogage
                #print(f"[DEBUG] Raw data received: {data}")

                # Si le buffer contient une fin de ligne, les données sont complètes
                if "\n" in buffer:
                    break
            except Exception as e:
                print(f"[ERROR] Failed to receive data: {e}")
                break

        if buffer:
            # Afficher le buffer complet avant le traitement
            #print(f"[DEBUG] Complete buffer before JSON parsing: {buffer}")

            # Décoder le JSON reçu
            json_data = buffer.strip()

            try:
                # Afficher les données JSON après le décodage
                data_dict = json.loads(json_data)
                #print(f"[DEBUG] Parsed JSON data: {data_dict}")
                return data_dict  # Renvoie la liste des joueurs sous forme de dictionnaire
            except json.JSONDecodeError as e:
                print(f"[ERROR] Failed to parse JSON data: {e}")

        return None

    def format_player_data(self, player, full_data=True):
        #if full_data:
            return player.to_dict()  # Envoie toutes les données du joueur, y compris les projectiles
        #else:
            #return {
                #"x": player.x,
                #"y": player.y,
                #"bullets": [bullets.to_dict() for bullets in player.bullets]  # Ajouter les projectiles
            #}

    def start_server(self):
        if self.server_process is None or not self.server_process.is_alive():
            server = Server()
            self.server_process = Process(target=server.start)
            self.server_process.start()
            time.sleep(1)  # Attendre que le serveur démarre avant de continuer
            print(f"Server started on {self.server_ip}:{self.server_port}")
        else:
            print("[ERROR] Server is already running.")

    def stop_server(self):
        if self.server_process is not None and self.server_process.is_alive():
            os.killpg(os.getpgid(self.server_process.pid), signal.SIGTERM)   # Attendre la fin du processus
            print("Server stopped.")
        else:
            print("[ERROR] No server is running.")





