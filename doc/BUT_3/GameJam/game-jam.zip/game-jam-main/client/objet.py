import pygame


class Objet:

    def __init__(self, x, y, h, w):
        self.x = x
        self.y = y
        self.position = pygame.Vector2(x, y)
        self.height = h
        self.width = w

        self.collider: pygame.Rect = pygame.Rect((x, y), (w, h))

    def getTeam(self):
        return "objet"

    def takeDamage(self, damage):
        pass