import pygame

from setting import Settings
from entity import Entity
from weapons import *
from camera import Camera
from animation import Animation
from imageLoaded import ImageLoaded
from  weapons import get_weapon_by_name

class Player(Entity):

    def __init__(self, id = 0, weapon = get_weapon_by_name("sonar"), mainPlayer = False):
        Entity.__init__(self, 0, 0, 7)
        self.weapon = weapon
        self.id = id
        self.mainPlayer = mainPlayer
        self.scale = 4

        self.animation : Animation = Animation(ImageLoaded.players_sprite_sheet[id%( len(ImageLoaded.players_sprite_sheet) + 1 )] , nb_of_frame=6, scale=self.scale, tile_height=32, tile_width=32)

        self.height = self.animation.tile_height * self.scale
        self.width = self.animation.tile_width * self.scale - 1

        self.collider = pygame.Rect(self.position.x, self.position.y, self.width, self.height)

        self.pvMax = 500
        self.pv = 500
        self.boost=1
        self.team = "players"

        self.soulSaved = 0


    def update(self,dt, listAll):
        if not self.mainPlayer:
            return
        keys = pygame.key.get_pressed()

        self.cooldown = max(self.cooldown - 1/dt, 0)

        dx = keys[pygame.K_d] - keys[pygame.K_q]
        dy = keys[pygame.K_s] - keys[pygame.K_z]

        self.orientation = pygame.math.Vector2(dx, dy)

        collision = self.collision(listAll, dt)

        match collision:
            case (True, True):
                self.orientation = pygame.math.Vector2(0, 0)

            case (False, True):
                self.orientation = pygame.math.Vector2(dx, 0)

            case (True, False):
                self.orientation = pygame.math.Vector2(0, dy)

            case (False, False):
                pass

        if dx != 0 and dy != 0:
            self.orientation /= 1.41421

        self.move(dt)

        self.collider.update(self.position.x, self.position.y, self.width, self.height)

        if keys[pygame.K_k] or pygame.mouse.get_pressed()[0]:
            self.shot()
        if keys[pygame.K_j]:
            self.weapon = Fusil()
        if keys[pygame.K_i]:
            self.weapon = Syphon()
        if keys[pygame.K_l]:
            self.weapon = Sniper()
        if keys[pygame.K_COMMA]:
            self.weapon = Mitraillette()
        if keys[pygame.K_SEMICOLON]:
            self.weapon = Pompe()


    def shot(self):
        if self.cooldown < 1:
            match Settings.directionDeTir:
                case "direction":  # 1 = right, 2 = left, 3 = bottom, 4 = up
                    if (self.direction == 1):
                        vecteur = (1, 0)
                    elif (self.direction == 2):
                        vecteur = (-1,0)
                    elif (self.direction == 3):
                        vecteur = (0,1)
                    elif (self.direction == 4):
                        vecteur = (0, -1)

                case "souris":
                    xMouse, yMouse = pygame.mouse.get_pos()
                    xPos = self.position.x + self.width/2 - Camera.posX
                    yPos = self.position.y + self.height/2 - Camera.posY
                    vecteur = (xMouse - xPos, yMouse - yPos)

                case "manette":
                    pass

            position = pygame.Vector2(self.position.x + self.width/2, self.position.y +  self.height/2)
            bulletsShot = self.weapon.shot(position, vecteur, self.team)

            for bullet in bulletsShot:
                self.bullets.append(bullet)

            self.cooldown = self.weapon.getCooldown()

    def add_bullet(self, bullet):
        self.bullets.append(bullet)



    def to_dict(self):
        return {
            "id" : self.id,
            "x": self.position.x,
            "y": self.position.y,
            "team": self.team,
            "pv": self.pv,
            "soulSaved": self.soulSaved,
            "bullets": [bullet.to_dict() for bullet in self.bullets],  # Projetiles sous forme de dictionnaires
            "weapon": self.weapon.getName()  # Nom de l'arme
        }

    @classmethod
    def from_dict(cls, data):
        # Créer une instance vide de Player
        player = cls()
        # Réinitialiser les attributs en fonction des données reçues
        player.id = data["id"]
        player.position.x = data["x"]
        player.position.y = data["y"]
        player.team = data["team"]
        player.weapon = get_weapon_by_name(data["weapon"])


        return player