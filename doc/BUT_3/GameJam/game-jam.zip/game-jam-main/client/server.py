import socket
from threading import Thread
import json

from bullets import Bullets

from player import Player



class Server:
    def __init__(self,server_ip ="", port =5555):
        self.server_ip = server_ip
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.player_index = 0
        self.players = {}
        self.list_mobs = {}
        self.boss = {}

    def start(self):
        print("SERVER START")
        try:
            self.server_socket.bind((self.server_ip, self.port))
        except Exception as e:
            print("[ERROR] Error trying to bind server.", e)

        self.server_socket.listen(10)
        self.listen_connections()
        print(f"[CONNECTION] Listening for connections on {self.port}")

    def listen_connections(self):
        while True:
            conn, addr = self.server_socket.accept()
            print(f"[CONNECTION] Connection from {addr}")
            thread = Thread(target=self.thread_client, args=(conn, addr, self.player_index))
            thread.start()
            self.player_index += 1

    def thread_client(self, conn, addr, player_index):
        print("Commencement du thread")

        # Réception des données de la première connexion (informations statiques + dynamiques)
        player_data = self.receive_data(conn)

        # Envoi de l'ID du joueur au joueur
        self.send_data(conn, player_index)

        #print(f"[RECEIVED DATA] Player {player_index} initial data: {player_data}")

        # Conversion du dictionnaire en objet Player
        player_obj = player_data
        player_obj['id'] = player_index
        # Ajout du joueur à la liste des joueurs
        self.players[player_index] = player_obj

        #print(f"[SERVER] Player {player_index} has joined.")

        current_player = self.players[player_index]
        is_online = True
        while is_online:
            try:
                #print("enter")
                # Réception des données dynamiques du client (uniquement la position et les projectiles)
                update_data = self.receive_data(conn)
                #print(f"[RECEIVED DATA] Player {player_index} update: {update_data}")

                if update_data:
                    # Mise à jour des coordonnées du joueur
                    current_player = update_data['players']
                    if player_index == 0:
                        self.list_mobs = update_data['mobs']
                        self.boss = update_data['boss']



                    # Ici, on met explicitement à jour l'entrée du dictionnaire `players`
                    self.players[player_index] = current_player

                    # Envoi des informations mises à jour aux autres joueurs
                    self.send_updated_data(conn, player_index)


            except Exception as e:
                print(f"[SERVER] {addr} has disconnected.", e)
                is_online = False

        print(f"[SERVER] Ended threaded tasks for client: {addr}")
        # Retrait du joueur de la liste des joueurs
        del self.players[player_index]
        # Fermeture de la connexion
        conn.close()

    def receive_data(self, conn):
        buffer = ""
        while True:
            try:
                # Réception des données du client
                data = conn.recv(2048).decode('utf-8')
                buffer += data
                # Si le buffer contient une fin de ligne, les données sont complètes
                if "\n" in buffer:
                    break
            except Exception as e:
                print(f"[ERROR] Failed to receive data: {e}")

                break
        if buffer:
            # Décodage du JSON reçu
            json_data = buffer.strip()
            #print(f"[RECEIVED RAW DATA] {json_data}")
            try:
             # Ajout du print pour voir les données brutes
                return json.loads(json_data)
            except Exception as e:
                print(f"[ERROR] Failed to receive data: {e}")
        return None

    def send_updated_data(self, conn, player_index):


        list_players = [player for key, player in self.players.items() if key != player_index]
        # [DEBUG] Afficher les données envoyées, y compris les projectiles
        #print(f"[SENDING DATA] Sending player data to player {player_index}: {list_players}")
        
        # Envoi des informations des autres joueurs au client
        dataToSend = {'players': list_players,
                      'mobs': self.list_mobs,
                      'boss': self.boss}
        
        self.send_data(conn, dataToSend)


    def send_data(self, conn, data):
        try:
            # Sérialisation des données en JSON et ajout d'un saut de ligne pour la fin du message
            message = json.dumps(data) + "\n"
            #print(f"[SENDING RAW DATA] {message.strip()}")  # Ajout du print pour voir les données envoyées
            # Envoi des données au client
            conn.sendall(message.encode('utf-8'))
        except Exception as e:
            print(f"[ERROR] Failed to send data: {e}")

def main():
    server = Server()
    server.start()

if __name__ == '__main__':
    main()
