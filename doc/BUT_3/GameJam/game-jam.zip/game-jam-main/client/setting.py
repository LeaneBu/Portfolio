class Settings:

    directionDeTir = "souris"  # direction, souris, manette
    volumeSonore = 1

    # Musique
    # pygame.mixer.music.load('my_music.mp3')
    # pygame.mixer.music.play()
    #
    # pygame.mixer.music.set_volume(0.5)
    #
    # Son
    # my_sound = pygame.mixer.Sound('my_sound.wav')
    # my_sound.play()

    # my_sound.set_volume(0.5)

    def __init__(self):
        None

    @staticmethod
    def setDirectionDeTir(newDirection):
        Settings.directionDeTir = newDirection

    @staticmethod
    def setVolume(newVolume):
        Settings.volumeSonore = newVolume
