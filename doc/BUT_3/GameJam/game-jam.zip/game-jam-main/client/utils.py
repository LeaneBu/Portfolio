import random

def random_of_ranges(*ranges):
  all_ranges = sum(ranges, [])
  return random.choice(all_ranges)