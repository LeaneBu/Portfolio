import math

from bullets import Bullets


def get_weapon_by_name(name):
    weapons = {
        "sword": Sword(10, 5),  # Si l'arme a des paramètres spécifiques comme height et width
        "sniper": Sniper(),
        "fusil": Fusil(),
        "fusil_boss": FusilDuBoss(),
        "mitraillette": Mitraillette(),
        "pompe": Pompe(),
        "lanceBulles": LanceBulles(),
        "syphon": Syphon(),
        "sonar": Sonar(),
        "trainee": Trainee(),
    }

    return weapons.get(name.lower(), None)


class Weapon:
    def __init__(self):
        self.name = "weapon"
        self.height = 10
        self.width = 10
        self.damage = 0
        self.quickness = 100
        self.lifeTime = 100
        self.cooldown = 10
        self.color = "pink"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets

    def getName(self):
        return self.name

    def getDamage(self):
        return self.damage

    def getQuickness(self):
        return self.quickness

    def getLifeTime(self):
        return self.lifeTime

    def getCooldown(self):
        return self.cooldown

    def getColor(self):
        return self.color

class Sword(Weapon):
    def __init__(self, height, width):
        Weapon.__init__(self)
        self.name = "sword"
        self.height = 50 + height
        self.width = 30 + width
        self.damage = 50
        self.quickness = 1
        self.lifeTime = 3
        self.cooldown = 25
        self.color = "green"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets


class Sniper(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "sniper"
        self.height = 15
        self.width = 15
        self.damage = 50000
        self.quickness = 4
        self.lifeTime = 500
        self.cooldown = 120
        self.color = "orange"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets

class Fusil(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "fusil"
        self.height = 14
        self.width = 14
        self.damage = 25
        self.quickness = 8
        self.lifeTime = 140
        self.cooldown = 14
        self.color = "cyan"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets

class FusilDuBoss(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "fusil_boss"
        self.height = 10
        self.width = 10
        self.damage = 25
        self.quickness = 2
        self.lifeTime = 70
        self.cooldown = 14
        self.color = "blue"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets


class Mitraillette(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "mitraillette"
        self.height = 12
        self.width = 12
        self.damage = 3
        self.quickness = 25
        self.lifeTime = 50
        self.cooldown = 3
        self.color = "green"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets

class Pompe(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "pompe"
        self.height = 15
        self.width = 15
        self.damage = 72
        self.quickness = 30
        self.lifeTime = 160
        self.cooldown = 42
        self.color = "yellow"

    def shot(self, position, vecteur, team):
        bullets = []
        angle = -20
        for i in range(0, 5):
            angleEnRadiant = angle * (math.pi / 180)
            vecteur = (vecteur[0]*math.cos(angleEnRadiant) - vecteur[1]*math.sin(angleEnRadiant) , vecteur[0]*math.sin(angleEnRadiant) + vecteur[1]*math.cos(angleEnRadiant) )
            bullet = Bullets(position, vecteur, self, team)
            bullets.append(bullet)
            if(angle==-20):
                angle=10
        return bullets


class LanceBulles(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "lanceBulles"
        self.height = 50
        self.width = 50
        self.damage = 3
        self.quickness = 3
        self.lifeTime = 400
        self.cooldown = 150
        self.color = "#daf2f0"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets


class Syphon(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "syphon"
        self.height = 5
        self.width = 5
        self.damage = 1
        self.quickness = 15
        self.lifeTime = 30
        self.cooldown = 2
        self.color = "purple"

    def shot(self, position, vecteur, team):
        bullets = []
        angle = -30
        for i in range(0, 60):
            angleEnRadiant = angle * (math.pi / 180)
            vecteur = (vecteur[0]*math.cos(angleEnRadiant) - vecteur[1]*math.sin(angleEnRadiant) , vecteur[0]*math.sin(angleEnRadiant) + vecteur[1]*math.cos(angleEnRadiant) )
            bullet = Bullets(position, vecteur, self, team)
            bullets.append(bullet)
            if(angle==-30):
                angle=1
        return bullets

class Sonar(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "sonar"
        self.height = 5
        self.width = 5
        self.damage = 10
        self.quickness = 5
        self.lifeTime = 500
        self.cooldown = 5
        self.color = "white"

    def shot(self, position, vecteur, team):
        bullets = []
        angle = 5 #-30
        for i in range(0, 72): #60
            angleEnRadiant = angle * (math.pi / 180)
            vecteur = (vecteur[0]*math.cos(angleEnRadiant) - vecteur[1]*math.sin(angleEnRadiant) , vecteur[0]*math.sin(angleEnRadiant) + vecteur[1]*math.cos(angleEnRadiant) )
            bullet = Bullets(position, vecteur, self, team)
            bullets.append(bullet)
        return bullets

class Trainee(Weapon):
    def __init__(self):
        Weapon.__init__(self)
        self.name = "trainee"
        self.height = 30
        self.width = 30
        self.damage = 3
        self.quickness = 0
        self.lifeTime = 400
        self.cooldown = 1
        self.color = "#00ffea"

    def shot(self, position, vecteur, team):
        bullets = []
        bullet = Bullets(position, vecteur, self, team)
        bullets.append(bullet)
        return bullets