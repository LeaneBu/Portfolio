if "aze":
    print('ok')