Groupe : A12

# CI / CD Chess Project

Gabin Bernard
Leane Buisson
Titouan Burdeau
Damien Briand

# 1. Mise en Place du Projet

## 1.1. Organisation du Projet

Pour l'organisation au sein du groupe, nous avons fait deux équipe de deux personnes.
- Gabin Bernard et Leane Buisson
- Titouan Burdeau et Damien Briand

Chaque équipe a pris des sujets différents pour travailler en parallèle.
Pour chaque sujet, nous avons créé une branche dédiée. Chaque branche est liée à une issue.

Nous n'avous pas jugé de créé un environnement de développement spécifique pour un projet de cette taille.
La branche `master` est la branche principale du projet. Les branches de chaque sujet sont mergées dans la branche `master` une fois que le sujet est terminé.

## 1.2. Convension de Nommage

Pour la bonne organisation du projet, nous avons décidé de suivre une convention de nommage pour les branches et les commits.

Pour les branches, nous avons décidé de suivre la convention suivante :
- La branche `master` est la branche principale du projet.
- Les branches doivent avoir un nom claire sur ce qui doit étre fait.
- Chaque branche doit être liée à une issue.

Pour les commits, nous avons décidé de suivre la convention suivante :
- Les commits doivent être clairs et concis.
- Chaque message de commits doit avoir un préfixe pour indiquer le type de commit: 
    - `feat` pour une nouvelle fonctionnalité
    - `fix` pour une correction de bug
    - `docs` pour une modification de la documentation
    - `style` pour une modification du style
    - `refactor` pour une modification du code qui n'ajoute pas de fonctionnalité
    - `test` pour l'ajout de tests
    - `chore` pour les tâches de maintenance
    - `ci` pour les modifications des fichiers de configuration de CI
    - `build` pour les modifications qui affectent le build system ou les dépendances externes

# 2. Pipeline CI / CD

Nous avons mis en place un pipeline CI / CD avec GitLab CI.
Nous avons plusieurs étapes dans notre pipeline :
- `lint` : Cette étape permet de vérifier que le code est bien formatté et qu'il respecte les conventions de style.
- `test` : Cette étape permet de lancer les tests unitaires.
- `docs` : Cette étape permet de générer la documentation du projet.
- `security` : Cette étape permet de vérifier que le code ne contient pas de failles de sécurité.
- `deploy` : Cette étape permet de déployer la docs dans une page du Git. [Lien de la page](https://chess-bernagab-briandd-buisslea-burdeaut-d17dd5.gricad-pages.univ-grenoble-alpes.fr/)

# 3. Issues et Merge Requests

## 3.1. Issues

Lors de l'ouverture d'une issue, nous mettons un label pour indiquer si c'est une feature, un bug, une amélioration, etc. L'issue doit avoir un titre clair et une description détaillée de ce qui doit être fait. Nous assignons ensuite l'issue à une personne du groupe. 

## 3.2. Merge Requests

Pour clore une issue, nous créons une merge request. La merge request doit être liée à l'issue. Nous assignons ensuite la merge request à une personne du groupe pour qu'elle puisse la relire et la valider.

Par défaut, une merge request ne peut être mergée que si elle a été validée par une autre personne.

Les merges requests sont en *draft* par défaut. Pour les passer en *open*, il faut les assigner à une personne du groupe.


# 4. Etat d'Avancement

Issue ouverte et traitée :
- integration pipeline [feature]
- mauvaise branch pipeline [bug]
- Migration Cypress v13 [bug]
- Système tour joueur [bug]
- Affichage des mouvement possible [feature]
- Prise en passant [feature]
- Ajout d'un environnement de développement [feature]
- Environnement de dev ne reload pas au changement dans src [bug]
- Problème Tour Pion [bug]
- Add custom notification to capture en passant [feature]
- Fix problème de chargement dépendance js [bug]
- fix en passant rule [bug]

# 5. Fonctionnalités réalisées

## 5.1. Prise en passant

Nous avons implémenté la mécanique de prise en passant. Il s'agit d'une règle particulière qui nous permet, à l'aide d'un pion, de capturer un autre pion lorsqu'il vient d'avancer de deux cases à la fois, en se plaçant sur la case intermédiaire par laquelle il aurait dû normalement plasser.

Cela a été implémenté en surchargeant la fonction move de Pièce sur Pawn et en modifiant la fonction canMove de Pawn. Il a également été nécessaire de stocker dans le chessboard le dernier coup effectué par le joueur adverse.

Egalement, a été rajouté un test permettant de vérifier la capacité de prise en pasant d'un pion à condition que les conditions précédentes soient respectées.

## 5.2. Affichage des mouvements possibles

Nous avons mis en place l'affichage des mouvements possibles par les différentes pièces sur le plateau lors de la sélection de celle pour un déplacement. Cela s'illustre par un changement de couleur de la case jouable, prenant en compte les différents déplacements spécifiques aux pièces.

Il a été créé un test permettant de vérifier que les cases affichées d'une couleur différente étaient bien celles dont l'action de déplacement pouvait être effectuée dessus.

# 6. Maintenance technique

Nous avons procédé à une mise à jour complète de notre environnement de test en migrant Cypress vers la version 13. Cette opération a impliqué la restructuration de l'ensemble des fichiers de tests E2E selon les nouvelles conventions de l'outil.

Les 27 fichiers de test existants ont été renommés (passage de .spec.js à .cy.js) et réorganisés dans l'arborescence officielle recommandée. Nous avons migré la configuration vers le nouveau format cypress.config.js tout en supprimant l'ancien fichier cypress.json devenu obsolète.

Cette maintenance technique (réalisée via des commits de type chore) préserve l'intégralité des scénarios de test existants tout en permettant d'utiliser les dernières fonctionnalités de Cypress. 

# 7. Conclusion

Au cours de ce projet, nous avons rencontré plusieurs difficultés. L'une des principales difficultés a été la mise en place du pipeline CI / CD. Nous avons dû configurer correctement les différentes étapes et nous assurer que chaque étape fonctionnait comme prévu. 

Une autre difficulté a été la gestion des branches et des merges requests. Il a fallu s'assurer que chaque branche était correctement nommée et liée à une issue, et que chaque merge request était validée par une autre personne avant d'être mergée.

Enfin, l'implémentation de certaines fonctionnalités, comme la prise en passant, a nécessité une compréhension approfondie des règles du jeu d'échecs et une adaptation du code existant.

Malgré ces difficultés, nous avons réussi à mener à bien ce projet et à implémenter les fonctionnalités principales du jeu d'échecs.
