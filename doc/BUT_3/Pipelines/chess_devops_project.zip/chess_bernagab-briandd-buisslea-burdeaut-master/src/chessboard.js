const Color = require('./color.js');
const Queen = require('./queen.js');
const King = require('./king.js');
const Pawn = require('./pawn.js');
const Bishop = require('./bishop.js');
const Knight = require('./knight.js');
const Rook = require('./rook.js');

/**
 * Chessboard constructor.
 * @constructor
 */
const Chessboard = function () {
  /**
   * An array containing the different pieces that have not been captured yet.
   * @type {Array.<Piece>}
   * @public
   */
  this.pieces = [];

  /**
   * The current turn color.
   * @type {Color}
   * @public
   */
  this.currentTurn = Color.WHITE;

  /**
   * The last move coordinates
   * @type {Array}
   * @public
   */
  this.lastMove = [];
};

/**
 * Initialize the chessboard.
 * This function will create the pieces and put them to their corresponding positions.
 * White pieces are located at the lowest ranks.
 * Black pieces are located at the uppest ranks.
 * The queen always starts on a cell corresponding to its color.
 */
Chessboard.prototype.init = function () {
  // Empty the array from previous games.
  this.pieces = [];

  const chessPackage = {
    Queen,
    King,
    Bishop,
    Rook,
    Knight,
    Pawn
  };

  // Each piece has a uniq numerical id.
  let id = 0;

  // Initialize the board.
  for (let i = 1; i <= 8; i++) {
    // Put the black pawns on the 7th rank
    const blackPawn = new Pawn({
      rank: 7,
      file: i,
      id: ++id,
      chessboard: this,
      color: Color.BLACK
    });

    this.pieces.push(blackPawn);

    // Put the white pawns on the 2nd rank
    const whitePawn = new Pawn({
      rank: 2,
      file: i,
      id: ++id,
      chessboard: this,
      color: Color.WHITE
    });

    this.pieces.push(whitePawn);
  }

  // Put the other pieces
  [
    { rank: 1, color: Color.WHITE },
    { rank: 8, color: Color.BLACK }
  ].forEach((data) => {
    const { rank, color } = data;

    [
      'Rook',
      'Knight',
      'Bishop',
      'Queen',
      'King',
      'Bishop',
      'Knight',
      'Rook'
    ].forEach((Piece, file) => {
      this.pieces.push(
        new chessPackage[Piece]({
          chessboard: this,
          rank,
          id: ++id,
          file: file + 1,
          color
        })
      );
    });
  });
};

/**
 * Retrieve a piece at a given rank and file.
 * @param {number} rank - the rank of the piece.
 * @param {number} file - the file of the piece.
 * @return {?Piece} Returns the piece (if any) or <code>null</code> if
 * no piece is located at the given rank and file.
 *
 * @example
 * // After initializing the board, returns the white rook located at (1, a)
 * let chessboard = new Chessboard();
 * chessboard.init();
 * let piece = this.getPiece(1, 1);
 */
Chessboard.prototype.getPiece = function (rank, file) {
  for (let i = 0; i < this.pieces.length; i++) {
    const p = this.pieces[i];
    if (p.rank === rank && p.file === file) {
      return p;
    }
  }
  return null;
};

/**
 * Switch the current turn to the opposite color.
 * If the current turn is white, it will switch to black, and vice versa.
 * @public
 */
Chessboard.prototype.switchTurn = function () {
  this.currentTurn = this.currentTurn === Color.WHITE ? Color.BLACK : Color.WHITE;
};

module.exports = Chessboard;
