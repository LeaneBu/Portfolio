/**
 * Piece color.
 * @enum
 */
const Color = {
  WHITE: 'white',
  BLACK: 'black'
};

module.exports = Color;
