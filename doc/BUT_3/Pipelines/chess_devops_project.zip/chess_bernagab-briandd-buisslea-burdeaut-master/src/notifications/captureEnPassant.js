const Notification = require('./notification.js');

/**
 * CaptureEnPassantNotification constructor.
 * @param {?Object} options - an optional list of options.
 * @constructor
 */
const CaptureEnPassantNotification = function (options) {
  options = options || {};

  /**
   * The position of the piece being captured.
   * @type {Object}
   */
  this.pos = options.pos || {
    rank: 1,
    file: 1
  };
};

// Inheritance definition
CaptureEnPassantNotification.prototype = Object.create(Notification.prototype);
CaptureEnPassantNotification.prototype.constructor = CaptureEnPassantNotification;

module.exports = CaptureEnPassantNotification;
