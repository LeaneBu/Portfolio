/**
 * Notification constructor.
 * @abstract
 * @constructor
 */
const Notification = function () {};

module.exports = Notification;
