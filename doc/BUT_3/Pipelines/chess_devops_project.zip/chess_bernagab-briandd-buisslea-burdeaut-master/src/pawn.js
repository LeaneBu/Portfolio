const Piece = require('./piece.js');
const Color = require('./color.js');
const CaptureNotification = require('./notifications/capture.js');
const MoveNotification = require('./notifications/move.js');
const CaptureEnPassantNotification = require('./notifications/captureEnPassant.js');

/**
 * Pawn constructor. A pawn ahs specific movement.
 * @param {!Object} options - a non-null list of options.
 * @constructor
 */
const Pawn = function (options) {
  Piece.call(this, options);
};

// Inheritance definition
Pawn.prototype = Object.create(Piece.prototype);
Pawn.prototype.constructor = Pawn;

/**
 * Check if the pawn is located at its initial position.
 * @return {boolean} <code>true</code> if the pawn is in its initial position, <code>false</code> otherwise.
 * @constructor
 */
Pawn.prototype.isInInitialPosition = function () {
  return (
    (this.color === Color.WHITE && this.rank === 2) ||
    (this.color === Color.BLACK && this.rank === 7)
  );
};

/**
 * Move a pawn at a specific rank and file. Prior to moving,
 * this method calls the <code>canMove</code> method.
 * Yelds move and capture notifications if necessary.
 * @param {number} rank - the target rank.
 * @param {number} file - the target file.
 */
Pawn.prototype.move = function (rank, file) {
  if (this.chessboard.currentTurn !== this.color) {
    return;
  }
  if (this.canMove(rank, file)) {
    const delta = {
      rank: Math.abs(this.rank - rank),
      file: Math.abs(this.file - file)
    };

    if (this.canCapture(rank, file)) {
      // If the answer is yes, get a ref to the captured piece and its index.
      const captured = this.chessboard.getPiece(rank, file),
        index = this.chessboard.pieces.indexOf(captured);

      // Remove the piece from the chessboard
      this.chessboard.pieces.splice(index, 1);
      captured.isCaptured = true;
      captured.rank = -1;
      captured.file = -1;

      // Notify observers that the piece has been captured
      captured.update(
        new CaptureNotification({
          pos: {
            rank,
            file
          }
        })
      );
    }

    // If the pawn is doing en passant, capture the piece and send notification
    if (delta.rank === delta.file && this.canCaptureEnPassant(this.rank, file)) {
      // If the answer is yes, get a ref to the captured piece and its index.
      const captured = this.chessboard.getPiece(this.rank, file),
        index = this.chessboard.pieces.indexOf(captured);

      // Remove the piece from the chessboard
      this.chessboard.pieces.splice(index, 1);
      captured.isCaptured = true;
      captured.rank = -1;
      captured.file = -1;

      // Notify observers that the piece has been captured
      captured.update(
        new CaptureEnPassantNotification({
          pos: {
            rank,
            file
          }
        })
      );
    }

    // Store the previous position of the piece to move
    const oldPosition = {
      rank: this.rank,
      file: this.file
    };

    // Store the new position of the piece to move
    const newPosition = {
      rank,
      file
    };

    // Actually move the piece
    this.rank = rank;
    this.file = file;

    this.chessboard.lastMove = [oldPosition.rank, oldPosition.file, newPosition.rank, newPosition.file];

    // Notify observers that the piece have been moved
    this.update(
      new MoveNotification({
        oldPosition,
        newPosition
      })
    );

    this.chessboard.switchTurn(); // Alterner les tours après un mouvement valide
  }
}

/**
 * Whether a piece can capture using en passant on a specific cell.
 * @param {number} rank - the rank on the chessboard.
 * @param {number} file - the file on the chessboard.
 * @return {boolean} <code>true</code> if the piece can capture, <code>false</code> otherwise.
 */
Piece.prototype.canCaptureEnPassant = function (rank, file) {
  const piece = this.chessboard.getPiece(rank, file);
  if (piece === null) return false;
  if (!(piece instanceof Pawn)) return false;
  if (
    Math.abs(this.chessboard.lastMove[0] - this.chessboard.lastMove[2]) !== 2 ||
    this.chessboard.lastMove[1] !== file ||
    this.chessboard.lastMove[2] !== rank ||
    this.chessboard.lastMove[3] !== file
  ) {
    return false;
  }

  return piece.color !== this.color;
};

/**
 * Whether a pawn can move at a given rank and file.
 *
 * @override
 * @param {number} rank - the rank on the chessboard.
 * @param {number} file - the file on the chessboard.
 * @return {boolean} <code>true</code> if the piece can move, <code>false</code> otherwise.
 */
Pawn.prototype.canMove = function (rank, file) {
  if (!Piece.prototype.canMove.call(this, rank, file)) {
    return false;
  }

  const delta = {
    rank: Math.abs(this.rank - rank),
    file: Math.abs(this.file - file)
  };

  const isGoingUp = rank - this.rank > 0;

  // In any case a pawn cannot move more than 2 cases vertically
  // and one case horizontally
  if (delta.rank > 2 || delta.file > 1) {
    return false;
  }

  // A pawn can move forward two cells
  // if it lies in its initial position
  if (delta.rank === 2 && !this.isInInitialPosition()) {
    return false;
  }

  // A white pawn "goes up" the chessboard
  if (this.color === Color.WHITE && !isGoingUp) {
    return false;
  }

  // A black pawn "goes down" the chessboard
  if (this.color === Color.BLACK && isGoingUp) {
    return false;
  }

  // A pawn only goes diagonally when it captures an opponnent piece
  if (
    (
      delta.rank === delta.file &&
      !this.canCapture(rank, file) &&
      !this.canCaptureEnPassant(this.rank, file)
    ) ||
    (delta.rank === 0 && delta.file === 1) ||
    (delta.file === 0 && this.canCapture(rank, file))
  ) {
    return false;
  }

  return true;
};

module.exports = Pawn;
