# Tour des Héros - Projet Angular

## Description

Le **Tour des Héros** est une application web développée avec Angular. Ce projet est une extension du tutoriel officiel Angular "Tour of Heroes", enrichi de fonctionnalités avancées pour gérer des héros et des armes.

### Fonctionnalités principales

- **Gestion des héros** :
	- Créer, modifier et supprimer des héros.
	- Lister l'ensemble des héros avec leurs caractéristiques, y compris les bonus/malus liés aux armes équipées.
	- Détail d'un héros avec les informations complètes, y compris l'arme associée.

- **Gestion des armes** :
	- Créer, modifier et supprimer des armes.
	- Lister toutes les armes avec leurs caractéristiques.
	- Détail d'une arme, incluant les héros qui l'utilisent.

- **Filtres et tris** :
	- Trier et filtrer les héros ou les armes par caractéristiques.

- **Formulaires réactifs** :
	- Utilisation de `Reactive Forms` avec des validateurs pour gérer les formulaires de création/édition des héros et des armes.
	- Contrôles des contraintes de répartition des points.

## Technologies utilisées

- **Framework** : Angular
- **Langage** : TypeScript
- **Styles** : CSS
- **Base de données distante** : Firebase (en option pour persistance des données)
- **Versionnement** : Git (hébergé sur le serveur GitLab universitaire)

## Installation

1. Clonez le dépôt Git :

   `git clone https://gricad-gitlab.univ-grenoble-alpes.fr/iut2-info-stud/2024-s5/r5.real.05/a1/toh-buisslea.git`

2. Accédez au répertoire du projet :

   `cd toh-buisslea`

3. Installez les dépendances :

   `npm install`

4. Lancez le serveur de développement :

   `ng serve`

5. Ouvrez l'application dans votre navigateur à l'adresse [http://localhost:4200](http://localhost:4200).

## Structure du projet

- **components** : Contient les composants Angular pour les pages principales.
- **services** : Contient les services Angular pour la gestion des données des héros et des armes.
- **model** : Définit les classes et interfaces pour les héros et les armes.

## Fonctionnalités avancées

### Héros

- Chaque héros possède 4 caractéristiques principales :
	- Attaque
	- Esquive
	- Dégâts
	- Points de vie
- La répartition des points suit les règles suivantes :
	- La somme des points ne doit pas dépasser 40.
	- Chaque caractéristique doit être supérieure ou égale à 1.
	- L'éditeur affiche les points restants.

### Armes

- Chaque arme possède également 4 caractéristiques avec des valeurs comprises entre -5 et 5.
- La somme des points d'une arme doit être égale à 0.
- Les bonus/malus des armes sont appliqués aux héros qui les équipent.

### Association héros/arme

- Un héros peut être équipé d'une arme.
- Une arme ne peut pas être ajoutée si une caractéristique du héros passe en dessous de 1 après application des bonus/malus.

### Création héros/arme

#### Utilisation des Reactives Forms
- Gestion des formulaires avec validation automatique des contraintes via `Reactive Forms`.
- Affichage des messages d'erreur en cas de non-respect des règles de répartition.

## Améliorations possibles

- **Tests unitaires** : Implémentation de tests pour les composants et les services.
- **Interface utilisateur** : Ajout de styles et d'animations pour améliorer l'expérience utilisateur.

## Déploiement

http://www-etu-info.iut2.upmf-grenoble.fr/~buisslea/info7

## Tuto Utilisation

https://youtu.be/_5jI0d4D4FU

## Auteurs

- **Buisson Léane** - Étudiante en parcours A à l'Université Grenoble Alpes
- Inspiré du tutoriel officiel "Tour of Heroes" d'Angular.
