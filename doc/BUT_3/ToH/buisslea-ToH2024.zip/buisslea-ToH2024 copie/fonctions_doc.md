# **Fonctionnalités de l'application Tour des Héros**

## **Introduction**

Le **Tour des Héros** est une application web développée avec Angular, inspirée du tutoriel officiel "Tour of Heroes". Ce projet a été enrichi pour inclure des fonctionnalités avancées permettant la gestion des héros et des armes, ainsi que leur interaction.

---

## **Fonctionnalités principales**

### **1. Gestion des Héros**
- **Création, modification et suppression** : Permet de créer de nouveaux héros, modifier leurs caractéristiques ou les supprimer.
- **Liste des héros** : Affiche tous les héros avec leurs caractéristiques principales :
  - Attaque
  - Esquive
  - Dégâts
  - Points de vie
- **Bonus/Malus des armes** : Les caractéristiques des héros incluent les effets des armes équipées.
- **Détail d’un héros** : Montre les informations complètes d’un héros, y compris son arme associée (si disponible).

---

### **2. Gestion des Armes**
- **Création, modification et suppression** : Fonctionnalités similaires à la gestion des héros, adaptées aux armes.
- **Liste des armes** : Présente toutes les armes avec leurs caractéristiques spécifiques :
  - Attaque
  - Esquive
  - Dégâts
  - Points de vie
- **Détail d’une arme** : Affiche la liste des héros qui utilisent une arme spécifique.

---

### **3. Filtres et Tris**
- Les utilisateurs peuvent trier et filtrer les listes de héros et d’armes en fonction de leurs caractéristiques.

---

### **4. Formulaires réactifs (Reactive Forms)**
- **Gestion des formulaires** : Utilisation des `Reactive Forms` d’Angular pour les formulaires de création et d’édition.
- **Validation** : Intégration de règles et de contraintes spécifiques :
  - Pour les héros :
    - La somme des points ne doit pas dépasser 40.
    - Chaque caractéristique doit être supérieure ou égale à 1.
  - Pour les armes :
    - Les caractéristiques doivent être comprises entre -5 et 5.
    - La somme des points doit être égale à 0.
- **Messages d’erreur** : Les erreurs sont affichées automatiquement si les règles ne sont pas respectées.

---

## **Fonctionnalités avancées**

### **1. Association Héros/Arme**
- **Équipement d’une arme** : Un héros peut être équipé d’une arme.
- **Restrictions** : Une arme ne peut être associée à un héros si cela entraîne une caractéristique du héros en dessous de 1.

### **2. Validation en temps réel**
- Les formulaires utilisent des validations dynamiques pour s'assurer que les contraintes sont respectées lors de la création ou de l'édition.

### **3. Bonus/Malus dynamiques**
- Les caractéristiques des héros incluent automatiquement les effets des armes associées.

---
