import { Component } from '@angular/core';
import {RouterLink, RouterOutlet} from '@angular/router';
import {MessagesComponent} from "./components/messages/messages.component";
import {CreateComponent} from "./components/create/create.component";
import {ModifComponent} from "./components/modif/modif.component";
import {WeaponsComponent} from "./components/weapons/weapons.component";

@Component({
  selector: 'app-root',
  standalone: true,
	imports: [RouterOutlet, MessagesComponent, RouterLink, CreateComponent, ModifComponent, WeaponsComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Tour of heroes';
}
