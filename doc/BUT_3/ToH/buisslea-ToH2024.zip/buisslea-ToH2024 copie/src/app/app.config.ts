import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { routes } from './app.routes';
import { initializeApp, provideFirebaseApp } from '@angular/fire/app';
import { getFirestore, provideFirestore } from '@angular/fire/firestore';

export const appConfig: ApplicationConfig = {
  providers: [provideZoneChangeDetection({ eventCoalescing: true }), provideRouter(routes), provideFirebaseApp(() => initializeApp({"projectId":"tower-of-heroes-6161a","appId":"1:29302082587:web:ca301225f059394612fcbe","storageBucket":"tower-of-heroes-6161a.appspot.com","apiKey":"AIzaSyC89r-wXqC9kYPOs-8yxvqYA2ZG6F-sm5A","authDomain":"tower-of-heroes-6161a.firebaseapp.com","messagingSenderId":"29302082587"})), provideFirestore(() => getFirestore())]
};
