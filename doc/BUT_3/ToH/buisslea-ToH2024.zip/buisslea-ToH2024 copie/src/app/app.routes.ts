import { Routes } from '@angular/router';
import {HeroesComponent} from "./components/heroes/heroes.component";
import {DashboardComponent} from "./components/dashboard/dashboard.component";
import {HeroDetailComponent} from "./components/hero-detail/hero-detail.component";
import {CreateComponent} from "./components/create/create.component";
import {ModifComponent} from "./components/modif/modif.component";
import {WeaponsComponent} from "./components/weapons/weapons.component";
import {WeaponDetailComponent} from "./components/weapon-detail/weapon-detail.component";
import {CreateWeaponComponent} from "./components/create-weapon/create-weapon.component";
import {ModifWeaponComponent} from "./components/modif-weapon/modif-weapon.component";

export const routes: Routes = [
	{ path: '', redirectTo: '/dashboard', pathMatch: 'full' },
	{ path: 'dashboard', component: DashboardComponent },
	{ path: 'detail-hero/:id', component: HeroDetailComponent },
	{ path: 'detail-weapon/:id', component: WeaponDetailComponent },
	{ path: 'heroes', component: HeroesComponent },
	{ path: 'weapons', component: WeaponsComponent },
	{ path: 'create', component: CreateComponent },
	{ path: 'create-weapon', component: CreateWeaponComponent },
	{ path: 'modif/:id', component: ModifComponent },
	{ path: 'modif-weapon/:id', component: ModifWeaponComponent },

];
