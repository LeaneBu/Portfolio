import {Component, Input} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, ReactiveFormsModule, ValidatorFn, Validators} from "@angular/forms";
import {HeroService} from "../../services/hero.service";
import {Weapon} from "../model/weapon";
import {WeaponService} from "../../services/weapon.service";

@Component({
  selector: 'app-create-weapon',
  standalone: true,
	imports: [
		ReactiveFormsModule
	],
  templateUrl: './create-weapon.component.html',
  styleUrl: './create-weapon.component.css'
})
export class CreateWeaponComponent {
	submitted: boolean = false;

	weaponForm = new FormGroup({
		name: new FormControl('', Validators.required),
		pv: new FormControl(0, [Validators.required, Validators.min(-5), Validators.max(5)]),
		att: new FormControl(0, [Validators.required, Validators.min(-5), Validators.max(5)]),
		dodge: new FormControl(0, [Validators.required, Validators.min(-5), Validators.max(5)]),
		dam: new FormControl(0, [Validators.required, Validators.min(-5), Validators.max(5)]),
	}, { validators: this.totalLimitValidator });

	@Input() weapon: Weapon = new Weapon();

	constructor(private weaponService: WeaponService) {}

	totalLimitValidator(): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } | null => {
			const formGroup = control as FormGroup;
			const pv = formGroup.get('pv')?.value || 0;
			const att = formGroup.get('att')?.value || 0;
			const dodge = formGroup.get('dodge')?.value || 0;
			const dam = formGroup.get('dam')?.value || 0;

			const total = pv + att + dodge + dam;
			return total == 0 ? { totalLimit: true } : null;
		};
	}

	save() {
		if (this.weaponForm.valid) {
			this.weapon.name = this.weaponForm.get('name')?.value || '';
			this.weapon.pv = Number(this.weaponForm.get('pv')?.value) || 0;
			this.weapon.att = Number(this.weaponForm.get('att')?.value) || 0;
			this.weapon.dodge = Number(this.weaponForm.get('dodge')?.value) || 0;
			this.weapon.dam = Number(this.weaponForm.get('dam')?.value) || 0;

			this.weaponService.addWeapon(this.weapon);
			this.snackbar();
			this.submitted = false;
		} else {
			console.log("Formulaire invalide !");
		}
	}

	getRemainingPoints(): number {
		const pv = Number(this.weaponForm.get('pv')?.value) || 0;
		const att = Number(this.weaponForm.get('att')?.value) || 0;
		const dodge = Number(this.weaponForm.get('dodge')?.value) || 0;
		const dam = Number(this.weaponForm.get('dam')?.value) || 0;

		const total = pv + att + dodge + dam;
		const maxPoints = 0;

		return maxPoints - total;
	}

	isFieldInvalid(field: string): boolean {
		// @ts-ignore
		return this.weaponForm.get(field).invalid && (this.weaponForm.get(field).dirty || this.weaponForm.get(field).touched);
	}

	snackbar(): void{
		const x = document.getElementById("snackbar");
		if (x) {
			x.className = "show";
			setTimeout(() => {
				x.className = x.className.replace("show", "");
			}, 3000);
		}
	}
}
