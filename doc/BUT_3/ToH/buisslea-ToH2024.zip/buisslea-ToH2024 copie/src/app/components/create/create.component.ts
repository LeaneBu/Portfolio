import {Component, Input} from '@angular/core';
import {
	AbstractControl,
	FormControl,
	FormGroup,
	FormsModule,
	ReactiveFormsModule,
	ValidatorFn,
	Validators
} from "@angular/forms";
import {Hero} from "../model/hero";
import {HeroService} from "../../services/hero.service";

@Component({
  selector: 'app-create',
  standalone: true,
	imports: [
		FormsModule,
		ReactiveFormsModule,
	],
  templateUrl: './create.component.html',
  styleUrl: './create.component.css'
})
export class CreateComponent {
	submitted: boolean = false;

	heroForm = new FormGroup({
		name: new FormControl('', Validators.required),
		pv: new FormControl(1, [Validators.required, Validators.min(1), Validators.max(37)]),
		att: new FormControl(1, [Validators.required, Validators.min(1), Validators.max(37)]),
		dodge: new FormControl(1, [Validators.required, Validators.min(1), Validators.max(37)]),
		dam: new FormControl(1, [Validators.required, Validators.min(1), Validators.max(37)]),
	}, { validators: this.totalLimitValidator() });

	@Input() hero: Hero = new Hero();

	constructor(private heroService: HeroService) {}

	totalLimitValidator(): ValidatorFn {
		return (control: AbstractControl): { [key: string]: any } | null => {
			const formGroup = control as FormGroup;
			const pv = formGroup.get('pv')?.value || 1;
			const att = formGroup.get('att')?.value || 1;
			const dodge = formGroup.get('dodge')?.value || 1;
			const dam = formGroup.get('dam')?.value || 1;

			const total = pv + att + dodge + dam;
			return total > 40 ? { totalLimit: { value: total } } : null;
		};
	}

	save() {
		if (this.heroForm.valid) {
			this.hero.name = this.heroForm.get('name')?.value || '';
			this.hero.pv = Number(this.heroForm.get('pv')?.value) || 1;
			this.hero.att = Number(this.heroForm.get('att')?.value) || 1;
			this.hero.dodge = Number(this.heroForm.get('dodge')?.value) || 1;
			this.hero.dam = Number(this.heroForm.get('dam')?.value) || 1;

			this.heroService.addHero(this.hero);
			this.snackbar();
			this.submitted = false;
		} else {
			console.log("Formulaire invalide !");
		}
	}

	getRemainingPoints(): number {
		const pv = Number(this.heroForm.get('pv')?.value) || 1;
		const att = Number(this.heroForm.get('att')?.value) || 1;
		const dodge = Number(this.heroForm.get('dodge')?.value) || 1;
		const dam = Number(this.heroForm.get('dam')?.value) || 1;

		const total = pv + att + dodge + dam;
		const maxPoints = 40;

		return maxPoints - total;
	}

	isFieldInvalid(field: string): boolean {
		// @ts-ignore
		return this.heroForm.get(field).invalid && (this.heroForm.get(field).dirty || this.heroForm.get(field).touched);
	}

	snackbar(): void{
		const x = document.getElementById("snackbar");
		if (x) {
			x.className = "show";
			setTimeout(() => {
				x.className = x.className.replace("show", "");
			}, 3000);
		}
	}
}
