import {Component, Input} from '@angular/core';
import {Hero} from "../model/hero";
import {HeroService} from "../../services/hero.service";
import {RouterLink} from "@angular/router";
import {Weapon} from "../model/weapon";
import {WeaponService} from "../../services/weapon.service";
import {FavoriteService} from "../../services/favorite.service";

@Component({
  selector: 'app-dashboard',
  standalone: true,
	imports: [
		RouterLink
	],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
	heroes: Hero[] = [];
	weapons: Weapon[] = [];
	favoriteHeroes: Hero[] = [];
	favoriteWeapons: Hero[] = [];

	constructor(private heroService: HeroService, private weaponService: WeaponService, private favoriteService: FavoriteService) {}

	ngOnInit(): void {
		this.getHeroes()
		this.getWeapons()
	}

	getHeroes(): void {
		this.favoriteService.getFavoriteHeroes().subscribe((heroes) => {
			this.favoriteHeroes = heroes;
		});
	}
	getWeapons(): void{
		this.favoriteService.getFavoriteWeapons().subscribe((weapons) => {
			this.favoriteWeapons = weapons;
		});	}
}
