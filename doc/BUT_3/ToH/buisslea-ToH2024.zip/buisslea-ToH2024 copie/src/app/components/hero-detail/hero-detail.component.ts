import {Component, Input} from '@angular/core';
import { UpperCasePipe, Location} from "@angular/common";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {Hero} from "../model/hero";
import {HeroService} from "../../services/hero.service";
import {ActivatedRoute, RouterLink, RouterOutlet} from "@angular/router";
import {ModifComponent} from "../modif/modif.component";
import {Weapon} from "../model/weapon";
import {Subscription} from "rxjs";

@Component({
	selector: 'app-hero-detail',
	standalone: true,
	imports: [
		ReactiveFormsModule,
		UpperCasePipe,
		FormsModule,
		RouterLink,
		RouterOutlet,
		ModifComponent,
	],
	templateUrl: './hero-detail.component.html',
	styleUrl: './hero-detail.component.css'
})
export class HeroDetailComponent {
	@Input() hero: Hero = new Hero();
	weapons: Weapon[] = [];
	selectedWeaponName: string | null = null;
	currentWeapon: Weapon | null = null;

	observable?: Subscription;

	constructor(
		private route: ActivatedRoute,
		private heroService: HeroService,
		private location: Location
	) {}

	ngOnInit(): void {
		this.getHero();
		this.getWeapons();

		if (this.hero && this.hero.weaponName) {
			this.selectedWeaponName = this.hero.weaponName;
		}
	}

	getHero(): void {
		const id = String(this.route.snapshot.paramMap.get('id'));
		this.observable = this.heroService.getHero(id).subscribe(hero => this.hero = hero);
	}

	getWeapons(): void {
		this.heroService.getWeapons().subscribe((weapons) => {
			this.weapons = weapons;

			if (this.hero && this.hero.weaponName) {
				this.currentWeapon = this.weapons.find(w => w.name === this.hero.weaponName) || null;
				this.selectedWeaponName = this.hero.weaponName;
			}
		});
	}

	assignWeapon(): void {
		const newWeapon = this.weapons.find(w => w.name === this.selectedWeaponName) || null;

		let newPv = this.hero.pv + (newWeapon?.pv || 0)
		let newAtt = this.hero.att + (newWeapon?.att || 0)
		let newDodge = this.hero.dodge + (newWeapon?.dodge || 0)
		let newDam = this.hero.dam + (newWeapon?.dam || 0)

		if (newPv < 1 || newAtt < 1 || newDodge < 1 || newDam < 1) {
			this.snackbar("Impossible, héro trop faible");
			this.selectedWeaponName = this.currentWeapon?.name || "Aucune";
			return;
		}

		this.hero.weaponName = newWeapon?.name || "Aucune";
		this.heroService.updateHero(this.hero);

		this.currentWeapon = newWeapon;
	}

	update(): void {
		this.heroService.updateHero(this.hero);
	}

	delete(id?: string): void {
		this.heroService.deleteHero(this.hero.idDoc = id);
		this.snackbar("Deleted");
	}

	snackbar(message?: string): void {
		const snackbarElement = document.getElementById("snackbar");
		if (snackbarElement) {
			if (message){
				snackbarElement.innerText = message;
			}
			snackbarElement.className = "show";
			setTimeout(() => {
				snackbarElement.className = snackbarElement.className.replace("show", "");
			}, 3000);
		}
	}


	goBack() {
		this.location.back();
	}

	ngOnDestroy() {
		this.observable?.unsubscribe();
	}
}
