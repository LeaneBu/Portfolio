import {Component,  OnInit} from '@angular/core';
import { UpperCasePipe} from "@angular/common";
import {FormsModule} from "@angular/forms";
import {Hero} from "../model/hero";
import {HeroDetailComponent} from "../hero-detail/hero-detail.component";
import {HeroService} from "../../services/hero.service";
import {MessageService} from "../../services/message.service";
import {RouterLink} from "@angular/router";
import {DashboardComponent} from "../dashboard/dashboard.component";
import {FavoriteService} from "../../services/favorite.service";
import {get} from "@angular/fire/database";

@Component({
	selector: 'app-heroes',
	standalone: true,
	imports: [
		UpperCasePipe,
		FormsModule,
		HeroDetailComponent,
		RouterLink,
		DashboardComponent
	],
	templateUrl: './heroes.component.html',
	styleUrl: './heroes.component.css'
})
export class HeroesComponent implements OnInit {
	heroes: Hero[] = [];
	selectedHero: Hero = new Hero();
	favoriteHeroes: Hero[] = [];
	favoriteStatus: { [id: string]: boolean } = {};
	filteredHeroes: Hero[] = [];
	searchTerm: string = '';

	onSelect(hero: Hero): void {
		this.selectedHero = hero;
		this.messageService.add(`Héros sélectionné id=`);
	}

	constructor(private heroService: HeroService, private messageService: MessageService, private favoriteService: FavoriteService) {
	}

	getHeroes(): void {
		this.heroService.getHeroes().subscribe(heroes => {
			this.heroes = heroes;
			this.heroes.forEach(hero => {
				this.favoriteService.isFavoriteHero(hero).subscribe(isFavorite => {
					this.favoriteStatus[hero.idDoc!] = isFavorite;
				});
			});
			this.filteredHeroes = heroes;
		});
	}

	ngOnInit(): void {
		this.getHeroes();
		this.refreshFavorites();
		this.filteredHeroes = this.heroes;
	}

	isFavoriteHero(hero: Hero): boolean {
		return this.favoriteStatus[hero.idDoc!] || false;
	}

	toggleFavorite(hero: Hero) {
		if (this.isFavoriteHero(hero)) {
			this.favoriteService.removeFavoriteHero(hero);
		} else {
			this.favoriteService.addFavoriteHero(hero);
		}

		this.refreshFavorites();
	}

	refreshFavorites() {
		this.favoriteService.getFavoriteHeroes().subscribe((heroes) => {
			this.favoriteHeroes = heroes;
		});
	}

	sortNameOrder: 'asc' | 'desc' = 'asc';

	sortList(): void {
		if (this.sortNameOrder === 'asc') {
			this.heroes.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
			this.sortNameOrder = 'desc';
		} else {
			this.heroes.sort((a, b) => b.name.toLowerCase().localeCompare(a.name.toLowerCase()));
			this.sortNameOrder = 'asc';
		}
		this.showDamageBars = false;
		this.showDefenseBars = false;
	}

	getCombinedDamage(hero: Hero): number {
		return (hero.dam || 0) + (hero.att || 0);
	}

	getCombinedDefense(hero: Hero): number {
		return (hero.dodge || 0) + (hero.pv || 0);
	}

	getBars(value: number, maxValue: number, type: 'life' | 'damage' | 'defense'): string[] {
		const maxBars = 8;
		const filledBars = Math.round((value / maxValue) * maxBars);
		const emptyBars = maxBars - filledBars;

		let filledIcon = '';
		let emptyIcon = '⚪';

		if (type === 'life') {
			filledIcon = '💚';
		} else if (type === 'damage') {
			filledIcon = '🔥';
		} else if (type === 'defense') {
			filledIcon = '🛡️';
		}

		return Array(filledBars).fill(filledIcon).concat(Array(emptyBars).fill(emptyIcon));
	}

	getBarsForCombinedValues(hero: Hero, type: 'damage' | 'defense'): string[] {
		let value = 0;

		if (type === 'damage') {
			value = this.getCombinedDamage(hero);
		} else if (type === 'defense') {
			value = this.getCombinedDefense(hero);
		}

		return this.getBars(value, 40, type);
	}



	showDamageBars: boolean = false;
	sortByDamageOrder: 'asc' | 'desc' = 'asc';

	sortByDamage(): void {
		this.heroes.sort((a, b) => {
			const combinedDamageA = (a.dam || 0) + (a.att || 0);
			const combinedDamageB = (b.dam || 0) + (b.att || 0);

			return this.sortByDamageOrder === 'asc'
				? combinedDamageA - combinedDamageB
				: combinedDamageB - combinedDamageA;
		});

		this.sortByDamageOrder = this.sortByDamageOrder === 'asc' ? 'desc' : 'asc';
		this.showDamageBars = true;
		this.showDefenseBars = false;
	}



	showDefenseBars: boolean = false;
	sortByDefenseOrder: 'asc' | 'desc' = 'asc';

	sortByDefense(): void {
		this.heroes.sort((a, b) => {
			const combinedDefenseA = (a.dodge || 0) + (a.pv || 0);
			const combinedDefenseB = (b.dodge || 0) + (b.pv || 0);

			return this.sortByDefenseOrder === 'asc'
				? combinedDefenseA - combinedDefenseB
				: combinedDefenseB - combinedDefenseA;
		});

		this.sortByDefenseOrder = this.sortByDefenseOrder === 'asc' ? 'desc' : 'asc';
		this.showDefenseBars = true;
		this.showDamageBars = false;
	}

	filterHeroes(): void {
		if (this.searchTerm) {
			this.filteredHeroes = this.heroes.filter(hero =>
				hero.name.toLowerCase().includes(this.searchTerm.toLowerCase())
			);
		} else {
			this.filteredHeroes = this.heroes;
		}
	}
}
