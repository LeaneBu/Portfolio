export class Hero {
  idDoc? : string = "";
  name: string = "";
  pv: number = 0;
  att: number = 0;
  dodge: number = 0;
  dam: number = 0;
  weaponName?: string | null;
  favoris ?: boolean;

  constructor(name: string = "", pv: number = 0, att: number = 0, dodge: number = 0, dam: number = 0) {
	  this.name = name;
	  this.pv = pv;
	  this.att = att;
	  this.dodge = dodge;
	  this.dam = dam;
  }
}
