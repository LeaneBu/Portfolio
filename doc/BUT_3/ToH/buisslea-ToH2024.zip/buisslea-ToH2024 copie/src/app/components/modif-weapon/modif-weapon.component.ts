import {Component, Input} from '@angular/core';
import {AbstractControl, FormControl, FormGroup, ReactiveFormsModule, ValidatorFn, Validators} from "@angular/forms";
import {ActivatedRoute} from "@angular/router";
import {Location} from "@angular/common";
import {WeaponService} from "../../services/weapon.service";
import {Weapon} from "../model/weapon";

@Component({
	selector: 'app-modif-weapon',
	standalone: true,
	imports: [
		ReactiveFormsModule
	],
	templateUrl: './modif-weapon.component.html',
	styleUrl: './modif-weapon.component.css'
})
export class ModifWeaponComponent {
	@Input() weapon: Weapon = new Weapon();

	weaponForm!: FormGroup;

	constructor(
		private route: ActivatedRoute,
		private weaponService: WeaponService,
		private location: Location
	) {
	}

	ngOnInit(): void {
		this.getWeapon();
	}

	getWeapon(): void {
		const id = String(this.route.snapshot.paramMap.get('id'));
		this.weaponService.getWeapon(id).subscribe(weapon => {
			this.weapon = weapon;
			this.initializeForm();
		});
	}

	initializeForm(): void {
		this.weaponForm = new FormGroup({
			name: new FormControl(this.weapon.name, [Validators.required]),
			pv: new FormControl(this.weapon.pv, [Validators.required, Validators.min(-5), Validators.max(5)]),
			att: new FormControl(this.weapon.att, [Validators.required, Validators.min(-5), Validators.max(5)]),
			dodge: new FormControl(this.weapon.dodge, [Validators.required, Validators.min(-5), Validators.max(5)]),
			dam: new FormControl(this.weapon.dam, [Validators.required, Validators.min(-5), Validators.max(5)]),
		}, {});
	}

	totalLimitValidator(): Boolean {
		const pv = this.weaponForm.get('pv')?.value || 0;
		const att = this.weaponForm.get('att')?.value || 0;
		const dodge = this.weaponForm.get('dodge')?.value || 0;
		const dam = this.weaponForm.get('dam')?.value || 0;



		const total = pv + att + dodge + dam;
		console.log(total)
		if (total == 0) {
			return true;
		} else {
			return false;
		}
	}

	save() {
		if (this.weaponForm.valid && this.totalLimitValidator()) {
			this.weapon.name = this.weaponForm.get('name')?.value || '';
			this.weapon.pv = Number(this.weaponForm.get('pv')?.value) || 0;
			this.weapon.att = Number(this.weaponForm.get('att')?.value) || 0;
			this.weapon.dodge = Number(this.weaponForm.get('dodge')?.value) || 0;
			this.weapon.dam = Number(this.weaponForm.get('dam')?.value) || 0;


			this.weaponService.updateWeapon(this.weapon);
			this.snackbar();
		} else {
			console.log(this.totalLimitValidator())
			console.log("Formulaire invalide !");
		}
	}

	getRemainingPoints(): number {
		const pv = Number(this.weaponForm.get('pv')?.value) || 0;
		const att = Number(this.weaponForm.get('att')?.value) || 0;
		const dodge = Number(this.weaponForm.get('dodge')?.value) || 0;
		const dam = Number(this.weaponForm.get('dam')?.value) || 0;

		const total = pv + att + dodge + dam;
		const maxPoints = 0;

		return maxPoints - total;
	}

	snackbar(): void {
		const x = document.getElementById("snackbar");
		if (x) {
			x.className = "show";
			setTimeout(() => {
				x.className = x.className.replace("show", "");
			}, 3000);
		}
	}

	isFieldInvalid(field: string): boolean {
		// @ts-ignore
		return this.weaponForm.get(field).invalid && (this.weaponForm.get(field).dirty || this.weaponForm.get(field).touched);
	}

	goBack() {
		this.location.back();
	}
}
