import {Component, Input, OnInit} from '@angular/core';
import {
	AbstractControl,
	FormControl,
	FormGroup,
	FormsModule,
	ReactiveFormsModule,
	ValidatorFn,
	Validators
} from "@angular/forms";
import {Hero} from "../model/hero";
import {HeroService} from "../../services/hero.service";
import {Location} from "@angular/common";
import {ActivatedRoute} from "@angular/router";

@Component({
	selector: 'app-modif',
	standalone: true,
	imports: [
		FormsModule,
		ReactiveFormsModule,
	],
	templateUrl: './modif.component.html',
	styleUrls: ['./modif.component.css'] // styleUrls au lieu de styleUrl
})
export class ModifComponent implements OnInit {
	submitted: boolean = false;
	@Input() hero: Hero = new Hero();

	heroForm!: FormGroup;

	constructor(
		private route: ActivatedRoute,
		private heroService: HeroService,
		private location: Location
	) {
	}

	ngOnInit(): void {
		this.getHero();
		this.initializeForm();
	}

	getHero(): void {
		const id = String(this.route.snapshot.paramMap.get('id'));
		this.heroService.getHero(id).subscribe(hero => {
			this.hero = hero;
			this.initializeForm();
		});
	}

	initializeForm(): void {
		this.heroForm = new FormGroup({
			name: new FormControl(this.hero.name, [Validators.required]),
			pv: new FormControl(this.hero.pv, [Validators.required, Validators.min(1), Validators.max(40)]),
			att: new FormControl(this.hero.att, [Validators.required, Validators.min(1), Validators.max(40)]),
			dodge: new FormControl(this.hero.dodge, [Validators.required, Validators.min(1), Validators.max(40)]),
			dam: new FormControl(this.hero.dam, [Validators.required, Validators.min(1), Validators.max(40)]),
		}, {});
	}

	totalLimitValidator(): Boolean {
		const pv = this.heroForm.get('pv')?.value || 1;
		const att = this.heroForm.get('att')?.value || 1;
		const dodge = this.heroForm.get('dodge')?.value || 1;
		const dam = this.heroForm.get('dam')?.value || 1;

		const total = pv + att + dodge + dam;

		if ((total <= 40) && (total >= 0)) {
			return true;
		} else {
			return false;
		}
	}

	save() {
		if (this.heroForm.valid && this.totalLimitValidator()) {
			this.hero.name = this.heroForm.get('name')?.value || '';
			this.hero.pv = Number(this.heroForm.get('pv')?.value) || 1;
			this.hero.att = Number(this.heroForm.get('att')?.value) || 1;
			this.hero.dodge = Number(this.heroForm.get('dodge')?.value) || 1;
			this.hero.dam = Number(this.heroForm.get('dam')?.value) || 1;

			this.heroService.updateHero(this.hero);
			this.snackbar();
			this.submitted = false;
		} else {
			console.log("Formulaire invalide !");
		}
	}

	getRemainingPoints(): number {
		const pv = Number(this.heroForm.get('pv')?.value) || 1;
		const att = Number(this.heroForm.get('att')?.value) || 1;
		const dodge = Number(this.heroForm.get('dodge')?.value) || 1;
		const dam = Number(this.heroForm.get('dam')?.value) || 1;

		const total = pv + att + dodge + dam;
		const maxPoints = 40;

		return maxPoints - total;
	}

	snackbar(): void {
		const x = document.getElementById("snackbar");
		if (x) {
			x.className = "show";
			setTimeout(() => {
				x.className = x.className.replace("show", "");
			}, 3000);
		}
	}

	isFieldInvalid(field: string): boolean {
		// @ts-ignore
		return this.heroForm.get(field).invalid && (this.heroForm.get(field).dirty || this.heroForm.get(field).touched);
	}

	goBack() {
		this.location.back();
	}

}
