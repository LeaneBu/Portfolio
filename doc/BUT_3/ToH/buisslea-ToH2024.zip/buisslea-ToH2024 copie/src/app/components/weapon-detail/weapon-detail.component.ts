import {Component, Input} from '@angular/core';
import {ActivatedRoute, RouterLink, RouterOutlet} from "@angular/router";
import {Location, UpperCasePipe} from "@angular/common";
import {Weapon} from "../model/weapon";
import {WeaponService} from "../../services/weapon.service";

@Component({
  selector: 'app-weapon-detail',
  standalone: true,
	imports: [
		RouterLink,
		RouterOutlet,
		UpperCasePipe
	],
  templateUrl: './weapon-detail.component.html',
  styleUrl: './weapon-detail.component.css'
})
export class WeaponDetailComponent {
	@Input() weapon: Weapon = new Weapon();

	constructor(
		private route: ActivatedRoute,
		private weaponService: WeaponService,
		private location: Location
	) {}

	ngOnInit(): void {
		this.getWeapon();
	}

	getWeapon(): void {
		const id = String(this.route.snapshot.paramMap.get('id'));
		this.weaponService.getWeapon(id).subscribe(weapon => this.weapon = weapon);
	}

	update(): void {
		this.weaponService.updateWeapon(this.weapon);
	}

	delete(id?: string): void {
		this.weaponService.deleteWeapon(this.weapon.idDoc = id);
		this.snackbar("Deleted");
	}

	snackbar(message?: string): void {
		const snackbarElement = document.getElementById("snackbar");
		if (snackbarElement) {
			if (message){
				snackbarElement.innerText = message;
			}
			snackbarElement.className = "show";
			setTimeout(() => {
				snackbarElement.className = snackbarElement.className.replace("show", "");
			}, 3000);
		}
	}


	goBack() {
		this.location.back();
	}
}
