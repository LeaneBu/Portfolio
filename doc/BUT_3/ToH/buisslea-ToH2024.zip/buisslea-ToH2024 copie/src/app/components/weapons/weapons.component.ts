import { Component } from '@angular/core';
import {RouterLink} from "@angular/router";
import {MessageService} from "../../services/message.service";
import {Weapon} from "../model/weapon";
import {WeaponService} from "../../services/weapon.service";
import {HeroDetailComponent} from "../hero-detail/hero-detail.component";
import {WeaponDetailComponent} from "../weapon-detail/weapon-detail.component";
import {FavoriteService} from "../../services/favorite.service";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";

@Component({
  selector: 'app-weapons',
  standalone: true,
	imports: [
		RouterLink,
		HeroDetailComponent,
		WeaponDetailComponent,
		ReactiveFormsModule,
		FormsModule
	],
  templateUrl: './weapons.component.html',
  styleUrl: './weapons.component.css'
})
export class WeaponsComponent {
	weapons: Weapon[] = [];
	selectedWeapon: Weapon = new Weapon();
	favoriteWeapons: Weapon[] = [];
	favoriteStatus: { [id: string]: boolean } = {};
	filteredWeapons: Weapon[] = [];
	searchTerm: string = '';


	onSelect(weapon: Weapon): void {
		this.selectedWeapon = weapon;
		this.messageService.add(`Arme sélectionnée id=`);
	}

	constructor(private weaponService: WeaponService, private messageService: MessageService, private favoriteService: FavoriteService) { }

	getWeapons(): void {
		this.weaponService.getWeapons().subscribe(weapons => {
			this.weapons = weapons;
			this.weapons.forEach(weapon => {
				this.favoriteService.isFavoriteWeapon(weapon).subscribe(isFavorite => {
					this.favoriteStatus[weapon.idDoc!] = isFavorite;
				});
			});
			this.filteredWeapons = this.weapons;
		});
	}

	ngOnInit(): void {
		this.getWeapons();
		this.refreshFavorites();
		this.filteredWeapons = this.weapons;
	}

	isFavoriteWeapon(weapon: Weapon) {
		return this.favoriteStatus[weapon.idDoc!] || false;
	}

	toggleFavorite(weapon: Weapon) {
		if (this.isFavoriteWeapon(weapon)) {
			this.favoriteService.removeFavoriteWeapon(weapon);
		} else {
			this.favoriteService.addFavoriteWeapon(weapon);
		}
		this.refreshFavorites();

	}

	refreshFavorites() {
		this.favoriteService.getFavoriteWeapons().subscribe((weapons) => {
			this.favoriteWeapons = weapons;
		});	}

	sortNameOrder: 'asc' | 'desc' = 'asc';

	sortList(): void {
		if (this.sortNameOrder === 'asc') {
			this.weapons.sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
			this.sortNameOrder = 'desc';
		} else {
			this.weapons.sort((a, b) => b.name.toLowerCase().localeCompare(a.name.toLowerCase()));
			this.sortNameOrder = 'asc';
		}
		this.showDamageBars = false;
	}

	getCombinedDamage(weapon: Weapon): number {
		return (weapon.dam || 0) + (weapon.att || 0);
	}

	getBars(value: number, maxValue: number, type: 'life' | 'damage' | 'defense'): string[] {
		const maxBars = 5;
		const valuePerBar = maxValue / maxBars;

		const clampedValue = Math.max(value, 0);

		const filledBars = Math.min(Math.max(Math.floor(clampedValue / valuePerBar), 0), maxBars);
		const emptyBars = maxBars - filledBars;

		let filledIcon = '';
		let emptyIcon = '⚪';

		if (type === 'life') {
			filledIcon = '💚';
		} else if (type === 'damage') {
			filledIcon = '⚔️';
		} else if (type === 'defense') {
			filledIcon = '🛡️';
		}

		return Array(filledBars).fill(filledIcon).concat(Array(emptyBars).fill(emptyIcon));
	}


	getBarsForCombinedValues(weapon: Weapon, type: 'damage' | 'defense'): string[] {
		let value = 0;
		let maxValue = 10;

		if (type === 'damage') {
			value = this.getCombinedDamage(weapon);
		}
		return this.getBars(value, maxValue, type);
	}




	showDamageBars: boolean = false;
	sortByDamageOrder: 'asc' | 'desc' = 'asc';

	sortByDamage(): void {
		this.weapons.sort((a, b) => {
			const combinedDamageA = (a.dam || 0) + (a.att || 0);
			const combinedDamageB = (b.dam || 0) + (b.att || 0);

			return this.sortByDamageOrder === 'asc'
				? combinedDamageA - combinedDamageB
				: combinedDamageB - combinedDamageA;
		});

		this.sortByDamageOrder = this.sortByDamageOrder === 'asc' ? 'desc' : 'asc';
		this.showDamageBars = true;
	}


	filterWeapons(): void {
		if (this.searchTerm) {
			this.filteredWeapons = this.weapons.filter(weapon =>
				weapon.name.toLowerCase().includes(this.searchTerm.toLowerCase())
			);
		} else {
			this.filteredWeapons = this.weapons;
		}
	}
}
