/*
import { HeroInterface } from './heroInterface';
export const HEROES: HeroInterface[] = [
  { id: 1, name: 'Thor' },
  { id: 2, name: 'Iron Man' },
  { id: 3, name: 'Hulk' },
  { id: 4, name: 'Spider Man' },
  { id: 5, name: 'Wolverine' },
  { id: 6, name: 'Black widow' },
  { id: 7, name: 'Wonder woman' },
  { id: 8, name: 'Cat woman' },
  { id: 9, name: 'Barman' },
];
*/
