import { Injectable } from '@angular/core';
import { Hero } from "../components/model/hero";
import {Weapon} from "../components/model/weapon";
import {collection, collectionData, doc, docData, Firestore, updateDoc} from "@angular/fire/firestore";
import {MessageService} from "./message.service";
import {from, map, Observable} from "rxjs";

@Injectable({
	providedIn: 'root'
})
export class FavoriteService {
	favoriteHeroes: Hero[] = [];
	favoriteWeapons: Weapon[] = [];

	private static readonly HEROES_COLLECTION = 'heroes';
	private static readonly WEAPONS_COLLECTION = 'weapons';

	constructor(private firestore: Firestore, private messageService: MessageService) {
	}

	setFavoriteHero(hero: Hero, isFavorite: boolean): Observable<void> {
		const heroDocRef = doc(this.firestore, `heroes/${hero.idDoc}`);
		return from(updateDoc(heroDocRef, { favoris: isFavorite }));
	}

	addFavoriteHero(hero: Hero): void {
		//if (!this.isFavoriteHero(hero)) {
			//this.favoriteHeroes.push(hero);
			//console.log(`${hero.name} ajouté aux favoris !`);
		//}
		const heroDocument = doc(this.firestore, `${FavoriteService.HEROES_COLLECTION}/${hero.idDoc}`);
		updateDoc(heroDocument, { favoris: true }).then(() => console.log(`${hero.name} ajouté aux favoris.`));
	}

	removeFavoriteHero(hero: Hero): void {
		//this.favoriteHeroes = this.favoriteHeroes.filter(h => h.idDoc !== hero.idDoc);
		//console.log(`${hero.name} retiré des favoris.`);
		const heroDocument = doc(this.firestore, `${FavoriteService.HEROES_COLLECTION}/${hero.idDoc}`);
		updateDoc(heroDocument, { favoris: false }).then(() => console.log(`${hero.name} retiré des favoris.`));
	}

	isFavoriteHero(hero: Hero): Observable<boolean> {
		//return this.favoriteHeroes.some(h => h.idDoc === hero.idDoc);
		const heroCollection = collection(this.firestore, FavoriteService.HEROES_COLLECTION);
		return collectionData(heroCollection, { idField: 'idDoc' }).pipe(
			map((heroes: Hero[]) => {
				const foundHero = heroes.find(h => h.idDoc === hero.idDoc);
				return !!foundHero?.favoris;
			})
		);
	}

	getFavoriteHeroes(): Observable<Hero[]> {
		const heroesCollection = collection(this.firestore, 'heroes');
		return collectionData(heroesCollection, { idField: 'idDoc' }).pipe(
			map((heroes: Hero[]) => heroes.filter(hero => hero.favoris === true))  // Filtrer les héros favoris
		);
	}

	addFavoriteWeapon(weapon: Weapon): void {
		const weaponDocRef = doc(this.firestore, `${FavoriteService.WEAPONS_COLLECTION}/${weapon.idDoc}`);
		updateDoc(weaponDocRef, { favoris: true }).then(() => console.log(`${weapon.name} ajouté aux favoris.`));
	}

	removeFavoriteWeapon(weapon: Weapon): void {
		const weaponDocRef = doc(this.firestore, `${FavoriteService.WEAPONS_COLLECTION}/${weapon.idDoc}`);
		updateDoc(weaponDocRef, { favoris: false }).then(() => console.log(`${weapon.name} retiré des favoris.`));
	}

	isFavoriteWeapon(weapon: Weapon): Observable<boolean> {
		//return this.favoriteWeapons.some(w => w.idDoc === weapon.idDoc);
		const weaponCollection = collection(this.firestore, FavoriteService.WEAPONS_COLLECTION);
		return collectionData(weaponCollection, { idField: 'idDoc' }).pipe(
			map((weapons: Weapon[]) => {
				const foundWeapon = weapons.find(w => w.idDoc === weapon.idDoc);
				return !!foundWeapon?.favoris;
			})
		);
	}

	getFavoriteWeapons(): Observable<Weapon[]> {
		const weaponCollectionRef = collection(this.firestore, FavoriteService.WEAPONS_COLLECTION);
		return collectionData(weaponCollectionRef, { idField: 'idDoc' }).pipe(
			map((weapons: Weapon[]) => weapons.filter((weapon) => weapon.favoris === true))
		);
	}
}
