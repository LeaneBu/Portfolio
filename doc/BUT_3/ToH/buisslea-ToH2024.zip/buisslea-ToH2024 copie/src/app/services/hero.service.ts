import {Injectable} from '@angular/core';
import {Hero} from "../components/model/hero";
import {Observable, of} from "rxjs";
// import {HEROES} from "../data/mock-heroes";
import { MessageService } from './message.service';
import {
	addDoc,
	collection,
	collectionData,
	deleteDoc,
	doc,
	docData,
	Firestore,
	updateDoc
} from "@angular/fire/firestore";
import {Weapon} from "../components/model/weapon";

@Injectable({
	providedIn: 'root'
})
export class HeroService {
	/*getHeroes(): Observable<HeroInterface[]> {
		const heroes = of(HEROES);
		/!*const heroes: Observable<HeroInterface[]> = new Observable(observer => {
			observer.next(HEROES.slice(0,2)); // 2 éléments envoyés
			setTimeout(() => {
				observer.next(HEROES); observer.complete();
			}, 3000); });*!/
		return heroes;
	}
	getHero(id: number): Observable<HeroInterface> {
		const hero = HEROES.find(h => h.id === id)!;
		if (id !== 0) {
			this.messageService.add(`HeroService: fetched hero id=${id}`);
		}
		return of(hero);

	}*/

	private static url = 'heroes';
	constructor(private firestore: Firestore, private messageService: MessageService) {
	}


	getHeroes(): Observable<Hero[]> {
		const heroCollection = collection(this.firestore, HeroService.url);
		return collectionData(heroCollection, { idField: 'idDoc' }) as Observable<Hero[]>;
	}

	getWeapons(): Observable<Weapon[]> {
		const weaponCollection = collection(this.firestore, 'weapons'); // Référence à la collection
		return collectionData(weaponCollection, { idField: 'idDoc' }) as Observable<Weapon[]>;
	}

	getHero(id: string): Observable<Hero> {
		const heroDocument = doc(this.firestore, HeroService.url + "/" + id);
		return docData(heroDocument, { idField: 'idDoc' }) as Observable<Hero>;
	}

	addHero(hero: Hero): void {
		const heroCollection = collection(this.firestore, HeroService.url);
		addDoc(heroCollection, {name: hero.name, pv: hero.pv, att: hero.att, dodge: hero.dodge, dam: hero.dam});
	}

	deleteHero(idDoc?: string): Promise<void> {
		const heroDocument = doc(this.firestore, HeroService.url + "/" + idDoc);
		return deleteDoc(heroDocument);
	}

	updateHero(hero: Hero): void {
		const heroDocument = doc(this.firestore, HeroService.url + "/" + hero.idDoc);
		let newHeroJSON = {name: hero.name, pv: hero.pv, att: hero.att, dodge: hero.dodge, dam: hero.dam, weaponName: hero.weaponName || null};
		updateDoc(heroDocument, newHeroJSON);
	}

}


