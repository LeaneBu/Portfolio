import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MessageService {
	messages: string[] = [];
	isVisible = false;

	add(message: string) {
		this.messages.push(message);
	}

	show() {
		this.isVisible = !this.isVisible;
	}

	clear() {
		this.messages = [];
	}
}
