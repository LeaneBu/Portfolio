import {Injectable} from '@angular/core';
import {
	addDoc,
	collection,
	collectionData,
	deleteDoc,
	doc,
	docData,
	Firestore,
	updateDoc
} from "@angular/fire/firestore";
import {MessageService} from "./message.service";
import {Observable} from "rxjs";
import {Weapon} from "../components/model/weapon";

@Injectable({
	providedIn: 'root'
})
export class WeaponService {

	private static url = 'weapons';

	constructor(private firestore: Firestore, private messageService: MessageService) {
	}

	getWeapons(): Observable<Weapon[]> {
		const weaponCollection = collection(this.firestore, WeaponService.url);
		return collectionData(weaponCollection, {idField: 'idDoc'}) as Observable<Weapon[]>;
	}

	getWeapon(id: string): Observable<Weapon> {
		const weaponDocument = doc(this.firestore, WeaponService.url + "/" + id);
		return docData(weaponDocument, {idField: 'idDoc'}) as Observable<Weapon>;
	}

	addWeapon(weapon: Weapon): void {
		const weaponCollection = collection(this.firestore, WeaponService.url);
		addDoc(weaponCollection, {
			name: weapon.name,
			pv: weapon.pv,
			att: weapon.att,
			dodge: weapon.dodge,
			dam: weapon.dam
		});
	}

	deleteWeapon(idDoc?: string): Promise<void> {
		const weaponDocument = doc(this.firestore, WeaponService.url + "/" + idDoc);
		return deleteDoc(weaponDocument);
	}

	updateWeapon(weapon: Weapon): void {
		const weaponDocument = doc(this.firestore, WeaponService.url + "/" + weapon.idDoc);
		let newWeaponJSON = {name: weapon.name, pv: weapon.pv, att: weapon.att, dodge: weapon.dodge, dam: weapon.dam};
		updateDoc(weaponDocument, newWeaponJSON);
	}
}
