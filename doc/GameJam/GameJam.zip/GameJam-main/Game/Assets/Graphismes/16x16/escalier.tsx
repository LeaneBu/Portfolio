<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="escalier" tilewidth="16" tileheight="16" tilecount="308" columns="22">
 <image source="../img/escaliers.png" width="352" height="224"/>
</tileset>
