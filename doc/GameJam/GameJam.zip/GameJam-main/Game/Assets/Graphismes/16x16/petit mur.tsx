<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="petit mur" tilewidth="8" tileheight="16" tilecount="360" columns="24">
 <image source="../img/noir.png" width="197" height="255"/>
</tileset>
