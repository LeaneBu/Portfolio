<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="tileset" tilewidth="16" tileheight="16" tilecount="64" columns="8">
 <image source="../img/tileset.png" trans="898989" width="128" height="128"/>
</tileset>
