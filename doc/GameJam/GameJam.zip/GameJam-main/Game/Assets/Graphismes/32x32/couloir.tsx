<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="couloir" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="../../../Downloads/normal.png" width="512" height="512"/>
</tileset>
