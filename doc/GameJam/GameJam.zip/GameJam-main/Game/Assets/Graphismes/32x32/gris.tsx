<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="gris" tilewidth="32" tileheight="32" margin="16" tilecount="36" columns="6">
 <image source="../../../Downloads/gris.jpeg" width="225" height="225"/>
</tileset>
