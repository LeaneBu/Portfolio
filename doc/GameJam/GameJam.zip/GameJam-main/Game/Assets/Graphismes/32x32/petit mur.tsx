<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="petit mur" tilewidth="16" tileheight="32" tilecount="84" columns="12">
 <image source="../../../Downloads/noir.png" width="197" height="255"/>
</tileset>
