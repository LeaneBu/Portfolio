import pygame
from Globals import *

class Button:    
    def __init__(self, x, y, w,h):
        self.image = pygame.Surface((w, h)).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.image.set_colorkey((0,0,0))
        self.collide = False

    def draw(self):
        Globals.screen.blit(self.image, self.rect)
    
    def detectClick(self):
        mousePos = pygame.mouse.get_pos()
        self.collide = 0

        if self.rect.collidepoint(mousePos):
            if pygame.mouse.get_pressed()[0] == 1 and self.collide == False:
                self.collide = True