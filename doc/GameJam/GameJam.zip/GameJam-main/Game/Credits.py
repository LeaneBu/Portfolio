import pygame
import Globals
from Button import *

from pygame import mixer

class Credits:
    def __init__(self):
        self.buttonRetour = Button(29,706,95,40)

        

    def draw(self):
        self.buttonRetour.draw()
    
    def process_events(self):
        self.buttonRetour.detectClick()


        if self.buttonRetour.collide == True:

            Globals.scene = 0
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        
        return True