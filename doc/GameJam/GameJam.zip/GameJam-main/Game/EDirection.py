
class Edirection():
    DOWN = 0
    DOWN_LEFT = 1
    DOWN_RIGHT = 2
    LEFT = 3
    RIGHT = 4
    UP = 5
    UP_LEFT = 6
    UP_RIGHT = 7
    STOP = 8