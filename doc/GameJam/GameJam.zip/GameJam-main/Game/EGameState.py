class EGameState: 
    RUNNING = 0
    MENU = 0
    END = 0
