import pygame
from pygame import mixer
from Player import *
from MapsTMX import *
from pytmx import load_pygame
from Globals import *
from EDirection import *
from EGameState import *


class Game :
    def __init__(self):
        self.player = Player()

        #Gestion des cartes TMX
        self.mapsManager = MapsTMX()
        self.mapsManager.setCurrentMapByID(0)
        self.gameState = EGameState.RUNNING

        #timer :
        self.timerFin = pygame.time.get_ticks() +  60000 * 5


        self.timerFont =  pygame.font.Font(None, 20)
        self.timerImage = 0



        self.colliders = []
        self.rect = pygame.Rect(self.player.rect)
        #self.updateColliders()

    def changeMusic(self) :
        mixer.music.load(self.music)
        mixer.music.play(-1)


    def process_events(self):
        """
        Process all of the events. Return a "False" to "running" if we need
        to close the window.
        """


        # poll for events
        # pygame.QUIT event means the user clicked to close the window
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        
        
        return True

    def gameOver(self):
        bgImage = pygame.image.load("Assets/Menu/game_over.png")
        bg = pygame.Rect((0,0),(0,0))
        image = pygame.Surface((Globals.screen.get_width(), Globals.screen.get_height())).convert_alpha()
        image.blit(bgImage,(0,0))
        Globals.screen.blit(image, bg)
        pygame.display.flip()
        pygame.time.wait(5000)

    def victory(sefl):
        bgImage = pygame.image.load("Assets/Menu/Victory.png")
        bg = pygame.Rect((0,0),(0,0))
        image = pygame.Surface((Globals.screen.get_width(), Globals.screen.get_height())).convert_alpha()
        image.blit(bgImage,(0,0))
        Globals.screen.blit(image, bg)
        pygame.display.flip()
        pygame.time.wait(5000)


    def running (self) :

        text = str( ( self.timerFin - pygame.time.get_ticks() ) / 1000 )
        

        #timer :
        self.timerImage = self.timerFont.render( text ,True,"black")

        if pygame.time.get_ticks() >= self.timerFin :
            self.gameOver()
            Globals.scene = 0

        if self.collidCoffre():
            self.victory()
            Globals.scene = 0
        



        allowY = allowX = 1

        #Gestion Clavier

        keystate = pygame.key.get_pressed()

        #Gestion des digonnales
        if (keystate[pygame.K_d] and keystate[pygame.K_z]) or (keystate[pygame.K_RIGHT] and keystate[pygame.K_UP]):
            if self.directionCollide(self.player.rect, "up"):
                allowY = 0
            if self.directionCollide(self.player.rect, "right"):
                allowX = 0
            self.player.animated(Edirection.UP_RIGHT)
            self.mapsManager.setOffset(self.mapsManager.offsetX + allowX*(0.70 * self.mapsManager.speed * Globals.deltaTime) ,self.mapsManager.offsetY - allowY*(0.70*self.mapsManager.speed* Globals.deltaTime) )
            
              
        elif (keystate[pygame.K_d] and keystate[pygame.K_s]) or (keystate[pygame.K_RIGHT] and keystate[pygame.K_DOWN]):
            if self.directionCollide(self.player.rect, "down"):
                allowY = 0
            if self.directionCollide(self.player.rect, "right"):
                allowX = 0
            self.player.animated(Edirection.DOWN_RIGHT)
            self.mapsManager.setOffset(self.mapsManager.offsetX + allowX*(0.70*self.mapsManager.speed * Globals.deltaTime)  ,self.mapsManager.offsetY + allowY*(0.70*self.mapsManager.speed* Globals.deltaTime) )
            
            
        elif (keystate[pygame.K_q] and keystate[pygame.K_z]) or (keystate[pygame.K_LEFT] and keystate[pygame.K_UP]):
            if self.directionCollide(self.player.rect, "up"):
                allowY = 0
            if self.directionCollide(self.player.rect, "left"):
                allowX = 0
            self.player.animated(Edirection.UP_LEFT)
            self.mapsManager.setOffset(self.mapsManager.offsetX - allowX*(0.70*self.mapsManager.speed * Globals.deltaTime) ,self.mapsManager.offsetY - allowY*(0.70*self.mapsManager.speed* Globals.deltaTime) )
            
            
        elif (keystate[pygame.K_q] and keystate[pygame.K_s]) or (keystate[pygame.K_LEFT] and keystate[pygame.K_DOWN]):
            if self.directionCollide(self.player.rect, "down"):
                allowY = 0
            if self.directionCollide(self.player.rect, "left"):
                allowX = 0
            self.player.animated(Edirection.DOWN_LEFT)
            self.mapsManager.setOffset(self.mapsManager.offsetX - allowX*(0.70*self.mapsManager.speed* Globals.deltaTime) ,self.mapsManager.offsetY + allowY*(0.70*self.mapsManager.speed* Globals.deltaTime) )
            
            
        #Gestions des 4 autres directions
        elif keystate[pygame.K_d] or keystate[pygame.K_RIGHT]:
            if self.directionCollide(self.player.rect, "right"):
                allowX = 0
            self.player.animated(Edirection.RIGHT)
            self.mapsManager.setOffsetX(self.mapsManager.offsetX + allowX*(self.mapsManager.speed* Globals.deltaTime) )
        elif keystate[pygame.K_q] or keystate[pygame.K_LEFT]:
            if self.directionCollide(self.player.rect, "left"):
                allowX = 0
            self.player.animated(Edirection.LEFT)
            self.mapsManager.setOffsetX(self.mapsManager.offsetX - allowX*(self.mapsManager.speed* Globals.deltaTime) )

        elif keystate[pygame.K_z] or keystate[pygame.K_UP]:
            if self.directionCollide(self.player.rect, "up"):
                allowY = 0
            self.player.animated(Edirection.UP)
            self.mapsManager.setOffsetY(self.mapsManager.offsetY - allowY*(self.mapsManager.speed* Globals.deltaTime) )

        elif keystate[pygame.K_s] or keystate[pygame.K_DOWN]:
            if self.directionCollide(self.player.rect, "down"):
                allowY = 0
            self.player.animated(Edirection.DOWN)
            self.mapsManager.setOffsetY(self.mapsManager.offsetY + allowY*(self.mapsManager.speed* Globals.deltaTime) )

        else:
            self.player.animated(Edirection.STOP)
    
    def collidCoffre(self):
        if Globals.positioncoffre.x > 480 and Globals.positioncoffre.y > 350 and Globals.positioncoffre.x < 530 and Globals.positioncoffre.y < 400:
            return True
        else:
            return False

    def directionCollide(self, rect1, direction):
        self.rect = pygame.Rect((rect1.x,rect1.y), (rect1.width, rect1.height))
        if direction == "right":
            self.rect.x += self.mapsManager.speed*Globals.deltaTime
            if self.rect.collidelist(self.colliders) != -1:
                return True
        if direction == "left":
            self.rect.x -= self.mapsManager.speed*Globals.deltaTime
            if self.rect.collidelist(self.colliders) != -1:
                return True
        if direction == "down":
            self.rect.y += self.mapsManager.speed*Globals.deltaTime
            if self.rect.collidelist(self.colliders) != -1:
                return True
        if direction == "up":
            self.rect.y -= self.mapsManager.speed*Globals.deltaTime
            if self.rect.collidelist(self.colliders) != -1:
                return True
        else:
            return False
    

    def update(self):
        self.running()

        mur = self.mapsManager.currentMap.get_layer_by_name("mur map")

        
        self.colliders.clear()

        for x,y,surface in mur.tiles():
                newSurf = pygame.Surface((32,32))
                pygame.transform.scale2x(surface, newSurf)
                position = (x*32 - self.mapsManager.offsetX, y*32 - self.mapsManager.offsetY)
                rect = pygame.Rect(position,(32,32))
                self.colliders.append(rect)


    def draw(self): 
        """
        Call the draw method of each entity 
        """
        self.mapsManager.drawCurrentMap()
        Globals.screen.blit( self.timerImage , (0,0))

        

        
