import pygame

class Globals :

    argumentSkin = "1"
    deltaTime = 0
    screen = 0
    scene = 0
    game = 0
    width = 1024
    height = 768
    display = pygame.Surface((width, height))
    positioncoffre = pygame.Rect((0,0),(0,0))
    coffreInit = 0
    

