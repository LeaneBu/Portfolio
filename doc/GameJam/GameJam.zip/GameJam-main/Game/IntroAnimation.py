import pygame
from Globals import *

from pygame import mixer

class IntroAnimation :


    def __init__(self) :
        self.all_frames = []

        self.loadImages()

        self.running = True
        
        self.debut = pygame.time.get_ticks()
        self.intervalFrame = 6000/120
        self.timeChangeFrame = pygame.time.get_ticks() + self.intervalFrame

        self.currentFrame = 0

        mixer.music.load("Assets/Intro/startupSong.mp3")
        mixer.music.play(1)

        self.update()
    
    def loadImages(self):
        defaultPath = "./Assets/Intro/frame-"

        for i in range(1,23) :
            path = defaultPath
            if i <= 9 :
                path += '0'
            
            path +=  str(i) + '.png'
            self.addFrame(path)


    def addFrame(self, filename) :
        surf = pygame.image.load(filename)
        self.all_frames.append ( surf )
    

    def update(self) :
        while self.running == True :
                
            if pygame.time.get_ticks() >= self.timeChangeFrame  :
                self.timeChangeFrame = pygame.time.get_ticks() + self.intervalFrame
                if self.currentFrame != len(self.all_frames) -1 :
                    self.currentFrame += 1
                
            Globals.screen.blit(self.all_frames[self.currentFrame], self.all_frames[self.currentFrame].get_rect())



            pygame.display.flip()



            if self.debut + pygame.time.get_ticks() >= self.debut + 2000 :
                self.running=False 

