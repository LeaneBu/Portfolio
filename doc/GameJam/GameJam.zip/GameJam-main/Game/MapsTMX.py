from pytmx import *
import pygame
from Globals import *



class MapsTMX :
    def __init__(self):

        #Tiled Map qui sera affiché
        self.currentMap = TiledMap()
        
        #Liste contenant toutes les TiledMAp
        self.all = []

        

        #Fonction qui load, et rempli la liste "all" de TiledMap
        self.load_all_TMX()

        #Les offsets permets de faire "defiler" la carte sous le joueur
        self.offsetX = 1*32
        self.offsetY = 190*32
        
        #Vitesse de deplacement de la carte sous le joueur
        self.speed = 0.25

        #Defini la premiere map de la liste "all", comme etant la map "active"
        self.setCurrentMapByID(0)


    def update(self, layer):
                for object in self.currentMap.objects :

                    if object.image:
                        if layer.name == "coffre lunette":
                            newSurf = pygame.Surface((32,32))
                            image= object.image
                            pygame.transform.scale2x(image, newSurf)
                            position = (object.x*2 - self.offsetX , object.y*2- self.offsetY)
                            Globals.positioncoffre = position
                            newSurf.convert_alpha()
                            newSurf.set_colorkey((0,0,0))
                            rect = pygame.Rect(position,(image.get_rect().width,image.get_rect().height ))
                            Globals.game.object = rect
                            Globals.display.blit(newSurf, position)

                #print(Globals.game.objects)
    



    #Chargement des Maps

    def load_all_TMX(self) :
        self.addMap("Assets/Graphismes/16x16/rdc(16x16).tmx")
    
    def addMap(self, filename) :
        tileMap = load_pygame(filename)
        self.all.append(tileMap)

    #Permet de modifier la map active    
    def setCurrentMapByID (self, mapId) :
        self.currentMap = self.all[mapId]


    #Modification des Offsets
    def setOffset(self,pos_x,pos_y) :
        self.offsetX = pos_x
        self.offsetY = pos_y
    
    def setOffsetX(self,pos_x) :
        self.offsetX = pos_x

    def setOffsetY(self, pos_y) :
        self.offsetY = pos_y



    #Fonction draw, qui parcours les Tiles de "currentMap" et double leur taille  et les affcihe au bon endroits
    def drawCurrentMap(self) :

        for layer in self.currentMap.visible_layers:
            if not hasattr(layer, 'data'):    
                #self.update( layer)
                continue    
           
            

            for x,y,surface in layer.tiles():
                if surface != None:
                    newSurf = pygame.Surface((32,32))
                    pygame.transform.scale2x(surface, newSurf)
                    newSurf.convert_alpha()
                    newSurf.set_colorkey((0,0,0))
                    position = (x*32 - self.offsetX, y*32 - self.offsetY)
                    if position < (1024,700) and position > (-50,-50):
                        Globals.display.blit(newSurf, position )
        
        rect = pygame.Rect((45*32 - self.offsetX, 95*32 - self.offsetY), (32,32))
        surf = pygame.Surface((32,32))
        surf.fill("brown")
        Globals.positioncoffre = rect
        Globals.display.blit(surf, (rect.x,rect.y))



        
        
        
        Globals.screen.blit(Globals.display, (0,0))

        