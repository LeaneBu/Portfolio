import pygame

from pygame import mixer

import Globals
from Button import *

class Menu:
    def __init__(self):
        self.buttonPlay = Button(102, 217,171,86)
        self.buttonQuit = Button(102,346,171,86)
        self.buttonCredit = Button(312,598,71,35)

        ## Provisoire si le temps de le déplaer
        self.player = pygame.image.load("Assets/Player/SkinSheet" + Globals.argumentSkin + ".png").convert_alpha()
        self.img = pygame.Surface((32,32)).convert_alpha()
        self.img.blit(self.player, (0,0), (32, 32, 32, 32))
        self.img.set_colorkey((0,0,0))

        self.changeMusicTo("Assets/Music/Beeeeeep.mp3")

    
    def changeMusicTo(self, filename) :
        mixer.music.load(filename)
        mixer.music.play(-1)

    def draw(self):
        self.buttonPlay.draw()
        self.buttonQuit.draw()
        self.buttonCredit.draw()
        rect = self.img.get_rect()
        rect.x , rect.y = 159, 651
        Globals.screen.blit(self.img, rect)


    def process_events(self):
        self.buttonPlay.detectClick()
        self.buttonQuit.detectClick()
        self.buttonCredit.detectClick()


        if self.buttonPlay.collide == True:
            self.changeMusicTo("Assets/Music/Play.mp3")
            Globals.game.__init__()
            Globals.scene = 1

        elif self.buttonQuit.collide == True:
            return False
        
        elif self.buttonCredit.collide == True:
            self.changeMusicTo("Assets/Music/creditSong.mp3")
            Globals.scene = 2
            
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
        
        return True