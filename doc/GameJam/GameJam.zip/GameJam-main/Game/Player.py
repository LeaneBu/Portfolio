import pygame
from Globals import *
from EDirection import *


class Player:

    def __init__(self):
        
        
        self.image = pygame.Surface((32, 32)).convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.x = 512
        self.rect.y = 384
        self.frame = 0
        self.wait = 0
        self.skin = "Assets/Player/SkinSheet"
        self.initImages(Globals.argumentSkin)
    


    def draw(self):
        Globals.screen.blit(self.image, self.rect)
        
    
    def initImages(self, numSkin):
        self.skin += numSkin + ".png"
    
    def animated(self, direction):
        if direction == Edirection.STOP:
            self.image = self.extract(1,0)
            self.frame = 1
        else:
            if self.frame == 1:
                self.frame = 0
            if self.wait == 1:

                if direction == Edirection.DOWN or direction == Edirection.DOWN_LEFT or direction == Edirection.DOWN_RIGHT:
                    self.image = self.extract(self.frame,0)
                
                elif direction == Edirection.LEFT:
                    self.image = self.extract(self.frame,1)
                
                elif direction == Edirection.RIGHT:
                    self.image = self.extract(self.frame,2)
                
                elif direction == Edirection.UP or direction == Edirection.UP_LEFT or direction == Edirection.UP_RIGHT:
                    self.image = self.extract(self.frame,3)
                    
                self.frame += 2
                self.frame %= 4
                self.wait = 0
                
            else:
                self.wait += 1

    def extract(self,x,y):
        skin = pygame.image.load(self.skin).convert_alpha()
        img = pygame.Surface((32,32)).convert_alpha()
        img.blit(skin, (0,0), ((x * 32), (y * 32), 32, 32))
        img.set_colorkey((0,0,0))
        
        return img
    
