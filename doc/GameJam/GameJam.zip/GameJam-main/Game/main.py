#!/bin/python3


import sys
import pygame
import pytmx
from Game import *
from Globals import *
from Menu import *
from Credits import *
from IntroAnimation import *

def verif_args(arg1):
    if arg1 == None:
        print("Aucun argument sélectionné, 4 options disponibles: \n\t-\"Boy\" \n\t-\"Girl\" \n\t-\"Cat\" \n\t-\"Dog\"")
        #Skin par defaut, donc "1" 
    elif arg1 == "Boy":
        Globals.argumentSkin = "1"
        #Skin par defaut, donc "1" 
    elif arg1 == "Girl":
        Globals.argumentSkin = "2"
    elif arg1 == "Cat":
        Globals.argumentSkin = "3"
    elif arg1 == "Dog":
        Globals.argumentSkin = "4"
    else:
        print(arg1, "n'est pas un argument valide, démarrage par défaut")
        #Skin par defaut, donc "1" 


def main() :


    pygame.init()
    Globals.screen = pygame.display.set_mode((Globals.width, Globals.height))
    pygame.display.set_caption("Scourge Awakens")
    clock = pygame.time.Clock()

    running = True



    IntroAnimation()

    Globals.game = Game()
    menu = Menu()
    credit = Credits()

    bgImage = pygame.image.load("Assets/Menu/background.png")
    creditImage = pygame.image.load("Assets/Menu/credits.png")
    bg = pygame.Rect((0,0),(0,0))
    image = pygame.Surface((Globals.screen.get_width(), Globals.screen.get_height())).convert_alpha()

    bgImage = pygame.image.load("Assets/Menu/background.png")

    while running:
        Globals.deltaTime = clock.tick(60)  # limits FPS to 60

        if Globals.scene == 0:
            image.blit(bgImage,(0,0))
            Globals.screen.blit(image, bg)
            
            #Globals.screen.fill("blue")
            menu.draw()
            running = menu.process_events()
        
        elif Globals.scene == 1:

            # Process events
            running = Globals.game.process_events()

            # Update object positions, check for collisions

            Globals.game.update()
            Globals.screen.fill("pink")
            Globals.game.draw()
            Globals.game.player.draw()
            

            ##Globals.game.draw()

        elif Globals.scene == 2:
            image.blit(creditImage,(0,0))
            Globals.screen.blit(image, bg)
            credit.draw()
            running = credit.process_events()

        # flip() the display to put your work on screen
        pygame.display.flip()
        

    pygame.quit()

if __name__ == '__main__' :
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        verif_args(arg)
    else:
        verif_args(None)

    main()