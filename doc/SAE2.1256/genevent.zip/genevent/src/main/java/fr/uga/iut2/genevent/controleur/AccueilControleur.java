package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Tournoi;
import fr.uga.iut2.genevent.util.Persisteur;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * La classe AccueilControleur est le controleur de l'interface "PageAccueil"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class AccueilControleur {

	private JavaFXGUI javaFXGUI;
	private final String ADD_BUTTON_ID = "caseAddTournoi";
	public AccueilControleur(JavaFXGUI javaFXGUI) {
		this.javaFXGUI = javaFXGUI;
	}
	@FXML
	private Circle logoCircle, imgTournoi;
	@FXML
	private CheckBox checkSuppr;
	@FXML
	private Button accBtnCreer, accBtnImporter, accBtnExporter, accBtnSupprimer;
	@FXML
	private Label labelSuppression, nomTournoi;
	@FXML
	private GridPane accGridPane;
	@FXML
	private VBox caseAddTournoi;
	@FXML
	private TextField textFieldRecherche;

	/**
	 * Génère l'affichage des tournois et les lie aux bon tournois lors du click sur l'und'entre eux en respectant les dimentions de la GridPane et gère le déplacement du boutton créer en fonction du nombre de tournois affichés
	 *
	 * @throws IOException
	 */
	public void loadTournoi() throws IOException {
		ArrayList<Tournoi> tournois = new ArrayList(javaFXGUI.getControleur().getApplication().getTournois().values());

		int i, j = 0, index = 0;
		for (i = 0; i < tournois.size()/accGridPane.getColumnCount() + 1; i++) {
			j = 0;
			while (j < accGridPane.getColumnCount() && index < tournois.size()) {
				VBox vbox = FXMLLoader.load(Objects.requireNonNull(javaFXGUI.getClass().getResource("TemplateTournoi.fxml")));
				vbox.setId(tournois.get(j).getNom());

				// accés au cercle de la template de tournoi
				Circle circle = (Circle) vbox.getChildren().get(1);
				circle.setFill(new ImagePattern(new Image(tournois.get(j).getLogo().getChemin())));

				// accés au label de la template de tournoi
				Label label = (Label) vbox.getChildren().get(2);
				label.setText(tournois.get(j).getNom());
				vbox.setOnMouseClicked(new EventHandler<MouseEvent>() {
					@Override
					public void handle(MouseEvent mouseEvent) {
						try {
							javaFXGUI.loadProjet((Stage) logoCircle.getScene().getWindow(), vbox.getId());
						} catch (IOException e) {
							throw new RuntimeException(e);
						}
					}
				});

				accGridPane.add(vbox, j, i);
				j++;
				index++;
			}
		}

		int k = 0;
		while (accGridPane.getChildren().get(k).getId().compareTo(ADD_BUTTON_ID) == 0 && k < accGridPane.getChildren().size()) {
			k++;
		}

		accGridPane.add(new VBox(accGridPane.getChildren().get(k)), j, i - 1);
	}

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		Image im = new Image(JavaFXGUI.class.getResource("defaultLogo.png").toString());
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
	}

	/**
	 * Affiche des "checkbox" pour permettre à l'utilisateur de choisir les tournois à supprimer sur la page d'accueil lors du clique sur le bouton "supprimer"
	 * Supprime les tournois séléctionnés lors du second click sur le boutton "supprimer"
	 *
	 * @param event
	 */
	@FXML
	public void onSupprClick(ActionEvent event) throws IOException {
		if(accGridPane.getChildren().size()!=1) {
			boolean b;

			if (accBtnCreer.disabledProperty().getValue()) {
				ArrayList<Tournoi> tournois = new ArrayList(javaFXGUI.getControleur().getApplication().getTournois().values());
				int i, j = 0, index = 0;
				b = false;
				for (i = 0; i < tournois.size()/accGridPane.getColumnCount() + 1; i++) {
					j = 0;
					while (j < accGridPane.getColumnCount() && index < tournois.size()) {
						VBox vbox = (VBox) accGridPane.getChildren().get(j+(3*i));
						CheckBox check = (CheckBox) vbox.getChildren().get(0);
						if (check.isSelected()){
							Label label = (Label) vbox.getChildren().get(2);
							javaFXGUI.getControleur().supprimerTournoi(label.getText());
						} else {
							check.setVisible(false);
						}

						j++;
						index++;
					}
				}
				javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
			} else {
				ArrayList<Tournoi> tournois = new ArrayList(javaFXGUI.getControleur().getApplication().getTournois().values());
				int i, j = 0, index = 0;
				b = true;
				for (i = 0; i < tournois.size()/accGridPane.getColumnCount() + 1; i++) {
					j = 0;
					while (j < accGridPane.getColumnCount() && index < tournois.size()) {
						VBox vbox = (VBox) accGridPane.getChildren().get(j+(3*i));
						vbox.getChildren().get(0).setVisible(true);
						j++;
						index++;
					}
				}
			}
			accBtnCreer.setDisable(b);
			accBtnImporter.setDisable(b);
			accBtnExporter.setDisable(b);
			caseAddTournoi.setDisable(b);
			textFieldRecherche.setDisable(b);
		} else {
			labelSuppression.setVisible(true);
		}
	}

	/**
	 * Ouverture de la page de création des tournoi lors du clique sur le bouton "creer" et désactive toute autre interaction
	 * <p>
	 *     Démarre le système de création des tournois
	 * </p>
	 * @param event
	 * @throws IOException si le chargement de la vue FXML échoue.
	 */
	@FXML
	public void onCreerClick(ActionEvent event) throws IOException {
		javaFXGUI.loadCreer((Stage) logoCircle.getScene().getWindow());
	}

	/**
	 * Affiche les CheckBox pour que l'utilisateur choisisse quels tournoi exporter lors du click sur le boutton "exporter" et désactive toute autre interaction
	 * Exporte individuellement les tournois séléctionnés lors du second click sur le boutton "exporter"
	 *
	 * @param event
	 */
	@FXML
	public void onExportClick(ActionEvent event) {
		if(accGridPane.getChildren().size()!=1) {
			boolean b;

			if (accBtnCreer.disabledProperty().getValue()) {
				ArrayList<Tournoi> tournois = new ArrayList(javaFXGUI.getControleur().getApplication().getTournois().values());
				int i, j = 0, index = 0;
				b = false;
				for (i = 0; i < tournois.size()/accGridPane.getColumnCount() + 1; i++) {
					j = 0;
					while (j < accGridPane.getColumnCount() && index < tournois.size()) {
						VBox vbox = (VBox) accGridPane.getChildren().get(j+(3*i));
						CheckBox check = (CheckBox) vbox.getChildren().get(0);
						if (check.isSelected()){
							Label label = (Label) vbox.getChildren().get(2);
							javaFXGUI.getControleur().exportationFichier(((Label) vbox.getChildren().get(2)).getText());
						}
						check.setSelected(false);
						check.setVisible(false);
						j++;
						index++;
					}
				}
			} else {
				ArrayList<Tournoi> tournois = new ArrayList(javaFXGUI.getControleur().getApplication().getTournois().values());
				int i, j = 0, index = 0;
				b = true;
				for (i = 0; i < tournois.size()/accGridPane.getColumnCount() + 1; i++) {
					j = 0;
					while (j < accGridPane.getColumnCount() && index < tournois.size()) {
						VBox vbox = (VBox) accGridPane.getChildren().get(j+(3*i));
						vbox.getChildren().get(0).setVisible(true);
						j++;
						index++;
					}
				}
			}
			accBtnCreer.setDisable(b);
			accBtnImporter.setDisable(b);
			accBtnSupprimer.setDisable(b);
			caseAddTournoi.setDisable(b);
			textFieldRecherche.setDisable(b);
		} else {
			labelSuppression.setVisible(true);
		}
	}

	/**
	 * Ouvre une fenêtre d'improt de fichier lors du click sur le boutton "import", fournis le nom du fichier à la fonction importationFichier du controleur
	 * recharge la fenêtre une fois l'import terminé
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onImportClick(ActionEvent event) throws IOException{
		FileChooser fileChooser = new FileChooser();
		File file = fileChooser.showOpenDialog(new Stage());
		javaFXGUI.getControleur().importationFichier(file.getName().substring(0, file.getName().length() - 4));
		javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
	}
}
