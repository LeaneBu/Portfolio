package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.*;
import fr.uga.iut2.genevent.util.Persisteur;
import fr.uga.iut2.genevent.vue.CLI;
import fr.uga.iut2.genevent.vue.IHM;
import fr.uga.iut2.genevent.vue.JavaFXGUI;

import java.io.IOException;
import java.util.*;


public class Controleur {

	private final Application application;
	private final IHM ihm;


	public Controleur(Application application) {
		this.application = application;

		// choisir la classe CLI ou JavaFXGUI
//		this.ihm = new CLI(this);
		this.ihm = new JavaFXGUI(this);
	}

	public Application getApplication() {
		return application;
	}

	public void demarrer() {
		this.ihm.demarrerInteraction();
	}

	public void saisirTournoi() {
		this.ihm.saisirNouveauTournoi(listNomTournois());
	}

	public void creerTournoi(IHM.InfosTournoi infos) {
		Logo logo;
		if(infos.logo != null) {
			logo = infos.logo;
		} else {
			logo = new Logo();
		}
		if (infos.typeTournoi == TypeTournoi.TOURNOI_ELIM) {
			this.application.nouveauTournoi( new TournoiElimination(
					infos.nbEquipe,
					infos.tailleEquipe,
					infos.date,
					infos.nom
					)
			);
//			this.ihm.informerUtilisateur(
//					"Nouveau tournoi : " + infos.nom + " créé.",
//					true
//			);
		} else if (infos.typeTournoi == TypeTournoi.TOURNOI_ROUND_ROBIN) {
			this.application.nouveauTournoi( new TournoiRoundRobin(
					infos.nbEquipe,
					infos.tailleEquipe,
					infos.date,
					infos.nom
					)
			);
//			this.ihm.informerUtilisateur(
//					"Nouveau tournoi : " + infos.nom + " créé.",
//					true
//			);
		}
	}


	public void saisirEquipe(String t){
		this.ihm.saisirNouvelEquipe(listEquipeMapper(t).keySet(), t);
	}

	public void creerEquipe(IHM.InfosEquipe infos, String tournoi) {
		Logo logo;
		if(infos.logo != null) {
			logo = infos.logo;
		} else {
			logo = new Logo();
		}
		this.application.getTournoi(tournoi).nouvelleEquipe(
				logo,
				infos.nom
		);
//		this.ihm.informerUtilisateur(
//				"Nouvelle équipe : " + infos.nom + " créée",
//				true
//		);
	}

	public void suppresionEquipes(String t) {
		this.ihm.choixSuppresionEquipes(listEquipeMapper(t).keySet(),t);
	}

	public void suppresionEquipe(String t, String e){
		application.getTournoi(t).removeEquipe(e);
//		this.ihm.informerUtilisateur("L'équipe " + e + " supprimée dans "
//				+ t, true);
	}

	public void interfaceModifierEquipe(String t) {
		this.ihm.saisirModifEquipe(t);
	}

	public void modifierEquipe(String t, String oldNomEquipe, IHM.InfosEquipe newEquipe) {
		application.getTournoi(t).getEquipe(oldNomEquipe).setLogo(newEquipe.logo);
		application.getTournoi(t).getEquipe(oldNomEquipe).setNomEquipe(newEquipe.nom);

//		this.ihm.informerUtilisateur("L'équipe " + oldNomEquipe + " à bien été modifiée dans "
//				+ t, true);
	}

	public void importationFichier(String t){
		try {
			application.importerTournoi(t);
			this.ihm.informerUtilisateur("Tournoi " + t + " importé.", true);
		} catch (ClassNotFoundException | IOException ignored) {
//			this.ihm.informerUtilisateur("Erreur irrécupérable pendant le chargement de l'état du tournoi " +
//					t + ".", false);
		}
	}

	public void choixImportationFichier(){
		this.ihm.importationTournoi();
	}

	public void exportationFichier(String t){
		try {
			application.exporterTournoi(getTounoi(t));
//			this.ihm.informerUtilisateur("Tournoi " + t + " exporté.", true);
		} catch (IOException ignored) {
//			this.ihm.informerUtilisateur("Erreur irrécupérable pendant la sauvegarde de l'état du tournoi " +
//					t + ".", false);
		}
	}

	public void choixExportationFichier(){
		this.ihm.exportationTournois();
	}

	public void listTournois(){
		this.ihm.afficherTournois(listNomTournois());
	}

	public Set<String> listNomTournois() {
		if(this.application.getTournois() == null){
			return null;
		} else {
			TreeSet<String> listTournoi = new TreeSet<>(this.application.getTournois().keySet());

			return listTournoi;
		}
	}

	public void ouvrirTournoi(String nomTournoi){
		afficherTournoi(nomTournoi);
		ihm.demarrerInteractionTournoi(getTournoi(nomTournoi).get());
	}

	public void afficherTournoi(String nomTournoi){
		ihm.afficherTournoi(getTournoi(nomTournoi).get());
	}

	public void modifierTournoi(IHM.InfosTournoi newParaTournoi, String oldParaTournoi){
		supprimerTournoi(oldParaTournoi);
		creerTournoi(newParaTournoi);
//		this.ihm.informerUtilisateur("Le tournoi "+oldParaTournoi+ " à bien été modifié.", true);

	}

	public Optional <IHM.InfosTournoi> getTournoi(String nomTournoi){
		Optional<IHM.InfosTournoi> optionalT;
		if (tournoiIsPresent(nomTournoi)) {
			Tournoi tournoi = application.getTournoi(nomTournoi);
			optionalT = Optional.of(new IHM.InfosTournoi(tournoi.getNom(),tournoi.getDate()
					,tournoi.getNbEquipe(),tournoi.getTailleEquipe(),tournoi.getTypeTournoi(),tournoi.getLogo()));

		} else {
			optionalT = Optional.empty();
		}
		return optionalT;
	}

	public HashMap<String,Equipe> listEquipeMapper(String t) {
		ArrayList<Equipe> equipes = application.getTournoi(t).getEquipes();

		HashMap<String,Equipe> equipesTrier = new HashMap<>();

		for (Equipe e : equipes){
			equipesTrier.put(e.getNomEquipe(),e);
		}

		return equipesTrier;
	}

	public void listEquipes(String t){
		ihm.afficherEquipes(listEquipeMapper(t).keySet());
	}

	public IHM.InfosEquipe accesEquipe(String nomEquipe, String t){
		Equipe equipe = application.getTournoi(t).getEquipe(nomEquipe);
		return new IHM.InfosEquipe(equipe.getNomEquipe(), equipe.getLogo());
	}

	public void interfaceAffichageRencontre(String t){
		ihm.demarrerInteractionRencontre(t);
	}

	public IHM.InfosRencontre[][] getRencontresTournoi(String t) {
		Rencontre[][] rencontres = application.getTournoi(t).getRencontres();
		int nbEtage = application.getTournoi(t).getNbEtage();

		IHM.InfosRencontre[][] infoRencontres = new IHM.InfosRencontre[nbEtage][];
		for (int i = 0; i < nbEtage; i++) {
			infoRencontres[i] = new IHM.InfosRencontre[rencontres[i].length];

			for (int j = 0; j < rencontres[i].length; j++){
				if (rencontres[i][j] != null && rencontres[i][j].getEquipe2() != null) {
					infoRencontres[i][j] = new IHM.InfosRencontre(
							rencontres[i][j].getEquipe1().getNomEquipe(),
							rencontres[i][j].getEquipe2().getNomEquipe(),
							rencontres[i][j].getScoreE1(),
							rencontres[i][j].getScoreE2(),
							rencontres[i][j].getNiveauRencontre(),
							rencontres[i][j].getIdRencontre(),
							rencontres[i][j].getBO()
					);
				}
			}
		}

		return infoRencontres;
	}

	public IHM.InfosRencontre getRencontreTournoi(String t, int id){
		Rencontre[][] rencontres = application.getTournoi(t).getRencontres();
		int i = 0;
		int j = 0;
		boolean trouve = false;
		while (i < rencontres.length && !trouve) {
			j = 0;
			while (j < rencontres[i].length && !trouve ){
				if (rencontres[i][j] != null && rencontres[i][j].getIdRencontre() == id){
					trouve = true;
				}else{
					j++;
				}
			}
			if (!trouve){
				i++;
			}
		}
		Rencontre rencontre = application.getTournoi(t).getRencontre(i,j);

		IHM.InfosRencontre infosRencontre = new IHM.InfosRencontre(
				rencontre.getEquipe1().getNomEquipe(),
				rencontre.getEquipe2().getNomEquipe(),
				rencontre.getScoreE1(),
				rencontre.getScoreE2(),
				rencontre.getNiveauRencontre(),
				rencontre.getIdRencontre(),
				rencontre.getBO()
		);
		infosRencontre.setIndex(j);

		return infosRencontre;
	}

	public ArrayList<Integer> getIdRencontres(IHM.InfosRencontre[][] rencontres){
		ArrayList<Integer> iD = new ArrayList<>();

		for (int i = 0; i < rencontres.length; i++) {
			for (int j = 0; j < rencontres[i].length; j++){
				if (rencontres[i][j] != null && rencontres[i][j].equipe1 != null) {
					iD.add(rencontres[i][j].idRencontre);
					}
				}
			}
		return iD;
	}

	public ArrayList<IHM.InfosMatch> getMatch(IHM.InfosRencontre rencontre, String t) {
		ArrayList<Match> listMatch = application.getTournoi(t).getRencontre(rencontre.lvRencontre, rencontre.index).getListMatch();
		ArrayList<IHM.InfosMatch> listInfoMatch = new ArrayList<>();

		int index = 0;
		for (Match m : listMatch){
			IHM.InfosMatch infosMatch = new IHM.InfosMatch(
					m.getEquipe1().getNomEquipe(),
					m.getEquipe2().getNomEquipe(),
					m.getScoreEquipe1().get(),
					m.getScoreEquipe2().get()
			);
			infosMatch.setIndex(index);
			listInfoMatch.add(infosMatch);
			index++;
		}

		return listInfoMatch;
	}

	public void setScoreMatch(IHM.InfosMatch newMatch, String nomTournoi, IHM.InfosRencontre rencontre){
		Match match = application.getTournoi(nomTournoi).getRencontre(rencontre.lvRencontre, rencontre.index).getListMatch().get(newMatch.index);
		match.setScoreMatch(newMatch.scoreE1, newMatch.scoreE2);
//		this.ihm.informerUtilisateur("Les score on bien été changé", true);
	}

	public void supprimerTournoi(String tournoi) {
		application.supprimerTournoi(application.getTournoi(tournoi));
//		this.ihm.informerUtilisateur("Tournoi " + tournoi + " supprimé.", true);
	}

	public void choixSupprimerTournoi() {
		this.ihm.supprimerTournoi();
	}

	public Tournoi	getTounoi (String nomTournoi) {
		return application.getTournoi(nomTournoi);
	}

	public boolean tournoiIsPresent(String nom) {
		return application.getTournois().containsKey(nom);
	}

	public boolean canAddEquipe(String nom) {
		return application.getTournoi(nom).getEquipes().size() != application.getTournoi(nom).getNbEquipe();
	}


	public static boolean isPuissance2(int nb){
		while ((nb%2) == 0){
			nb = nb/2;
		}
		return nb == 1;
	}

	public void affichageClassement(String t){
		TreeSet<Equipe> classement = application.getTournoi(t).creerClassement();

		ArrayList<String> infoClassement = new ArrayList<>();

		for (Equipe e : classement){
			infoClassement.add(e.getNomEquipe());
		}

		this.ihm.afficherClassement(infoClassement);
	}

	public boolean isRencontreJouer(int id, String nomTournoi){
		Rencontre[][] rencontres = application.getTournoi(nomTournoi).getRencontres();
		int i = 0;
		int j = 0;
		boolean trouve = false;
		while (i < rencontres.length && !trouve) {
			j = 0;
			while (j < rencontres[i].length && !trouve ){
				if (rencontres[i][j] != null && rencontres[i][j].getIdRencontre() == id){
					trouve = true;
				}else{
					j++;
				}
			}
			if (!trouve){
				i++;
			}
		}
		Rencontre rencontre = application.getTournoi(nomTournoi).getRencontre(i,j);

		return rencontre.isJouer();
	}

	public void setBO(String nomTournoi, int idrencontre, int newBO){
		Rencontre[][] rencontres = application.getTournoi(nomTournoi).getRencontres();
		int i = 0;
		int j = 0;
		boolean trouve = false;
		while (i < rencontres.length && !trouve) {
			j = 0;
			while (j < rencontres[i].length && !trouve ){
				if (rencontres[i][j] != null && rencontres[i][j].getIdRencontre() == idrencontre){
					trouve = true;
				}else{
					j++;
				}
			}
			if (!trouve){
				i++;
			}
		}
		Rencontre rencontre = application.getTournoi(nomTournoi).getRencontre(i,j);

		rencontre.setBO(newBO);
//		this.ihm.informerUtilisateur("Le BO a bien été changé", true);
	}






}
