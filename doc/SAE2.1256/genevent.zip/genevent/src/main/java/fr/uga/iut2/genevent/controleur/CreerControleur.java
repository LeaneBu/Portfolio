package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.TypeTournoi;
import fr.uga.iut2.genevent.vue.IHM;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Set;

/**
 * La classe CreerControleur est le controleur de l'interface "creer"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class CreerControleur {


	private JavaFXGUI javaFXGUI;

	public CreerControleur(JavaFXGUI javaFXGUI) {
		this.javaFXGUI = javaFXGUI;
	}

	@FXML
	private Circle logoCircle;
	@FXML
	private Button btnAnnuler, btnCreer;
	@FXML
	private TextField tfNomTournoi;
	@FXML
	private Spinner spinner1, spinner2;
	@FXML
	private ComboBox cbTypeTournoi;
	@FXML
	private DatePicker dpDateDebut;
	@FXML
	private Label labelNom, labelDate, lErrNom, lErrNbEquipe, lErrDate;

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
		dpDateDebut.setValue(LocalDate.now());
	}

	/**
	 * Retour sur la page d'accueil lors du clique sur le bouton "annuler"
	 * <p>
	 *     Annule la création du tournoi et permet à l'utilisateur de revenir en arrière
	 * </p>
	 * @param event
	 * @throws IOException si le chargement de la vue FXML échoue.
	 */
	@FXML
	public void onAnnulerClick(ActionEvent event) throws IOException {
		javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
	}

	/**
	 * Ouverture de la page d'affichage et de modification des tournoi lors du clique sur le bouton "creer"
	 * <p>
	 *     Affiche des messages d'erreur si les données saisies ne sont pas valides pour nous le retournous à l'utilisateur
	 * </p>
	 * @param event
	 * @throws IOException si le chargement de la vue FXML échoue.
	 */

	@FXML
	public void onCreerClick(ActionEvent event){
		boolean ok = true;
		lErrNom.setVisible(false);
		lErrNbEquipe.setVisible(false);
		lErrDate.setVisible(false);

		Set<String> listTournoi = javaFXGUI.getControleur().listNomTournois();

		if (tfNomTournoi.getText().compareTo("") == 0 ){
			ok = false;
			lErrNom.setText("Le nom doit être renseigné.");
			lErrNom.setVisible(true);
		} else if (listTournoi.contains(tfNomTournoi.getText())) {
			ok = false;
			lErrNom.setText("Le nom est déja utilisé.");
			lErrNom.setVisible(true);
		}

		if (cbTypeTournoi.getValue()==null){
			cbTypeTournoi.setValue("Round Robin");
		} else {
			if (cbTypeTournoi.getValue().toString().compareTo("Élimination")==0 && !javaFXGUI.getControleur().isPuissance2((Integer) spinner1.getValue())){
				ok = false;
				lErrNbEquipe.setVisible(true);
			}
		}
		if (dpDateDebut.getValue().compareTo(LocalDate.now())<0) {
			ok=false;
			lErrDate.setVisible(true);
		}

		if (ok) {
			try {
				if (cbTypeTournoi.getValue().toString().compareTo("Élimination")==0) {
					IHM.InfosTournoi tournoiElim = new IHM.InfosTournoi(tfNomTournoi.getText(), dpDateDebut.getValue(), (Integer) spinner1.getValue(),
							(Integer) spinner2.getValue(), TypeTournoi.TOURNOI_ELIM, null);
					javaFXGUI.getControleur().creerTournoi(tournoiElim);
				} else if (cbTypeTournoi.getValue().toString().compareTo("Round Robin")==0){
					IHM.InfosTournoi tournoiRond = new IHM.InfosTournoi(tfNomTournoi.getText(), dpDateDebut.getValue(), (Integer) spinner1.getValue(),
							(Integer) spinner2.getValue(), TypeTournoi.TOURNOI_ROUND_ROBIN, null);
					javaFXGUI.getControleur().creerTournoi(tournoiRond);
				}

				javaFXGUI.loadProjet((Stage) logoCircle.getScene().getWindow(), tfNomTournoi.getText());

			} catch(Exception e) {
				e.printStackTrace();
			}
		}



	}
}
