package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Logo;
import fr.uga.iut2.genevent.modele.Tournoi;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

/**
 * La classe EquipeControleur est le controleur de l'interface "equipe"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class EquipeControleur {

	private JavaFXGUI javaFXGUI;

	public EquipeControleur(JavaFXGUI javaFXGUI) {

		this.javaFXGUI= javaFXGUI;
	}
	@FXML
	private Circle logoCircle;
	@FXML
	private CheckBox checkSuppr;
	@FXML
	private Button btnAddEquipe, btnSave, btnTournoi, btnRencontre, btnHome;
	@FXML
	private GridPane gridPaneEquipe;
	private Tournoi tournoi;

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
	}

	public void afficherEquipes(Tournoi tournoi) throws IOException{
		this.tournoi=tournoi;
		int j = 0;
		int index = 0;
		for (int i = 0; i < tournoi.getNbEquipe()/gridPaneEquipe.getColumnCount() + 1; i++) {
			j = 0;
			while (j < gridPaneEquipe.getColumnCount() && index < tournoi.getNbEquipe() ) {
				HBox hbox = FXMLLoader.load(Objects.requireNonNull(javaFXGUI.getClass().getResource("TemplateEquipe.fxml")));
				hbox.setMinWidth(380);
				hbox.setPrefWidth(380);

				Label nomEquipe = (Label) hbox.getChildren().get(1);
				nomEquipe.setText(tournoi.getEquipes().get(index).getNomEquipe());

				Circle circle = (Circle) hbox.getChildren().get(0);
				circle.setFill(new ImagePattern(new Image(tournoi.getEquipes().get(index).getLogo().getChemin())));

				System.out.println(i + " : " + j + " : " + index);
				gridPaneEquipe.add(hbox, j, i);
				j++;
				index++;
			}
		}
	}

	/**
	 * Affiche des "checkbox" pour permettre à l'utilisateur de choisir les tournois à supprimer sur la page d'accueil lors du clique sur le bouton "supprimer"
	 *
	 * @param event
	 */
	@FXML
	public void supprEquipe(ActionEvent event){
		boolean b;
		if (checkSuppr.visibleProperty().getValue()){
			b=false;
		} else {
			b=true;
		}
		checkSuppr.setVisible(b);
		btnAddEquipe.setDisable(b);
		btnSave.setDisable(b);
		btnTournoi.setDisable(b);
		btnRencontre.setDisable(b);
		btnHome.setDisable(b);
	}
	@FXML
	public void onHomeClick(ActionEvent event) throws IOException {
		javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
	}
	@FXML
	public void onTournoiClick(ActionEvent event) throws IOException {
		javaFXGUI.loadProjet((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}
	@FXML
	public void onRencontreClick(ActionEvent event) throws IOException {
		javaFXGUI.loadRencontre((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}
}
