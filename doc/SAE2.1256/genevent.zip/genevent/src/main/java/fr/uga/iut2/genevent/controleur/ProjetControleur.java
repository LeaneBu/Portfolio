package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Logo;
import fr.uga.iut2.genevent.modele.Tournoi;
import fr.uga.iut2.genevent.vue.IHM;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
/**
 * La classe ProjetControleur est le controleur de l'interface "projet"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class ProjetControleur {

	private JavaFXGUI javaFXGUI;

	public ProjetControleur(JavaFXGUI javaFXGUI){
		this.javaFXGUI = javaFXGUI;
	}

	@FXML
	private Circle logoCircle, logoTournoi;
	@FXML
	private Button btnHome, btnModifierTournoi, btnRencontre, btnEquipe, btnSave;
	@FXML
	private TextField tfNomTournoi, tfNbEquipes, tfTailleEquipe;
	@FXML
	private Label lTypeTournoi, lErreur1, lErreur2, lErreur3, labelDate;
	@FXML
	private DatePicker dpDateDebut;
	@FXML
	private Controleur controleur;
	private Tournoi ancienTournoi;
	private Tournoi tournoi;
	private String ancienneDate;

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
		logoTournoi.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("defaultLogo.png").toString())));

	}

	/**
	 * Affiche les informations d'un tournoi au chargement de la page
	 *
	 * @param tournoi
	 */
	public void labelsTournoi(Tournoi tournoi){
		this.tournoi=tournoi;
		tfNomTournoi.setText(tournoi.getNom());
		tfNbEquipes.setText(Integer.toString(tournoi.getNbEquipe()));
		if (tournoi.getTypeTournoi().toString() == "TOURNOI_ROUND_ROBIN") {
			lTypeTournoi.setText("Round Robin");
		} else if (tournoi.getTypeTournoi().toString() == "TOURNOI_ELIM") {
			lTypeTournoi.setText("Élination directe");
		}
		tfTailleEquipe.setText(Integer.toString(tournoi.getTailleEquipe()));
		dpDateDebut.setValue(tournoi.getDate());
		dpDateDebut.setDisable(true);
		dpDateDebut.opacityProperty().setValue(1);
	}

	/**
	 * Charge la page d'accueil
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onHomeClick(ActionEvent event) throws IOException {
		javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
	}

	/**
	 * Change les champs d'informations pour qu'ils soient modifiables au click du boutton "modifier"
	 *
	 * @param event
	 */
	@FXML
	public void onModifierClick(ActionEvent event) {
		tfNomTournoi.setEditable(true);
		tfNbEquipes.setEditable(true);
		tfTailleEquipe.setEditable(true);
		dpDateDebut.setDisable(false);
		btnSave.setVisible(true);
		ancienTournoi = javaFXGUI.getControleur().getTounoi(tfNomTournoi.getText());
		ancienneDate = dpDateDebut.getValue().toString();//avec to do date
	}

	/**
	 * Récupère les nouvelles informations données par l'utilisateur et vérifie qu'elles soient correctes
	 * Si les informations sont correctes, les champs ne sont plus modifiables et le tournoi est modifié
	 * Sinon les messages d'avertissement adéquats s'affichent sous les valeurs erronées
	 *
	 * @param event
	 */
	public void onSaveClick(ActionEvent event){
		boolean ok = true, datechangee=true;
		if (tfNomTournoi.getText().compareTo("")==0){
			ok = false;
			tfNomTournoi.setBackground(new Background(new BackgroundFill(Paint.valueOf("FA0020"), new CornerRadii(10), Insets.EMPTY)));
		}
		if (!isNumeric(tfNbEquipes.getText())){
			ok = false;
			lErreur1.setVisible(true);
		} else {
			lErreur1.setVisible(false);
		}
		if (!isNumeric(tfTailleEquipe.getText())){
			ok = false;
			lErreur2.setVisible(true);
		} else {
			lErreur2.setVisible(false);
		}
		if (dpDateDebut.getValue().toString().compareTo(ancienneDate)==0 || dpDateDebut.getValue().compareTo(LocalDate.now())>=0) {
			datechangee=false;
			lErreur3.setVisible(false);
		} else {
			ok = false;
			lErreur3.setVisible(true);
		}


		if (ok) {
			tfNomTournoi.setEditable(false);
			tfNbEquipes.setEditable(false);
			tfTailleEquipe.setEditable(false);
			dpDateDebut.setDisable(true);
			dpDateDebut.setOpacity(1);
			btnSave.setVisible(false);
			try {
				javaFXGUI.getControleur().modifierTournoi( new IHM.InfosTournoi(tfNomTournoi.getText(), dpDateDebut.getValue(), Integer.parseInt(tfNbEquipes.getText()),
						Integer.parseInt(tfTailleEquipe.getText()), ancienTournoi.getTypeTournoi(),new Logo()),ancienTournoi.getNom());
				tournoi = javaFXGUI.getControleur().getTounoi(tfNomTournoi.getText());
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Vérifie si une chaîne de caractères en entrée n'est composée seulement de chiffres ou non
	 *
	 * @param s
	 * @return
	 */
	private static boolean isNumeric(String s){
		return (s.compareTo("")!=0 && s.matches("[0-9]+"));
	}

	/**
	 * Charge la page des rencontres en lui donnant connaissance du tournoi ouvert
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onRencontreClick(ActionEvent event) throws IOException {
		javaFXGUI.loadRencontre((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}

	/**
	 * Charge la page des équipes en lui donnant connaissance du tournoi ouvert
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onEquipeClick(ActionEvent event) throws IOException {
		javaFXGUI.loadEquipe((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}


}
