package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.modele.Tournoi;
import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;
import java.util.Objects;

/**
 * La classe RencontreControleur est le controleur de l'interface "Rencontre"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class RencontreControleur {

	private JavaFXGUI javaFXGUI;

	public RencontreControleur(JavaFXGUI javaFXGUI) {
		this.javaFXGUI = javaFXGUI;
	}

	@FXML
	private Circle logoCircle;
	@FXML
	private Button btnHome, btnTournoi, btnEquipe;
	@FXML
	private GridPane gridPaneRencontre;
	private Tournoi tournoi;

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
	}

	/**
	 * Affiche les rencontres à l'affichege de la page en respectant un formatage selon le type de tournois à afficher
	 *
	 * @param tournoi
	 * @throws IOException
	 */
	public void afficherRencontres(Tournoi tournoi) throws IOException {
		this.tournoi = tournoi;
		for (int i = 0; i < tournoi.getNbEtage(); i++) {
			// ajoute a chaque nouvelle étape du label indiquant le numero de cette dernière.
			Label label = new Label("Round " + (i + 1));
			label.fontProperty().set(new Font(30));
			label.setMinWidth(380);
			label.setPrefWidth(380);
			label.setAlignment(Pos.CENTER);

			gridPaneRencontre.add(label , i, 0);
			for (int j = 0; j < tournoi.getRencontres()[i].length; j++) {
				if (tournoi.getRencontre(i, j) != null) {
					HBox hbox = FXMLLoader.load(Objects.requireNonNull(javaFXGUI.getClass().getResource("TemplateRencontre.fxml")));
					hbox.setMinWidth(380);
					hbox.setPrefWidth(380);

					Label labelEquipe1 = (Label) hbox.getChildren().get(0);
					labelEquipe1.setText(labelEquipe1.getText() + tournoi.getRencontre(i, j).getEquipe1().getNomEquipe());

					Label labelScore = (Label) hbox.getChildren().get(1);
					labelScore.setText(tournoi.getRencontre(i , j).getEquipe1().getScore() + " | " + tournoi.getRencontre(i, j).getEquipe1().getScore());

					Label labelEquipe2 = (Label) hbox.getChildren().get(2);
					labelEquipe2.setText(labelEquipe2.getText() + tournoi.getRencontre(i, j).getEquipe2().getNomEquipe());

					gridPaneRencontre.add(hbox, i, j + 1);
				}
			}
		}
	}

	/**
	 * Charge la page d'accueil
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onHomeClick(ActionEvent event) throws IOException {
		javaFXGUI.loadAccueil((Stage) logoCircle.getScene().getWindow());
	}

	/**
	 * Charge la page du tournoi ouvert
	 *
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onTournoiClick(ActionEvent event) throws IOException {
		javaFXGUI.loadProjet((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}

	/**
	 * Charge la page des équipes en lui donnant connaissance du tournoi ouvert
	 * @param event
	 * @throws IOException
	 */
	@FXML
	public void onEquipeClick(ActionEvent event) throws IOException {
		javaFXGUI.loadEquipe((Stage) logoCircle.getScene().getWindow(), tournoi.getNom());
	}
}
