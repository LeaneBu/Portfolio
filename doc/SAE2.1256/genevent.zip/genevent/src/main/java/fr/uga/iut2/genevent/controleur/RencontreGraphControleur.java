package fr.uga.iut2.genevent.controleur;

import fr.uga.iut2.genevent.vue.JavaFXGUI;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
/**
 * La classe RencontreGraphCOntroleur est le controleur de l'interface "RencontreGraph"
 * <p>
 * 		C'est une classe qui est liée au JavaFXGUI.
 * <p>
 */
public class RencontreGraphControleur {

	private JavaFXGUI javaFXGUI;

	public RencontreGraphControleur(JavaFXGUI javaFXGUI) {
		this.javaFXGUI = javaFXGUI;
	}

	@FXML
	private Circle logoCircle;

	/**
	 * Initialise les images lors de l'affichege de la page
	 */
	public void initImages(){
		logoCircle.setFill(new ImagePattern(new Image(JavaFXGUI.class.getResource("logoApp.png").toString())));
	}
}
