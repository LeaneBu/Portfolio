package fr.uga.iut2.genevent.exeption;

public class EquipeExeption extends Exception {
	private static final long serialVersionUID = 1L;
	public EquipeExeption() {
	}

	public EquipeExeption(String message) {
		super(message);
	}

	public EquipeExeption(Throwable cause) {
		super(cause);
	}

	public EquipeExeption(String message, Throwable cause) {
		super(message, cause);
	}
}
