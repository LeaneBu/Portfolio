package fr.uga.iut2.genevent.exeption;

public class ScoreExeption extends Exception {
	private static final long serialVersionUID = 1L;
	public ScoreExeption() {
	}

	public ScoreExeption(String message) {
		super(message);
	}

	public ScoreExeption(Throwable cause) {
		super(cause);
	}

	public ScoreExeption(String message, Throwable cause) {
		super(message, cause);
	}
}
