package fr.uga.iut2.genevent.exeption;

public class TournoiExeption extends Exception {
	private static final long serialVersionUID = 1L;
	public TournoiExeption() {
	}

	public TournoiExeption(String message) {
		super(message);
	}

	public TournoiExeption(Throwable cause) {
		super(cause);
	}

	public TournoiExeption(String message, Throwable cause) {
		super(message, cause);
	}
}
