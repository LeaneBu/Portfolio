package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.util.Persisteur;

import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Application implements Serializable {

	private static final long serialVersionUID = 1L;

	public static final Logger LOGGER = Logger.getLogger("Application");
	private HashMap<String,Tournoi> tournois;

	public Application() {
		this.tournois = new HashMap<>();
	}

	public void exporterTournoi(Tournoi tournoi) throws IOException {
		Persisteur.exporterEtatTournoi(tournoi);
	}

	public void importerTournoi(String t) throws ClassNotFoundException, IOException {
		Tournoi tournoi = Persisteur.importerEtatTournoi(t);
		if (tournoi != null){
			nouveauTournoi(tournoi);
		}
	}

	public void nouveauTournoi(Tournoi newtournoi){//todo: refaire les log

		this.tournois.put(newtournoi.getNom(),newtournoi);
	}

	public void supprimerTournoi(Tournoi tournoi){
		LOGGER.info("Suppression du tournoi");
		this.tournois.remove(tournoi.getNom());
	}

	public HashMap<String,Tournoi> getTournois() {
		return tournois;
	}

	public Tournoi getTournoi(String nom) {
		return tournois.get(nom);
	}

}
