package fr.uga.iut2.genevent.modele;

import java.io.Serializable;
import java.util.Comparator;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Equipe implements Serializable {

	private static final long serialVersionUID = 1L;
	private Logo logo;
	private String nomEquipe;

	public static final Logger LOGGER = Logger.getLogger("Equipe");
	private int Score;

	public Equipe(Logo logo, String nomEquipe){
		Score = 0;
		this.logo = logo;
		this.nomEquipe = nomEquipe;
	}

	public void setLogo(Logo logo) {
		LOGGER.info("Définition du logo de l'équipe " + this.getNomEquipe() + ".");
		LOGGER.log(Level.INFO, (this.logo == null) ? ("initialement non défini.") :  ("chemin logo initial = {0}."), this.logo.getChemin());
		this.logo = logo;
		LOGGER.log(Level.INFO, "chemin logo final = {0}.", this.logo.getChemin());
	}

	/**
	 * setter de l'attribut nomEquipe
	 * si nom invalide ecrit un log warning
	 * @param nomEquipe
	 */
	public void setNomEquipe(String nomEquipe) {
		if (nomEquipe != null || !nomEquipe.equals("")) {
			LOGGER.info("Définition du nom de l'équipe " + nomEquipe + ".");
			LOGGER.log(Level.INFO, (this.nomEquipe == null) ? ("initialement non défini.") :  ("nom initial = {0}."), this.nomEquipe);
			this.nomEquipe = nomEquipe;
			LOGGER.log(Level.INFO, "nom final = {0}.", this.nomEquipe);
		} else {
			LOGGER.warning("Nom d'équipe Invalide");
		}

	}

	public String getNomEquipe () {
		return nomEquipe;
	}

	public Logo getLogo () {
		return logo;
	}

	public void addScore(int point) {

		Score += point;
	}

	public int getScore() {
		return Score;
	}

	public static final Comparator<Equipe> EQUIPE_COMPARATOR = new Comparator<Equipe>() {
		@Override
		public int compare(Equipe equipe1, Equipe equipe2) {
			if (equipe1.getScore() > equipe2.getScore()) {
				return -1;
			} else if (equipe1.getScore() == equipe2.getScore()) {
				return 0;
			} else {
				return 1;
			}
		}
	};
}
