package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.vue.JavaFXGUI;
import java.io.Serializable;

public class Logo implements Serializable {

	private static final long serialVersionUID = 1L;
	private String chemin;
	private String alt;

	/**
	 * renvoie le chemin d'accés de l'image.
	 * @return l'attribut chemin du Logo.
	 */
	public String getChemin() {
		return chemin;
	}

	public String getAlt() {
		return alt;
	}

	/**
	 * Initialise un nouveau objet Logo avec comme attribut son chemin d'accès et un nom alternative.
	 * @param chemin Le chemin d'accés de l'image.
	 * @param alt Un String alternative en cas de problème avec le chemin.
	 */
	public Logo(String chemin, String alt) {
		this.chemin = chemin;
		this.alt = alt;
	}

	/**
	 * Initialise un nouveau objet Logo avec des paramétres par défauts.
	 */
	public Logo() {
		this.chemin = JavaFXGUI.class.getResource("defaultLogo.png").toString();
		this.alt = "";
	}
}
