package fr.uga.iut2.genevent.modele;
import javafx.util.Pair;
import java.io.Serializable;
import java.util.Optional;

public class Match implements Serializable {

	private static final long serialVersionUID = 1L;
	private Equipe equipe1;

	private int scoreEquipe1;
	private Equipe equipe2;

	private int scoreEquipe2;

	private Rencontre rencontre;

	public void setEquipe1(Equipe equipe) {
		this.equipe1 = equipe;
	}

	public void setEquipe2(Equipe equipe) {
		this.equipe2 = equipe;
	}

	public void setScoreEquipe1(int scoreEquipe1) {
		this.scoreEquipe1 = scoreEquipe1;
	}

	public void setScoreEquipe2(int scoreEquipe2) {
		this.scoreEquipe2 = scoreEquipe2;
	}
	/**
	 * set le score d'un match et vérifie si le la rencontre est remporter par l'une des deux équipes avec vérifRencontre
	 * @param scoreEquipe1
	 * @param scoreEquipe2
	 */
	public void setScoreMatch (int scoreEquipe1, int scoreEquipe2) {
		setScoreEquipe1(scoreEquipe1);
		setScoreEquipe2(scoreEquipe2);
		rencontre.verifRencontre(getGagnant());
	}



	public Match(Equipe equipe1, Equipe equipe2, Rencontre rencontre) {
		this.equipe1 = equipe1;
		this.equipe2 = equipe2;
		this.rencontre = rencontre;
	}

	public Optional<Integer> getScoreEquipe1() {
		if (equipe1 != null) {
			return Optional.of(scoreEquipe1);
		}
		return Optional.empty();
	}
	public Optional<Integer> getScoreEquipe2() {
		if (equipe2 != null) {
			return Optional.of(scoreEquipe2);
		}
		return Optional.empty();
	}

	public Optional<Integer> getScore(Pair<Equipe, Integer> equipe) {
		if (equipe != null) {
			return Optional.of(equipe.getValue());
		}
		return Optional.empty();
	}

	public Equipe getGagnant() {
		 if (scoreEquipe1 > scoreEquipe2) {
			return equipe1;
		} else {
			 return equipe2;
		 }
	}

	public Equipe getEquipe1() {
		return equipe1;
	}

	public Equipe getEquipe2() {
		return equipe2;
	}
}
