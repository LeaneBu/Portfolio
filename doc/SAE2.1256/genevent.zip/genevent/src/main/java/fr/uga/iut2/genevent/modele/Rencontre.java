package fr.uga.iut2.genevent.modele;

import javafx.util.Pair;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Rencontre implements Serializable {

	public static final Logger LOGGER = Logger.getLogger("Rencontre");
	private ArrayList<Match> listMatch;

	private Equipe equipe1;

	private Equipe equipe2;

	private int scoreE1;

	private int scoreE2;

	private int BO;

	private int niveauRencontre;

	private int idRencontre;

	private int indexRencontre;

	private Tournoi tournoi;
	private boolean isJouer;

	/**
	 * Génere une arrayList de match de taille le nombre de BO de la rencontre
	 * @param equipe1
	 * @param equipe2
	 */
	private void generateListMatch (Equipe equipe1, Equipe equipe2) {
		listMatch.clear();
		LOGGER.log(Level.INFO, "Generation des {0} match de la rencontre entre {1} est {2} du tournoi {3}."
				, new Object[] {BO,equipe1, equipe2, tournoi.getNom()});
		for (int i = 0; i < BO; i++) {
			listMatch.add(new Match(equipe1, equipe2, this));
		}
	}
	/**
	 * définit le BO de la rencontre et regénere les matchs de cette dernière
	 * @param BO
	 */
	public void setBO(int BO) {
		LOGGER.log(Level.INFO, "Définition du BO de la rencontre entre {1} est {2} du tournoi {3}."
				, new Object[] {BO,equipe1, equipe2, tournoi.getNom()});
		LOGGER.log(Level.INFO, (this.BO == 0) ? ("initialement non défini.") :  ("BO initial = {0}."), this.BO);
		this.BO = BO;
		LOGGER.log(Level.INFO, "BO final = {0}.", this.BO);
		generateListMatch(equipe1, equipe2);//todo: ajouter LOGGER
	}

	public Rencontre(){}

	public Rencontre(Equipe equipe1, Equipe equipe2, Tournoi tournoi, int indexRencontre , int idRencontre) {
		listMatch = new ArrayList<>();
		BO = 1;
		scoreE1 = 0;
		scoreE2 = 0;
		niveauRencontre = 0;
		this.idRencontre = idRencontre;
		this.indexRencontre = indexRencontre;
		this.tournoi = tournoi;
		this.equipe1 = equipe1;
		this.equipe2 = equipe2;
		generateListMatch(equipe1, equipe2);
		this.isJouer = false;
	}

	public Equipe getEquipe1() {
		return equipe1;
	}

	public Equipe getEquipe2() {
		return equipe2;
	}

	/**
	 * a utilisé seulement l'orsqu'on sait qu'il y a un gagnant
	 * @return le gagnant d'une rencontre
	 */
	public Equipe getGagnant () {
		if (scoreE1 > scoreE2) {
			return equipe1;
		} else {
			return equipe2;
		}
	}

	public int getIdRencontre() {
		return idRencontre;
	}

	public void setIdRencontre(int idRencontre) {
		this.idRencontre = idRencontre;
	}

	/**
	 * vérifie si un équipe a gagné la rencontre et si oui appelle le methode next rencontre et met la rencontre comme joué
	 * @param equipeGagnante
	 */
	public void verifRencontre(Equipe equipeGagnante) {
		if (equipeGagnante == equipe1) {
			scoreE1 ++;
		} else {
			scoreE2 ++;
		}

		if (scoreE1 > BO / 2) {
			tournoi.nextRencontre(equipe1, niveauRencontre, indexRencontre);
			equipe1.addScore(1);
			isJouer = true;
		} else if (scoreE2 > BO / 2) {
			tournoi.nextRencontre(equipe2, niveauRencontre, indexRencontre);
			equipe2.addScore(1);
			isJouer = true;
		}
	}

	public void setEquipe1(Equipe equipe1) {
		this.equipe1 = equipe1;
		generateListMatch(equipe1, equipe2);
	}

	public void setEquipe2(Equipe equipe2) {
		this.equipe2 = equipe2;
		generateListMatch(equipe1, equipe2);
	}

	public void setNiveauRencontre(int niveauRencontre) {
		this.niveauRencontre = niveauRencontre;
	}

	public int getScoreE1() {
		return scoreE1;
	}

	public int getScoreE2() {
		return scoreE2;
	}

	public int getBO() {
		return BO;
	}

	public int getNiveauRencontre() {
		return niveauRencontre;
	}

	@Override
	public String toString(){
		return (scoreE1 + " " + equipe1.getNomEquipe() + " : " + equipe2.getNomEquipe() + " " + scoreE2);
	}

	public ArrayList<Match> getListMatch() {
		return listMatch;
	}

	public boolean isJouer(){
		return isJouer;
	}
}
