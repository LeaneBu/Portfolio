package fr.uga.iut2.genevent.modele;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class Tournoi  implements Serializable {

	private static final long serialVersionUID = 1L;  // nécessaire pour la sérialisation

	public static final Logger LOGGER = Logger.getLogger("Tournoi");
	private int nbEquipe;
	private int tailleEquipe;
	private LocalDate date;
	private String nom;

	private Logo logo;

	private ArrayList<Equipe> equipes;//

	private TreeSet<Equipe> classement;

	public void setNbEquipe(int nbEquipe) {
		LOGGER.info("Définition du nombre équipe du tournoi " + this.getNom());
		LOGGER.log(Level.FINEST, (this.nbEquipe == 0) ? ("initialement non défini.") :  ("nbEquipe initial = {0}."), this.nbEquipe);
		this.nbEquipe = nbEquipe;
		LOGGER.log(Level.FINEST, "nbEquipe final = {0}", this.nbEquipe);
	}

	public void setTailleEquipe(int tailleEquipe) {
		LOGGER.info("Définition de la taille des équipe du tournoi " + this.getNom());
		LOGGER.log(Level.FINEST, (this.tailleEquipe == 0) ? ("initialement non défini.") :  ("tailleEquipe initial = {0}."), this.tailleEquipe);
		this.tailleEquipe = tailleEquipe;
		LOGGER.log(Level.FINEST, "tailleEquipe final = {0}", this.tailleEquipe);
	}

	public void setDate(LocalDate date) {
		LOGGER.info("Définition de la date du tournoi " + this.getNom());
		if (this.date == null) {
			LOGGER.finest("initialement non défini.");
		} else {
			LOGGER.log(Level.FINEST,"date initial = {0}.", date);
		}
		this.date = date;
		LOGGER.log(Level.FINEST, "date final = {0}", this.date.toString());
	}

	public void setNom(String nom) {
		LOGGER.info("Définition du nom du tournoi " + nom + ".");
		if (this.nom == null) {
			LOGGER.finest("initialement non défini.");
		} else {
			LOGGER.log(Level.FINEST, "nom initial = {0}.", this.nom);
		}
		this.nom = nom;
		LOGGER.log(Level.FINEST, "nom final = {0}.", this.nom);
	}

	public void setLogo(Logo logo) {
		LOGGER.info("Définition du logo tournoi " + this.getNom() + ".");
		if (this.logo == null) {
			LOGGER.finest("initialement non défini.");
		} else {
			LOGGER.log(Level.FINEST, "chemin logo initial = {0}.", this.logo.getChemin());
		}
		this.logo = logo;
		LOGGER.log(Level.FINEST, "chemin logo final = {0}.", this.logo.getChemin());
	}


	public Tournoi(int nbEquipe, int tailleEquipe, LocalDate date, String nom) {
		equipes = new ArrayList<>();
		classement = new TreeSet<>();
		setNom(nom);
		setNbEquipe(nbEquipe);
		setTailleEquipe(tailleEquipe);
		setDate(date);
		initEquipes();
		setLogo(new Logo());
	}

	public int getNbEquipe() {
		return nbEquipe;
	}

	public int getTailleEquipe() {
		return tailleEquipe;
	}

	public LocalDate getDate() {
		return date;
	}

	public String getNom() {
		return nom;
	}

	public Logo getLogo() {
		return logo;
	}


	public void changerRencontre(){}

	public void initEquipes() {
		for (int i = 0; i < nbEquipe; i++) {
			equipes.add(new Equipe(new Logo(), "Equipe" + i));
		}
	}
	public void removeEquipe(String nomEquipe){
		int i = 0;
		while (i < equipes.size() && !equipes.get(i).getNomEquipe().equals(nomEquipe)) {
			i++;
		}
		if (i == equipes.size()) {
			LOGGER.warning("l'équipe : " +nomEquipe + " n'éxiste pas.");
		} else {
			equipes.remove(equipes.get(i));
			LOGGER.info("L'équipe : " + nomEquipe + " a était supprimer");
		}
	}

	public void nouvelleEquipe(Logo logo, String nom){
		LOGGER.info("Création d'une équipe avec le nom " + nom + ".");
		Equipe equipe = new Equipe(logo, nom);
		LOGGER.finest("Ajout de l'équipe " + nom + " au tournoi " + this.getNom() + ".");
		equipes.add(equipe);
	}

	public ArrayList<Equipe> getEquipes() {
		return equipes;
	}

	public Equipe getEquipe(String nomEquipe) {

		int i = 0;
		while (i < equipes.size() && !equipes.get(i).getNomEquipe().equals(nomEquipe)) {
			i++;
		}
		if(i == equipes.size()){
			return null;
		} else {
			return equipes.get(i);
		}
	}

	public void nextRencontre(Equipe equipe1, int niveauRencontre, int idRencontre) {
	}

	public abstract Rencontre[][] getRencontres();
	/**
	 * permet d'avoir une rencontre en fonction de son niveau dans le tournoi et son index
	 * @param niveau
	 * @param id
	 * @return la rencontre chercher
	 */
	public abstract Rencontre getRencontre(int niveau, int id);

	public abstract int getNbEtage();

	public abstract TypeTournoi getTypeTournoi();
	
	public abstract void generateTournoiTable();

	/**
	 * crée le classement des équipes d'un tournoi
	 * @return un treeSet des équipes
	 */
	public TreeSet<Equipe> creerClassement() {
		TreeSet<Equipe> classement = new TreeSet<>(Equipe.EQUIPE_COMPARATOR);

		for (Equipe e : getEquipes()) {
			classement.add(e);
		}

		return classement;
	}
}
