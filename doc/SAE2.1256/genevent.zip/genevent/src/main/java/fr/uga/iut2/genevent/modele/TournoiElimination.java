package fr.uga.iut2.genevent.modele;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;

public class TournoiElimination extends Tournoi{


	private int nbEtage;

	private Rencontre tournoiElim[][];
	public final TypeTournoi type = TypeTournoi.TOURNOI_ELIM;

	private int idMax;

	public TournoiElimination(int nbEquipe, int tailleEquipe, LocalDate date, String nom) {
		super(nbEquipe, tailleEquipe, date, nom);
		nbEtage = 0;
		generateTournoiTable();
	}
	/**
	 * génere les rencontre du tournoui
	 * elles sont stocké dans un tableau a double entré chaque line corresponde a un round
	 * chaque tableau dans une ligne corresponde au rencontre de ce round
	 * la génération crée les rencontre uniquement pour le premier round 
	 */
	@Override
	public void generateTournoiTable() {
		int temp = getNbEquipe();
		while (temp > 1 ) {
			temp = temp / 2;
			nbEtage ++;
		}
		Rencontre rencontreTemp = new Rencontre();

		tournoiElim = new Rencontre[nbEtage][];

		for (int i = 0; i < nbEtage; i++) {
			tournoiElim[i] = new Rencontre[getNbEquipe() / (2 * (i +1))];
			for (int j = 0; j < tournoiElim[i].length; j++) {
				tournoiElim[i][j] = rencontreTemp;
			}
		}

		Collections.shuffle(getEquipes());
		for (int i = 0; i < getNbEquipe()/2; i++) {
			tournoiElim[0][i] = new Rencontre(getEquipes().get(i * 2), getEquipes().get(i * 2 + 1), this, i,i);
		}
		this.idMax = ((getNbEquipe()/2)-1);
	}

	/**
	 * permet de crée la rencontre suivante, suite a la victoire d'une équipe dans la rencontre précédente
	 */
	@Override
	public void nextRencontre(Equipe equipeGagnante , int niveauRencontre, int index) {
		if (tournoiElim.length != niveauRencontre+1 && tournoiElim[niveauRencontre + 1] [index / 2].getEquipe1() == null) {
			tournoiElim[niveauRencontre + 1][index / 2] = new Rencontre(equipeGagnante, null, this, index/2, idMax+1);
			tournoiElim[niveauRencontre + 1][index / 2].setNiveauRencontre(niveauRencontre + 1);
			this.idMax ++;
		}else if (tournoiElim.length != niveauRencontre+1){
			tournoiElim[niveauRencontre + 1] [index / 2].setEquipe2(equipeGagnante);
		}
	}

	@Override
	public Rencontre getRencontre(int niveau, int id) {
		return tournoiElim[niveau][id];
	}

	@Override
	public Rencontre[][] getRencontres() {
		return tournoiElim;
	}

	public TypeTournoi getTypeTournoi(){
		return type;
	}

	public int getNbEtage() {
		return nbEtage;
	}

}
