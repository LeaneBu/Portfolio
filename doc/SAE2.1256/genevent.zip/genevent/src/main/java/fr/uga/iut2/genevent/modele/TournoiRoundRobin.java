package fr.uga.iut2.genevent.modele;

import java.time.LocalDate;

public class TournoiRoundRobin extends Tournoi{

	public TournoiRoundRobin(int nbEquipe, int tailleEquipe, LocalDate date, String nom) {
		super(nbEquipe, tailleEquipe, date, nom);
		generateTournoiTable();
	}

	private Rencontre tournoiRobin [] [];

	public final TypeTournoi type = TypeTournoi.TOURNOI_ROUND_ROBIN;
	
	/**
	 * génere un double tableau chaque ligne et chaque colone corressponde a une equipe
	 * et le croisement de ces dernières a une rencontre
	 * l'orsqu'une équipe s'affronte elle même la rencontre est null
	 */
	@Override
	public void generateTournoiTable() {
		tournoiRobin = new Rencontre[getNbEquipe()][getNbEquipe()];
		int id = 0;
		for (int i = 0; i < getNbEquipe(); i++) {
			for (int j = 0 ; j < getNbEquipe(); j++) {
				if (i == j) {
					tournoiRobin[i][j] = null;
				} else {
					tournoiRobin[i][j] = new Rencontre(getEquipes().get(i), getEquipes().get(j), this, id, id);
					tournoiRobin[i][j].setNiveauRencontre(i);
					id++;
				}
			}

		}
	}

	@Override
	public Rencontre[][] getRencontres() {
		return tournoiRobin;
	}

	@Override
	public Rencontre getRencontre(int niveau, int id) {
		return tournoiRobin[niveau][id];
	}

	@Override
	public TypeTournoi getTypeTournoi(){
		return type;
	}

	public int getNbEtage(){
		return getNbEquipe();
	}

}
