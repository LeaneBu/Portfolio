package fr.uga.iut2.genevent.modele;

import java.util.HashMap;
import java.util.Map;

public enum TypeTournoi {

	TOURNOI_ELIM(0, "Tournoi d'élimination.",2,128,2),
	TOURNOI_ROUND_ROBIN(1,"Tournoi round Robin.",2,128,null)
	;

	private final int code;
	private final String description;
	private final int contrainteNbEquipeMin;
	private final int contrainteNbEquipeMax;
	private final Integer contrainteNbEquipePower;

	private static final Map<Integer, TypeTournoi> valueByCode = new HashMap<>();

	static {
		// On initialise une fois pour la durée de vie de l'application le
		// cache de la fonction `valueOfCode`
		for (TypeTournoi cmd : TypeTournoi.values()) {
			TypeTournoi.valueByCode.put(cmd.code, cmd);
		}
	}

	/**
	 * Renvoie la variante de la classe enum dont le code est donné en
	 * paramètre.
	 *
	 * @param code Le code de la variante à retourner.
	 *
	 * @return La variante de la classe enum dont le code est celui
	 *     spécifié.
	 */
	public static final TypeTournoi valueOfCode(int code) {
		TypeTournoi result = TypeTournoi.valueByCode.get(code);
		if (result == null) {
			throw new IllegalArgumentException("Invalid code");
		}
		return result;
	}

	private TypeTournoi(int code, String description, int contrainteNbEquipeMin, int contrainteNbEquipeMax, Integer contrainteNbEquipePower) {
		assert code >= 0;
		this.code = code;
		this.description = description;
		this.contrainteNbEquipeMax = contrainteNbEquipeMax;
		this.contrainteNbEquipeMin = contrainteNbEquipeMin;
		this.contrainteNbEquipePower = contrainteNbEquipePower;
	}

	/**
	 * Renvoie le synopsis mis en forme du type de tournoi.
	 *
	 * @return Une chaîne de caractères sans retour à la ligne contenant le
	 *     synopsis du type de tournoi.
	 */
	public String synopsis() {
		return this.code + " — " + this.description;
	}

	public int getContrainteNbEquipeMax() {
		return contrainteNbEquipeMax;
	}

	public int getContrainteNbEquipeMin() {
		return contrainteNbEquipeMin;
	}

	public Integer getContrainteNbEquipePower() {
		return contrainteNbEquipePower;
	}

	public String getDescription() {
		return description;
	}
}

