package fr.uga.iut2.genevent.vue;

import fr.uga.iut2.genevent.controleur.Controleur;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;

import fr.uga.iut2.genevent.modele.TypeTournoi;
import javafx.util.Pair;


/**
 * La classe CLI est responsable des interactions avec l'utilisa·teur/trice en
 * mode texte.
 * <p>
 * C'est une classe qui n'est associée à aucun état : elle ne contient aucun
 * attribut d'instance.
 * <p>
 * Aucun méthode de cette classe n'est pas censée modifier ses paramètres,
 * c'est pourquoi les paramètres des méthodes sont tous marqués comme `final`.
 *
 */
public class CLI extends IHM {

	private final Controleur controleur;

	public CLI(Controleur controleur) {
		this.controleur = controleur;
	}

//-----  Éléments du dialogue  -------------------------------------------------

	/**
	 * L'enum Commande répertorie les actions que l'utilisa·teur/trice peut
	 * entreprendre via CLI.
	 *
	 */
	private static enum Commande {

		QUITTER(0, "Quitter"),
		IMPORTER_FICHIER(1,"importation d'un tournoi externe"),
		CREER_EVENEMENT(2, "Créer un nouveau tournoi"),
		EXPORTER_FICHIER(3,"exportation d'un de vos tournoi"),
		OUVRIR_TOURNOI(4,"ouvrir un tournoi existant"),
		SUP_TOURNOI(5,"Supprime le tournoi.")
		;

		private final int code;
		private final String description;

		private static final Map<Integer, Commande> valueByCode = new HashMap<>();

		static {
			// On initialise une fois pour la durée de vie de l'application le
			// cache de la fonction `valueOfCode`
			for (Commande cmd : Commande.values()) {
				Commande.valueByCode.put(cmd.code, cmd);
			}
		}

		/**
		 * Renvoie la variante de la classe enum dont le code est donné en
		 * paramètre.
		 *
		 * @param code Le code de la variante à retourner.
		 *
		 * @return La variante de la classe enum dont le code est celui
		 *     spécifié.
		 */
		public static final Commande valueOfCode(int code) {
			Commande result = Commande.valueByCode.get(code);
			if (result == null) {
				throw new IllegalArgumentException("Invalid code");
			}
			return result;
		}

		private Commande(int code, String description) {
			assert code >= 0;
			this.code = code;
			this.description = description;
		}

		/**
		 * Renvoie le synopsis mis en forme de la commande.
		 *
		 * @return Une chaîne de caractères sans retour à la ligne contenant le
		 *     synopsis de la commande.
		 */
		public String synopsis() {
			return this.code + " — " + this.description;
		}
	}

	//------------------------------------------------------\\

	/**
	 * L'enum CommandeTournoi répertorie l'ensemble des commandes associées
	 * au TOURNOI auxquelles l'utilisateur a accès dans le CLI
	 *
	 */
	private static enum CommandeTournoi {

		RETOUR(0, "Revenir au menu"),
		AFFICHER_PARA_TOURNOI(1,"Affiche les paramétre du tournoi."),
		MODIFIER_PARA_TOURNOI(2,"Modifie les paramétre du tournoi."),
		AFFICHER_EQUIPE(3,"Affiche les équipes inscrit au tournoi."),
		MODIFIER_EQUIPE(4,"Modifie les paramétres d'une équipe."),
		CREER_EQUIPE(5,"Ajoute une nouvelle equipe au tournoi."),
		SUP_EQUIPE(6,"Supprime une équipe du tournoi."),
		AFFICHER_RENCONTRE(7,"Ouvre l'interface de gestion des rencontres."),
		AFFICHE_CLASSEMENT(8,"Affiche le classement du tournoi.")
		;

		private final int code;
		private final String description;

		private static final Map<Integer, CommandeTournoi> valueByCode = new HashMap<>();

		static {
			// On initialise une fois pour la durée de vie de l'application le
			// cache de la fonction `valueOfCode`
			for (CommandeTournoi cmd : CommandeTournoi.values()) {
				CommandeTournoi.valueByCode.put(cmd.code, cmd);
			}
		}

		/**
		 * Renvoie la variante de la classe enum dont le code est donné en
		 * paramètre.
		 *
		 * @param code Le code de la variante à retourner.
		 *
		 * @return La variante de la classe enum dont le code est celui
		 *     spécifié.
		 */
		public static final CommandeTournoi valueOfCode(int code) {
			CommandeTournoi result = CommandeTournoi.valueByCode.get(code);
			if (result == null) {
				throw new IllegalArgumentException("Invalid code");
			}
			return result;
		}

		private CommandeTournoi(int code, String description) {
			assert code >= 0;
			this.code = code;
			this.description = description;
		}

		/**
		 * Renvoie le synopsis mis en forme de la commande.
		 *
		 * @return Une chaîne de caractères sans retour à la ligne contenant le
		 *     synopsis de la commande.
		 */
		public String synopsis() {
			return this.code + " — " + this.description;
		}
	}

	/**
	 * L'enum CommandeRencontre répertorie l'ensemble des commandes associées
	 * aux RENCONTRES auxquelles l'utilisateur a accès dans le CLI
	 *
	 */
	private static enum CommandeRencontre {

		RETOUR(0, "Revenir au menu tournoi."),
		AFFICHER_RENCONTRE(1,"Affiche les rencontres du tournoi."),
		AFFICHER_MATCHE(2,"Afficher les matches d'une rencontre."),
		PAR_BO(3,"Définir le BO."),
		DEF_SCORE_MATCH(4,"Définir le score d'un matche.")
		;

		private final int code;
		private final String description;

		private static final Map<Integer, CommandeRencontre> valueByCode = new HashMap<>();

		static {
			// On initialise une fois pour la durée de vie de l'application le
			// cache de la fonction `valueOfCode`
			for (CommandeRencontre cmd : CommandeRencontre.values()) {
				CommandeRencontre.valueByCode.put(cmd.code, cmd);
			}
		}

		/**
		 * Renvoie la variante de la classe enum dont le code est donné en
		 * paramètre.
		 *
		 * @param code Le code de la variante à retourner.
		 *
		 * @return La variante de la classe enum dont le code est celui
		 *     spécifié.
		 */
		public static final CommandeRencontre valueOfCode(int code) {
			CommandeRencontre result = CommandeRencontre.valueByCode.get(code);
			if (result == null) {
				throw new IllegalArgumentException("Invalid code");
			}
			return result;
		}

		private CommandeRencontre(int code, String description) {
			assert code >= 0;
			this.code = code;
			this.description = description;
		}

		/**
		 * Renvoie le synopsis mis en forme de la commande.
		 *
		 * @return Une chaîne de caractères sans retour à la ligne contenant le
		 *     synopsis de la commande.
		 */
		public String synopsis() {
			return this.code + " — " + this.description;
		}
	}

//-----  Éléments du dialogue  -------------------------------------------------

	private Commande dialogueSaisirCommande() throws NoSuchElementException {
			CLI.afficher("===== FTM: Gestionnaire de tournoi =====");
			CLI.afficher(CLI.synopsisCommandes());
			CLI.afficher("===============================================");
			CLI.afficher("Saisir l'identifiant de l'action choisie :");
			return CLI.lireAvecErreurs(CLI::parseCommande);
	}

	private static CommandeTournoi dialogueSaisirCommandeTournoi(String nomTournoi) throws NoSuchElementException {
		CLI.afficher("===== Action sur "+ nomTournoi +" =====");
		CLI.afficher(CLI.synopsisCommandesTournoi());
		CLI.afficher("===============================================");
		CLI.afficher("Saisir l'identifiant de l'action choisie :");
		return CLI.lireAvecErreurs(CLI::parseCommandeTournoi);
	}

	private static CommandeRencontre dialogueSaisirCommandeRencontre(String nomTournoi) throws NoSuchElementException {
		CLI.afficher("===== Action sur les rencontre de "+ nomTournoi +" =====");
		CLI.afficher(CLI.synopsisCommandesRencontre());
		CLI.afficher("===============================================");
		CLI.afficher("Saisir l'identifiant de l'action choisie :");
		return CLI.lireAvecErreurs(CLI::parseCommandeRencontre);
	}
	private static TypeTournoi dialogueSaisirTypeTournoi() throws NoSuchElementException {
		CLI.afficher("===== type de tournoi disponible =====");
		CLI.afficher(CLI.synopsisTypeTournoi());
		CLI.afficher("===============================================");
		CLI.afficher("Saisir le type de tournoi :");
		return CLI.lireAvecErreurs(CLI::parseTypeTournoi);
	}

	private InfosTournoi dialogueSaisirNouveauTournoi(final Set<String> nomsExistants) throws NoSuchElementException {
		String nom;
		LocalDate date = LocalDate.now();
		int nbEquipe, tailleEquipe;
		TypeTournoi type;

		CLI.afficher("== Saisie d'un nouvel évènement ==");
		CLI.afficher("Saisir le nom du tournoi :");
		nom = CLI.lireNom(nomsExistants, true, false);
		CLI.afficher("Date de début: ");
		date = CLI.lireDate(date);
		CLI.afficher("Indiquer le type de tournoi");
		type = CLI.dialogueSaisirTypeTournoi();
		CLI.afficher("Indiquer le nombre d'équipes");
		nbEquipe = CLI.lireIntAvecContrainte(type.getContrainteNbEquipeMin(), type.getContrainteNbEquipeMax(),
				type.getContrainteNbEquipePower(), null);
		CLI.afficher("Indiquer la taille des équipe");
		tailleEquipe = CLI.lireIntAvecContrainte(1,100, null, null);

		return new InfosTournoi(nom, date, nbEquipe, tailleEquipe, type, null);
	}

	private InfosEquipe dialogueSaisirNouvelEquipe(final Set<String> nomsExistants) throws NoSuchElementException {
		String nom;

		CLI.afficher("== Saisie d'une nouvelle équipe ==");
		CLI.afficher("Saisir le nom de l'équipe :");
		nom = CLI.lireNom(nomsExistants, true, false);

		return new InfosEquipe(nom,null);
	}

	private InfosEquipe dialogueSaisirModifEquipe(final Set<String> nomsExistants, final InfosEquipe etatActuelle) throws NoSuchElementException {
		String nom;
		nomsExistants.remove(etatActuelle.nom);

		CLI.afficher("== Modification de l'équipe "+ etatActuelle.nom +" ==");
		CLI.afficher("Saisir le nouveau nom de l'équipe :");
		nom = CLI.lireNom(nomsExistants, true, false);

		return new InfosEquipe(nom,etatActuelle.logo);
	}

	private InfosTournoi dialogueSaisirModifTournoi(final Set<String> nomsExistants, final InfosTournoi etatActuelle) throws NoSuchElementException {
		String nom;
		LocalDate date = LocalDate.now();
		int nbEquipe;
		int tailleEquipe;

		nomsExistants.remove(etatActuelle.nom);

		CLI.afficher("== Modification du tournoi "+ etatActuelle.nom +" ==");
		CLI.afficher("Saisir le nouveau nom du tournoi :");
		nom = CLI.lireNom(nomsExistants, true, false);
		CLI.afficher("Saisir la nouvelle date du tournoi :");
		date = CLI.lireDate(date);
		CLI.afficher("Saisir le nouveau nombre d'équipes :");
		nbEquipe = CLI.lireIntAvecContrainte(etatActuelle.typeTournoi.getContrainteNbEquipeMin(), etatActuelle.typeTournoi.getContrainteNbEquipeMax(),
				etatActuelle.typeTournoi.getContrainteNbEquipePower(), null);
		CLI.afficher("Saisir la nouvelle taille des équipes :");
		tailleEquipe = CLI.lireIntAvecContrainte(1,100,null, null);

		return new InfosTournoi(nom, date, nbEquipe, tailleEquipe, etatActuelle.typeTournoi, etatActuelle.logo);
	}

//-----  Implémentation des Interface Homme-Machine  -------------------------------

	@Override
	public final void demarrerInteraction() {
		try {
			Commande cmd;
			do {
				cmd = dialogueSaisirCommande();
				switch (cmd) {
					case QUITTER:
						break;
					case IMPORTER_FICHIER:
						this.controleur.choixImportationFichier();
						break;
					case EXPORTER_FICHIER:
						this.controleur.choixExportationFichier();
						break;
					case CREER_EVENEMENT:
						this.controleur.saisirTournoi();
						break;
					case OUVRIR_TOURNOI:
						this.controleur.listTournois();
						break;
					case SUP_TOURNOI:
						this.controleur.choixSupprimerTournoi();
						break;
					default:
						assert false : "Commande inconnue.";
				}
			} while (cmd != Commande.QUITTER);
		} catch (NoSuchElementException e) {
			demarrerInteraction();
		}
	}

	@Override
	public void demarrerInteractionTournoi(final InfosTournoi tournoi) {
		try {
			CommandeTournoi cmd;
			do {
				cmd = dialogueSaisirCommandeTournoi(tournoi.nom);
				switch (cmd) {
					case RETOUR:
						break;
					case AFFICHER_PARA_TOURNOI:
						controleur.afficherTournoi(tournoi.nom);
						break;
					case AFFICHER_EQUIPE:
						this.controleur.listEquipes(tournoi.nom);
						break;
					case CREER_EQUIPE:
						this.controleur.saisirEquipe(tournoi.nom);
						break;
					case SUP_EQUIPE:
						this.controleur.suppresionEquipes(tournoi.nom);
						break;
					case MODIFIER_EQUIPE:
						this.controleur.interfaceModifierEquipe(tournoi.nom);
						break;
					case MODIFIER_PARA_TOURNOI:
						try {
							this.controleur.modifierTournoi(dialogueSaisirModifTournoi(this.controleur.listNomTournois(), tournoi), tournoi.nom);
						} catch (NoSuchElementException e) {
							CLI.afficher("Erreur infructueuse répété. Retour au menu précédant");
						}
						break;
					case AFFICHER_RENCONTRE:
						controleur.interfaceAffichageRencontre(tournoi.nom);
						break;
					case AFFICHE_CLASSEMENT:
						this.controleur.affichageClassement(tournoi.nom);
						break;
					default:
						assert false : "Commande inconnue.";
				}
			} while (cmd != CommandeTournoi.RETOUR && this.controleur.getTournoi(tournoi.nom).isPresent());
		}catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant");
		}
	}

	@Override
	public void demarrerInteractionRencontre(final String t) {
		try {
			CommandeRencontre cmd;
			do {
				cmd = dialogueSaisirCommandeRencontre(t);
				switch (cmd) {
					case RETOUR:
						break;
					case AFFICHER_RENCONTRE:
						afficherRencontres(t);
						break;
					case AFFICHER_MATCHE:
						try {
							afficherMatchs(t);
						} catch (NoSuchElementException e) {
							CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
						}
						break;
					case DEF_SCORE_MATCH:
						definirScoreMatch(t);
						break;
					case PAR_BO:
						definirBO(t);
						break;
					default:
						assert false : "Commande inconnue.";
				}
			} while (cmd != CommandeRencontre.RETOUR);
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}
	}

	//-----  Implémentation des méthodes abstraites  -------------------------------

	@Override
	public void saisirNouveauTournoi(final Set<String> nomsExistants) {
		try {
			InfosTournoi newTournoi = dialogueSaisirNouveauTournoi(nomsExistants);
			this.controleur.creerTournoi(newTournoi);
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}
	}

	@Override
	public void saisirNouvelEquipe(Set<String> nomsExistants, String t) {
		try {
			if (this.controleur.canAddEquipe(t)) {
				InfosEquipe newEquipe = dialogueSaisirNouvelEquipe(nomsExistants);
				this.controleur.creerEquipe(newEquipe, t);
			} else {
				System.out.println("===============================================");
				System.out.println("Le Tournoi a atteint le nombre max d'équipe");
				System.out.println("===============================================");
			}
		}catch (NoSuchElementException e){
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}

	}

	@Override
	public void saisirModifEquipe(String t) {
		try {
			Set<String> nomConnues = this.controleur.listEquipeMapper(t).keySet();
			String equipeAModif = lireNom(nomConnues, false, false);

			this.controleur.modifierEquipe(t, equipeAModif, dialogueSaisirModifEquipe(
					nomConnues,
					controleur.accesEquipe(equipeAModif, t))
			);
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}
	}

	public void choixSuppresionEquipes(Set<String> nomEquipes, String t) {
		try {
			CLI.afficher("===============Suppression equipes===============");
			String equipeSupprimer = null;
			if (nomEquipes.size() > 0) {
				do {
					equipeSupprimer = CLI.lireNom(nomEquipes, false, true);
					if (equipeSupprimer != ".") {
						this.controleur.suppresionEquipe(t, equipeSupprimer);
						nomEquipes.remove(equipeSupprimer);
					}
				} while (equipeSupprimer != "." && nomEquipes.size() > 0);
			} else {
				CLI.afficher("\tAucune équipe a supprimer.");
			}
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infrutueuse répété. Retour au menu précédant.");
		}

	}

	@Override
	public void supprimerTournoi() {
		try {
			CLI.afficher("===============Exportation de tournoi===============");
			String tournoiASupprimer = null;
			Set<String> listTournoi = this.controleur.listNomTournois();
			if (listTournoi.size() > 0) {
				do {
					tournoiASupprimer = CLI.lireNom(listTournoi, false, true);
					if (tournoiASupprimer != ".") {
						this.controleur.supprimerTournoi(tournoiASupprimer);
						listTournoi.remove(tournoiASupprimer);
					}
				} while (tournoiASupprimer != "." && listTournoi.size() > 0);
			} else {
				CLI.afficher("\tAucun tournoi a supprimer.");
			}
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infrutueuse répété. Retour au menu précédant.");
		}
	}

	@Override
	public void importationTournoi() {
		try {
			CLI.afficher("===============Importation de tournoi===============");
			CLI.afficher("Indiquer le nom tu tournoi a importer.");
			this.controleur.importationFichier(lireNom());
		} catch (NoSuchElementException e) {
			CLI.afficher("Erruer infructueuse répété. Retour au menu précédant.");
		}
	}

	@Override
	public void exportationTournois() {

		try {
			CLI.afficher("===============Exportation de tournoi===============");
			String tournoiAExporter = null;
			Set<String> listTournoi = this.controleur.listNomTournois();
			if (listTournoi.size() > 0) {
				do {
					tournoiAExporter = CLI.lireNom(listTournoi, false, true);
					if (tournoiAExporter != ".") {
						this.controleur.exportationFichier(tournoiAExporter);
					}
				} while (tournoiAExporter != "." && listTournoi.size() > 0);
			} else {
				CLI.afficher("\tAucun tournoi a exporter.");
			}
		} catch (NoSuchElementException e){
			CLI.afficher("Erreur infructueuse répéter. Retour au menu précédant");
		}

	}

	@Override
	public void afficherEquipes(Set<String> nomEquipes) {
		CLI.afficher("=================equipes=================");
		if (nomEquipes.size() > 0) {
			CLI.afficherListString(nomEquipes);
		} else {
			CLI.afficher("\tAucune equipe...");
		}
	}

	@Override
	public void afficherTournoi(InfosTournoi tournoi) {
		CLI.afficher("================="+ tournoi.nom +"=================");
		CLI.afficher("\tType de tournoi : "+tournoi.typeTournoi.getDescription());
		CLI.afficher("\tNombre d'équipes : "+tournoi.nbEquipe);
		CLI.afficher("\tTaille des équipes : "+tournoi.tailleEquipe);
		CLI.afficher("\tDate de début : "+tournoi.date);
	}

	@Override
	public void afficherTournois(Set<String> listTournois) {
		try {
			String tournoiChoisi;

			CLI.afficher("=================List des tournois=================");
			if (listTournois == null || listTournois.size() <= 0) {
				CLI.afficher("\t-aucun tournoi existant");
			} else {
				CLI.afficher("Indiquer le nom du tournoi que vous voulez ouvrir.");
				tournoiChoisi = CLI.lireNom(listTournois, false, false);

				controleur.ouvrirTournoi(tournoiChoisi);
			}
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}

	}

	@Override
	public void definirScoreMatch(String nomTournoi) {
		try {
			Pair infos = afficherMatchs(nomTournoi);
			ArrayList<InfosMatch> matches = (ArrayList<InfosMatch>) infos.getKey();
			InfosRencontre rencontre = (InfosRencontre) infos.getValue();

			ArrayList<Integer> idMatches = new ArrayList<>();

			for (int i = 0; i < matches.size(); i++) {
				idMatches.add(i);
			}

			int id = lireId(idMatches);
			InfosMatch match = matches.get(id);

			CLI.afficher("Saisiser le score de " + match.equipe1 + " du match");
			int newScore1 = lireIntAvecContrainte(0, 100, null, null);
			CLI.afficher("Saisiser le score de " + match.equipe2 + " du match");
			int newScore2 = lireIntAvecContrainte(0, 100, null, null);

			this.controleur.setScoreMatch(new InfosMatch(
							match.equipe1,
							match.equipe2,
							newScore1,
							newScore2)
					, nomTournoi, rencontre
			);
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}

	}

	@Override
	public void afficherRencontres(String nomTournoi) {
		InfosRencontre [] [] rencontres = this.controleur.getRencontresTournoi(nomTournoi);
		for (int i = 0; i < rencontres.length; i++) {
			for (int j = 0; j < rencontres[i].length; j++) {
				if (rencontres[i][j] != null) {
					System.out.print(rencontres[i][j] + "	|	");
				}
			}
			System.out.println();
		}
	}

	@Override
	public void afficherClassement(ArrayList<String> classement){
		int i = 1;
		for (String s : classement){
			CLI.afficher(i +" : "+ s);
			i++;
		}

	}

	@Override
	public void definirBO(String nomTournoi) {
		try {
			CLI.afficher("===== Définir le BO d'une rencontre  =====");
			afficherRencontres(nomTournoi);
			int id = lireId(this.controleur.getIdRencontres(this.controleur.getRencontresTournoi(nomTournoi)));
			if (!this.controleur.isRencontreJouer(id, nomTournoi)) {
				CLI.afficher("Saissiser le nombre de BO:");
				int bo = lireIntAvecContrainte(1, 7, null, false);
				this.controleur.setBO(nomTournoi, id, bo);
			} else {
				CLI.afficher("La rencontre a déja été jouée.");
			}
		} catch (NoSuchElementException e) {
			CLI.afficher("Erreur infructueuse répété. Retour au menu précédant.");
		}
	}

	@Override
	public void informerUtilisateur(String msg, boolean succes) {}

	//-----  Implémentation de méthodes suplémentaires  -------------------------------

	/**
	 * Affiche la list des matches d'une rencontre.
	 * @param nomTournoi Le nom du tournoi auquelle on veut afficher les matches.
	 * @return Une pair contenant une liste des informations des matches ainsi que les informations de la rencontre.
	 */
	public Pair<ArrayList<InfosMatch>,InfosRencontre> afficherMatchs(String nomTournoi) throws NoSuchElementException{
		//demmande de l'id de la rencontre
		afficherRencontres(nomTournoi);
		int id = lireId(this.controleur.getIdRencontres(this.controleur.getRencontresTournoi(nomTournoi)));


		InfosRencontre rencontre = this.controleur.getRencontreTournoi(nomTournoi, id);
		ArrayList<InfosMatch> matchs = this.controleur.getMatch(rencontre, nomTournoi);

		CLI.afficher("===== Matches de la rencontre "+ rencontre.equipe1 + " contre " + rencontre.equipe2 +" =====");
		for (InfosMatch m : matchs){
			CLI.afficher(m.toString());
		}

		return new Pair<>(matchs, rencontre);
	}

//-----  Primitives d'affichage  -----------------------------------------------

	/**
	 * Construit le synopsis des commandes.
	 *
	 * @return Une chaîne de caractères contenant le synopsis des commandes.
	 */
	private static String synopsisCommandes() {
		StringBuilder builder = new StringBuilder();

		for (Commande cmd: Commande.values()) {
			builder.append("\t");  // légère indentation
			builder.append(cmd.synopsis());
			builder.append(System.lineSeparator());
		}

		return builder.toString();
	}

	/**
	 * Construit le synopsis des commandes d'un tournoi.
	 *
	 * @return Une chaîne de caractères contenant le synopsis des commandes du tournoi.
	 */
	private static String synopsisCommandesTournoi() {
		StringBuilder builder = new StringBuilder();

		for (CommandeTournoi cmd: CommandeTournoi.values()) {
			builder.append("\t");  // légère indentation
			builder.append(cmd.synopsis());
			builder.append(System.lineSeparator());
		}

		return builder.toString();
	}

	/**
	 * Construit le synopsis des commandes pour les rencontres d'un tournoi.
	 *
	 * @return Une chaîne de caractères contenant le synopsis des commandes de la rencontre.
	 */
	private static String synopsisCommandesRencontre() {
		StringBuilder builder = new StringBuilder();

		for (CommandeRencontre cmd: CommandeRencontre.values()) {
			builder.append("\t");  // légère indentation
			builder.append(cmd.synopsis());
			builder.append(System.lineSeparator());
		}

		return builder.toString();
	}

	/**
	 * Construit le synopsis des commandes d'un tournoi.
	 *
	 * @return Une chaîne de caractères contenant le synopsis des types tournois disponible.
	 */
	private static String synopsisTypeTournoi() {
		StringBuilder builder = new StringBuilder();

		for (TypeTournoi cmd: TypeTournoi.values()) {
			builder.append("\t");  // légère indentation
			builder.append(cmd.synopsis());
			builder.append(System.lineSeparator());
		}

		return builder.toString();
	}

	/**
	 * Affiche la liste de String a l'utilisateur.
	 * @param listString la liste a afficher.
	 */
	private static void afficherListString(final Set<String> listString){
		String list = "";
		for (String s : listString){
			list += ("\t-"+s+"\n");
		}
		CLI.afficher(list);
	}


//-----  Primitives de lecture  ------------------------------------------------

	/**
	 * Interprète un token entier non signé comme une {@link Commande}.
	 *
	 * @param token La chaîne de caractère à interpréter.
	 *
	 * @return Une option contenant la {@link Commande} en cas de succès,
	 *     l'option vide en cas d'erreur.
	 */
	private static Optional<Commande> parseCommande(final String token) {
		Optional<Commande> result;
		try {
			int cmdId = Integer.parseUnsignedInt(token);  // may throw NumberFormatException
			Commande cmd = Commande.valueOfCode(cmdId);  // may throw IllegalArgumentException
			result = Optional.of(cmd);
		}
		// NumberFormatException est une sous-classe de IllegalArgumentException
		catch (IllegalArgumentException ignored) {
			CLI.afficher("Choix non valide : merci d'entrer un identifiant existant.");
			result = Optional.empty();
		}
		return result;
	}

	/**
	 * Interprète un token entier non signé comme une {@link CommandeTournoi}.
	 *
	 * @param token La chaîne de caractère à interpréter.
	 *
	 * @return Une option contenant la {@link CommandeTournoi} en cas de succès,
	 *     l'option vide en cas d'erreur.
	 */
	private static Optional<CommandeTournoi> parseCommandeTournoi(final String token) {
		Optional<CommandeTournoi> result;
		try {
			int cmdId = Integer.parseUnsignedInt(token);  // may throw NumberFormatException
			CommandeTournoi cmd = CommandeTournoi.valueOfCode(cmdId);  // may throw IllegalArgumentException
			result = Optional.of(cmd);
		}
		// NumberFormatException est une sous-classe de IllegalArgumentException
		catch (IllegalArgumentException ignored) {
			CLI.afficher("Choix non valide : merci d'entrer un identifiant existant.");
			result = Optional.empty();
		}
		return result;
	}

	/**
	 * Interprète un token entier non signé comme une {@link CommandeRencontre}.
	 *
	 * @param token La chaîne de caractère à interpréter.
	 *
	 * @return Une option contenant la {@link CommandeRencontre} en cas de succès,
	 *     l'option vide en cas d'erreur.
	 */
	private static Optional<CommandeRencontre> parseCommandeRencontre(final String token) {
		Optional<CommandeRencontre> result;
		try {
			int cmdId = Integer.parseUnsignedInt(token);  // may throw NumberFormatException
			CommandeRencontre cmd = CommandeRencontre.valueOfCode(cmdId);  // may throw IllegalArgumentException
			result = Optional.of(cmd);
		}
		// NumberFormatException est une sous-classe de IllegalArgumentException
		catch (IllegalArgumentException ignored) {
			CLI.afficher("Choix non valide : merci d'entrer un identifiant existant.");
			result = Optional.empty();
		}
		return result;
	}

	/**
	 * Interprète un token entier non signé comme une {@link TypeTournoi}.
	 *
	 * @param token La chaîne de caractère à interpréter.
	 *
	 * @return Une option contenant la {@link TypeTournoi} en cas de succès,
	 *     l'option vide en cas d'erreur.
	 */
	private static Optional<TypeTournoi> parseTypeTournoi(final String token) {
		Optional<TypeTournoi> result;
		try {
			int cmdId = Integer.parseUnsignedInt(token);  // may throw NumberFormatException
			TypeTournoi cmd = TypeTournoi.valueOfCode(cmdId);  // may throw IllegalArgumentException
			result = Optional.of(cmd);
		}
		// NumberFormatException est une sous-classe de IllegalArgumentException
		catch (IllegalArgumentException ignored) {
			CLI.afficher("Choix non valide : merci d'entrer un identifiant existant.");
			result = Optional.empty();
		}
		return result;
	}



}
