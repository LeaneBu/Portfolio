package fr.uga.iut2.genevent.vue;

import fr.uga.iut2.genevent.controleur.Controleur;
import fr.uga.iut2.genevent.modele.Logo;
import fr.uga.iut2.genevent.modele.TypeTournoi;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;


public abstract class IHM {

    public abstract void afficherClassement(ArrayList<String> classement);

    /**
     * Nombre maximum d'essais pour la lecture d'une saisie utilisa·teur/trice.
     */
    private static final int MAX_ESSAIS = 3;

    public abstract void definirBO(String nomTournoi);

    /**
     * Classe conteneur pour les informations d'un tournoi
     * {@link fr.uga.iut2.genevent.modele.Tournoi}.
     *
     * <ul>
     * <li>Tous les attributs sont `public` par commodité d'accès.</li>
     * <li>Tous les attributs sont `final` pour ne pas être modifiables.</li>
     * </ul>
     */
    public static class InfosTournoi{
        public final String nom;
        public final LocalDate date;

        public final int nbEquipe;
        public final int tailleEquipe;
        public final TypeTournoi typeTournoi;
        public final Logo logo;



        public InfosTournoi(final String nom, final LocalDate date, final int nbEquipe, final int tailleEquipe, final TypeTournoi typeTournoi, final Logo logo) {
            this.nom = nom;
            this.date = date;
            this.nbEquipe = nbEquipe;
            this.tailleEquipe = tailleEquipe;
            this.typeTournoi = typeTournoi;
            this.logo = logo;
        }
    }

    /**
     * Classe conteneur pour les informations d'une equipe.
     * {@link fr.uga.iut2.genevent.modele.Equipe}.
     *
     * <ul>
     * <li>Tous les attributs sont `public` par commodité d'accès.</li>
     * <li>Tous les attributs sont `final` pour ne pas être modifiables.</li>
     * </ul>
     */
    public static class InfosEquipe{
        public final String nom;
        public final Logo logo;


        public InfosEquipe(final String nom, final Logo logo) {
            this.nom = nom;
            this.logo = logo;
        }
    }

    /**
     * Classe conteneur pour les informations d'un match.
     * {@link fr.uga.iut2.genevent.modele.Match}.
     *
     * <ul>
     * <li>Tous les attributs sont `public` par commodité d'accès.</li>
     * <li>Tous les attributs sont `final` pour ne pas être modifiables.</li>
     * </ul>
     */
    public static class InfosMatch{
        public final String equipe1;
        public final String equipe2;
        public final int scoreE1;
        public final int scoreE2;
        public int index;


        public InfosMatch(final String equipe1, final String equipe2, final int scoreE1, final int scoreE2) {
            this.equipe1 = equipe1;
            this.equipe2 = equipe2;
            this.scoreE1 = scoreE1;
            this.scoreE2 = scoreE2;
        }

        @Override
        public String toString(){
            return ("(ID match: " + index + ") "+scoreE1 + " " + equipe1 + " : " + equipe2 + " " + scoreE2);
        }

        public void setIndex(int index){
            this.index = index;
        }
    }

    /**
     * Classe conteneur pour les informations d'une rencontre.
     * {@link fr.uga.iut2.genevent.modele.Rencontre}.
     *
     * <ul>
     * <li>Tous les attributs sont `public` par commodité d'accès.</li>
     * <li>Tous les attributs sont `final` pour ne pas être modifiables.</li>
     * </ul>
     */
    public static class InfosRencontre{
        public final String equipe1;
        public final String equipe2;
        public final int scoreE1;
        public final int scoreE2;
        public int lvRencontre;
        public int idRencontre;
        public int BO;
        public int index;


        public InfosRencontre(final String equipe1, final String equipe2, final int scoreE1, final int scoreE2, final int lvRencontre, final int idRencontre, final int BO) {
            this.equipe1 = equipe1;
            this.equipe2 = equipe2;
            this.scoreE1 = scoreE1;
            this.scoreE2 = scoreE2;
            this.lvRencontre = lvRencontre;
            this.idRencontre = idRencontre;
            this.BO =BO;

        }

        @Override
        public String toString(){
            return ("(Id : " + idRencontre + ") " + scoreE1 + " " + equipe1 + " : " + equipe2 + " " + scoreE2);
        }

        public void setIndex(int index) {
            this.index = index;
        }
    }

    /**
     * Rend actif l'interface Humain-machine global de l'application.
     *
     * L'appel est bloquant : le contrôle est rendu à l'appelant une fois que
     * l'IHM est fermée.
     *
     */
    public abstract void demarrerInteraction();

    /**
     * Rend actif l'interface Humain-machine des tournois.
     * @param tournoi nom du tournoi avec le quelle on interagir.
     */
    public abstract void demarrerInteractionTournoi(InfosTournoi tournoi);

    /**
     * Affiche un message d'information à l'attention de l'utilisa·teur/trice.
     *
     * @param msg Le message à afficher.
     *
     * @param succes true si le message informe d'une opération réussie, false
     *     sinon.
     */
    public abstract void informerUtilisateur(final String msg, final boolean succes);

    /**
     * Affiche l'interface de saisie pour la création d'un nouveau tournoi.
     *
     * @param nomsExistants L'ensemble des noms de tournoi qui ne sont plus
     *      *     disponibles dans le tournoi.
     */
    public abstract void saisirNouveauTournoi(final Set<String> nomsExistants);

    /**
     * Récupère les informations nécessaires à la création d'une nouvelle équipe.
     * {@link fr.uga.iut2.genevent.modele.Equipe}.
     *
     * @param nomsExistants L'ensemble des noms d'équipe qui ne sont plus
     *     disponibles dans le tournoi.
     *
     * @param nomTournoi nom du tournoi dans le quelle on doit ajouter l'équipe.
     *
     */
    public abstract void saisirNouvelEquipe(final Set<String> nomsExistants, final String nomTournoi);

    /**
     * Affiche l'interface pour modifier les paramétres d'une équipe.
     *
     * @param nomTournoi nom du tournoi dans le quelle on doit modifier l'équipe.
     */
    public abstract void saisirModifEquipe(final String nomTournoi);

    /**
     * Affiche l'interface pour choisir les équipes a supprimer.
     * @param nomEquipes L'ensemble des noms d'équipe qui sont dans
     *      *     le tournoi.
     * @param tournoi nom du tournoi dans le quelle on doit supprimer les équipes.
     */
    public abstract void choixSuppresionEquipes(final Set<String> nomEquipes, final String tournoi);


    /**
     * Affiche l'interface pour supprimer les tournois.
     */
    public abstract void supprimerTournoi();

    /**
     * Affiche l'interface pour importer son tournoi.
     */
    public abstract void importationTournoi();

    /**
     * Affiche l'interface pour exporter son tournoi.
     */
    public abstract void exportationTournois();

    /**
     * Affiche la liste des équipes.
     * @param nomEquipes Liste des équipes a afficher.
     */
    public abstract void afficherEquipes(Set<String> nomEquipes);

    /**
     * Affiche les information d'un tournoi.
     * @param tournoi Les informations du tournoi.
     */
    public abstract void  afficherTournoi(InfosTournoi tournoi);

    /**
     * Affiche la liste des tournois.
     * @param listTournois Une liste des noms des tournois dans l'application.
     */
    public void afficherTournois(Set<String> listTournois) {
    }

    /**
     * Déffinie le score du match numéro X d'une rencontre.
     *
     * @param nomTournoi Le nom du tournoi auquelle on veut définir un match.
     */
    public abstract void definirScoreMatch(String nomTournoi);

    /**
     * Affiche les matchs et scores actuelle de la rencontre.
     * @param nomTournoi Le nom du tournoi auquelle on veut voir les rencontres.
     */
    public abstract void afficherRencontres(String nomTournoi);

    /**
     * Rend actif l'interface Humain-machine des rencontres d'un tournoi.
     * @param tournoi Le nom du tournoi auquelle on veut accéder a ses rencontres.
     */
    public abstract void demarrerInteractionRencontre(String tournoi);

    // ======= methode d'affichage de donnée ======

    /**
     * Affiche un message à l'attention de l'utilisa·teur/trice.
     *
     * @param msg Le message à afficher.
     */
    public static void afficher(final String msg) {
        System.out.println(msg);
        System.out.flush();
    }

    // ======= methode de traitement de donnée ======
    /**
     * Essaie de lire l'entrée standard avec la fonction d'interprétation.
     * <p>
     * En cas d'erreur, la fonction essaie au plus {@value #MAX_ESSAIS} fois de
     * lire l'entrée standard.
     *
     * @param <T> Le type de l'élément lu une fois interprété.
     *
     * @param parseFunction La fonction d'interprétation: elle transforme un
     *     token de type chaîne de caractère un un objet de type T.
     *     <p>
     *     La fonction doit renvoyer l'option vide en cas d'erreur, et une
     *     option contenant l'objet interprété en cas de succès.
     *     <p>
     *     La fonction d'interprétation est responsable d'afficher les messages
     *     d'erreur et de guidage utilisa·teur/trice.
     *
     * @return L'interprétation de la lecture de l'entrée standard.
     */
    public static <T> T lireAvecErreurs(final Function<String, Optional<T>> parseFunction) throws NoSuchElementException {
        Optional<T> result = Optional.empty();
        Scanner in = new Scanner(System.in);
        String token;

        for (int i = 0; i < IHM.MAX_ESSAIS && result.isEmpty(); ++i) {
            token = in.next();
            result = parseFunction.apply(token);
        }

        //return result.orElseThrow();//() -> new Error("Erreur de lecture (" + CLI.MAX_ESSAIS + " essais infructueux).")
        if (!result.isEmpty()){
            return result.get();
        } else {
            throw new NoSuchElementException();
        }
    }

    /**
     * Interprète un token comme une chaîne de caractère et vérifie que la
     * chaîne n'existe pas déjà.
     *
     * @param token La chaîne de caractère à interpréter.
     *
     * @param nomsConnus L'ensemble de chaîne de caractères qui ne sont plus
     *     disponibles.
     *
     * @return Une option contenant la chaîne de caractère en cas de succès,
     *     l'option vide en cas d'erreur.
     */
    public static Optional<String> parseNouveauNom(final String token, final Set<String> nomsConnus) {
        Optional<String> result;
        if ((nomsConnus == null) || !(nomsConnus.contains(token))) {
            result = Optional.of(token);
        } else {
            afficher("Le nom existe déjà dans l'application.");
            result = Optional.empty();
        }
        return result;
    }

    /**
     * Interprète un token comme une chaîne de caractère et vérifie que la
     * chaîne existe déjà.
     *
     * @param token La chaîne de caractère à interpréter.
     *
     * @param nomsConnus L'ensemble de chaîne de caractères valides.
     *
     * @param boucle Si on veut rien séléctionner comme nom (a utiliser dans les cas de multiple saisie).
     *
     * @return Une option contenant la chaîne de caractère en cas de succès,
     *     l'option vide en cas d'erreur.
     */
    public static Optional<String> parseNomExistant(final String token, final Set<String> nomsConnus, boolean boucle) {
        Optional<String> result;
        if (nomsConnus.contains(token)) {
            result = Optional.of(token);
        } else if (boucle && token.equals(".")){
            result = Optional.of(".");
        } else {
            afficher("Le nom n'existe pas dans l'application.");
            result = Optional.empty();
        }
        return result;
    }

    /**
     * Lit sur l'entrée standard un nom en fonction des noms connus.
     *
     * @param nomsConnus L'ensemble des noms connus dans l'application.
     *
     * @param nouveau Le nom lu doit-il être un nom connu ou non.
     *     Si {@code true}, le nom lu ne doit pas exister dans
     *     {@code nomConnus}; sinon le nom lu doit exister dans
     *     {@code nomsConnus}.
     *
     * @param boucle Si on veut rien séléctionner comme nom (a utiliser dans les cas de multiple saisie).
     *
     * @return Le nom saisi par l'utilisa·teur/trice.
     */
    public static String lireNom(final Set<String> nomsConnus, final boolean nouveau, final boolean boucle) throws NoSuchElementException {
        if (nouveau) {
            if (!nomsConnus.isEmpty()) {
                afficher("Les noms suivants ne sont plus disponibles :");
                afficher("  " + String.join(" - ", nomsConnus) + ".");
            }
            return IHM.lireAvecErreurs(token -> IHM.parseNouveauNom(token, nomsConnus));
        } else {
            if (!boucle){
                assert !nomsConnus.isEmpty();
                afficher("Choisir un nom parmi les noms suivants :");
                afficher("  " + String.join(" - ", nomsConnus) + ".");
                return lireAvecErreurs(token -> parseNomExistant(token, nomsConnus, false));
            } else {
                assert !nomsConnus.isEmpty();
                afficher("Choisir un nom parmi les noms suivants :");
                afficher("\t" + String.join(" - ", nomsConnus));
                afficher("Envoyer \".\" pour arréter");
                return lireAvecErreurs(token -> parseNomExistant(token, nomsConnus, true));
            }
        }
    }

    /**
     * Lit sur l'entrée standard un nom.
     *
     * @return Le nom saisi par l'utilisa·teur/trice.
     */
    public static String lireNom() throws NoSuchElementException {
        return lireNom(Collections.emptySet(), true, false);
    }

    /**
     * Lit sur l'entrée standard un entier en fonction des des contraintes donnée.
     *
     * @param nbMin La valeur minimum que peut avoir la valeur saisie.
     *
     * @param nbMax La valeur maximum que peut avoir la valeur saisie.
     *
     * @param puissance Est-ce que sa doit étre une puissance de 2.
     *                     Si {@code null}, pas de contrainte de puissance;
     *                   Sinon, La valeur lut doit étre une puissance de 2.
     *
     * @param paire Est-ce que la valeur doit étre paire.
     *                 Si {@code true}, La valeur lut doit étre paire;
     *              Si {@code false} , la valuer lut doit étre impaire;
     *              et si {@code null}, pas de contrainte de paire / impaire.
     *
     * @return L'entier saisie par l'utilisa·teur/trice.
     * @throws NoSuchElementException
     */
    public static int lireIntAvecContrainte(Integer nbMin, Integer nbMax, Integer puissance, Boolean paire) throws NoSuchElementException{
        ArrayList<Integer> type = new ArrayList<>();
        type.add(nbMin);
        type.add(nbMax);
        type.add(puissance);

        afficher("\tmin: " + nbMin +
                " - max: " + nbMax);
        if (puissance != null) {
            afficher("\tDoit étre une puissance de 2");
        }
        if (paire != null && paire) {
            afficher("Le nombre doit étre paire.");
            type.add(2);
        } else if (paire != null && !paire) {
            afficher("Le nombre doit étre impaire.");
            type.add(1);
        } else {
            type.add(null);
        }


        return lireAvecErreurs(token -> parseInt(token,Optional.of(type)));
    }

    /**
     * Lit sur l'entrée standard un entier en fonction de la liste {@code iD} donnée.
     *
     * @param iD la liste d'entier dans le quelle doit étre présant l'entier lut.
     * @return L'entier saisie par l'utilisa·teur/trice.
     */
    public static int lireId(ArrayList<Integer> iD) throws NoSuchElementException{
        afficher("Saissiser l'ID voulu:");
        return lireAvecErreurs(token -> parseId(token,iD));
    }

    /**
     * Interprète un token comme une {@link Integer}.
     *
     * @param token La chaîne de caractère à interpréter.
     *
     * @param contraint Si l'option contient une valeur, l' entier lue doit suivre les contraintes de
     * 	{@code contraint}; sinon aucune contrainte n'est présente.
     *
     * @return Une option contenant l' {@link Integer} en cas de succès,
     *     l'option vide en cas d'erreur.
     */
    public static Optional<Integer> parseInt(final String token, final Optional<ArrayList<Integer>> contraint) {
        Optional<Integer> result;
        try {

            Integer nbEquipe = Integer.parseInt(token);
            if (contraint.isPresent() && nbEquipe < contraint.get().get(0)) {
                // `contraint.get()` est garanti de fonctionner grâce à la garde `contraint.isPresent()`
                afficher("La valeur ne doit pas étre infèrieur à " + contraint.get().get(0));
                result = Optional.empty();
            } else if (contraint.isPresent() && nbEquipe > contraint.get().get(1)){
                // `contraint.get()` est garanti de fonctionner grâce à la garde `contraint.isPresent()`
                afficher("La valeur ne doit pas étre supérieur à " + contraint.get().get(1));
                result = Optional.empty();
            } else if (contraint.isPresent() && contraint.get().get(2) != null && !Controleur.isPuissance2(nbEquipe)) {
                // `contraint.get()` est garanti de fonctionner grâce à la garde `contraint.isPresent()`
                afficher("La valeur doit étre une puissance de " + contraint.get().get(2));
                result = Optional.empty();
            } else if (contraint.isPresent() && contraint.get().get(3) != null && contraint.get().get(3) == 1 && nbEquipe%2 != 1){
                afficher("La valeur doit étre impaire.");
                result = Optional.empty();
            } else if (contraint.isPresent() && contraint.get().get(3) != null && contraint.get().get(3) == 2 && nbEquipe%2 != 0){
                afficher("La valeur doit étre paire.");
                result = Optional.empty();
            } else {
                result = Optional.of(nbEquipe);
            }

        }
        catch (Exception e) {
            afficher("La valeur saisie n'est pas valide.");
            result = Optional.empty();
        }
        return result;
    }

    /**
     * Interprète un token comme une {@link Integer}.
     *
     * @param token La chaîne de caractère à interpréter.
     *
     * @param Id la liste d'entier dans le quelle doit étre présant l'entier lut.
     * 	 * @return L'entier saisie par l'utilisa·teur/trice.
     *
     * @return Une option contenant l' {@link Integer} en cas de succès,
     *     l'option vide en cas d'erreur.
     */
    public static Optional<Integer> parseId(final String token, final ArrayList<Integer> Id) {
        Optional<Integer> result;
        try {

            Integer idSaisie = Integer.parseInt(token);
            int i = 0;
            while(i < Id.size() && idSaisie != Id.get(i)){
                i++;
            }
            if (i == Id.size()){
                afficher("L'Id saisie est inexistant.");
                result = Optional.empty();
            } else {
                result = Optional.of(idSaisie);
            }

        }
        catch (Exception e) {
            afficher("L'Id saisie n'est pas valide.");
            result = Optional.empty();
        }
        return result;
    }

    /**
     * Interprète un token comme une {@link LocalDate}.
     *
     * @param token La chaîne de caractère à interpréter.
     *
     * @param apres Si l'option contient une valeur, la date lue doit être
     *     ultérieure à {@code apres}; sinon aucune contrainte n'est présente.
     *
     * @return Une option contenant la {@link LocalDate} en cas de succès,
     *     l'option vide en cas d'erreur.
     */
    public static Optional<LocalDate> parseDate(final String token, final Optional<LocalDate> apres) {
        Optional<LocalDate> result;
        try {

            LocalDate date = LocalDate.parse(token);
            if (apres.isPresent() && apres.get().isAfter(date)) {
                // `apres.get()` est garanti de fonctionner grâce à la garde `apres.isPresent()`
                afficher("La date saisie n'est pas ultérieure à " + apres.get().toString());
                result = Optional.empty();
            } else {
                result = Optional.of(date);
            }
        }
        catch (DateTimeParseException ignored) {
            afficher("La date saisie n'est pas valide.");
            result = Optional.empty();
        }
        return result;
    }

    /**
     * Lit une date au format ISO-8601.
     *
     * @param apres Si l'option contient une valeur, la date lue doit être
     *     ultérieure à {@code apres}; sinon aucune contrainte n'est présente.
     *
     * @see java.time.format.DateTimeFormatter#ISO_LOCAL_DATE
     *
     * @return La date saisie par l'utilisa·teur/trice.
     */
    public static LocalDate lireDate(final Optional<LocalDate> apres) throws NoSuchElementException {
        afficher("Saisir une date au format YYYY-MM-DD :");//ISO-8601
        apres.ifPresent(date -> afficher("La date doit être ultérieure à " + date.toString()));
        return lireAvecErreurs(token -> parseDate(token, apres));
    }

    /**
     * Lit une date au format ISO-8601.
     * <p>
     * Alias pour {@code lireDate(Optional.of(apres))}.
     *
     * @param apres La date saisie doit être ultérieure à {@code apres}.
     *
     * @return La date saisie par l'utilisa·teur/trice.
     *
     * @see #lireDate(java.util.Optional)
     */
    public static LocalDate lireDate(final LocalDate apres) throws NoSuchElementException{
        return lireDate(Optional.of(apres));
    }

}
