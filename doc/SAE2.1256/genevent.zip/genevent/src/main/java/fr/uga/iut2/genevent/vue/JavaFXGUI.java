package fr.uga.iut2.genevent.vue;

import fr.uga.iut2.genevent.controleur.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;


/**
 * La classe JavaFXGUI est responsable des interactions avec
 * l'utilisa·teur/trice en mode graphique.
 * <p>
 * Attention, pour pouvoir faire le lien avec le
 * {@link Controleur}, JavaFXGUI n'est pas une
 * sous-classe de {@link javafx.application.Application} !
 * <p>
 * Le démarrage de l'application diffère des exemples classiques trouvés dans
 * la documentation de JavaFX : l'interface est démarrée à l'initiative du
 * {@link Controleur} via l'appel de la méthode
 * {@link #demarrerInteraction()}.
 */
public class JavaFXGUI extends IHM {



    private final Controleur controleur;
    private final CountDownLatch eolBarrier;  // /!\ ne pas supprimer /!\ : suivi de la durée de vie de l'interface

    private AccueilControleur accueilControleur;
    private CreerControleur creerControleur;
    private EquipeControleur equipeControleur;
    private ProjetControleur projetControleur;
    private RencontreControleur rencontreControleur;
    private RencontreGraphControleur rencontreGraphControleur;

    private FXMLLoader accueil, creer, projet, equipe, rencontre, rencontreGraph;

    // éléments vue nouvel·le utilisa·teur/trice
//    @FXML private TextField newUserForenameTextField;
//    @FXML private TextField newUserSurnameTextField;
//    @FXML private TextField newUserEmailTextField;
//    @FXML private Button newUserOkButton;
//    @FXML private Button newUserCancelButton;

    public JavaFXGUI(Controleur controleur) {
        this.controleur = controleur;
        accueilControleur = new AccueilControleur(this);
        creerControleur = new CreerControleur(this);
        equipeControleur = new EquipeControleur(this);
        projetControleur = new ProjetControleur(this);
        rencontreControleur = new RencontreControleur(this);
        rencontreGraphControleur = new RencontreGraphControleur(this);

        accueil = new FXMLLoader(getClass().getResource("PageAccueil.fxml"));
        creer = new FXMLLoader(getClass().getResource("creer.fxml"));
        projet = new FXMLLoader(getClass().getResource("projet.fxml"));
        equipe = new FXMLLoader(getClass().getResource("equipe.fxml"));
        rencontre = new FXMLLoader(getClass().getResource("Rencontre.fxml"));
        rencontreGraph = new FXMLLoader(getClass().getResource("RencontreGraph.fxml"));

        accueil.setController(accueilControleur);
        creer.setController(creerControleur);
        projet.setController(projetControleur);
        equipe.setController(equipeControleur);
        rencontre.setController(rencontreControleur);
        rencontreGraph.setController(rencontreGraphControleur);

        this.eolBarrier = new CountDownLatch(1);  // /!\ ne pas supprimer /!\
    }

    public Controleur getControleur(){
        return this.controleur;
    }

    /**
     * Point d'entrée principal pour le code de l'interface JavaFX.
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     *
     * @see javafx.application.Application#start(Stage)
     */
    public void start(Stage primaryStage) throws IOException {
        accueil = new FXMLLoader(getClass().getResource("PageAccueil.fxml"));
        accueil.setController(accueilControleur);

        Scene mainScene = new Scene(accueil.load(), 1600, 900);
        primaryStage.setTitle("Gestionnaire de Tournoi E-sport");
        primaryStage.setScene(mainScene);
        accueilControleur.loadTournoi();
        primaryStage.setResizable(false);
        accueilControleur.initImages();
        primaryStage.show();
    }

    /**
     * Entrée sur l'interface d'accueil.
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadAccueil(Stage primaryStage) throws IOException {
        accueil = new FXMLLoader(getClass().getResource("PageAccueil.fxml"));
        accueil.setController(accueilControleur);

        Scene mainScene = new Scene(accueil.load(), 1600, 900);

        primaryStage.setScene(mainScene);
        accueilControleur.loadTournoi();

        accueilControleur.initImages();
        primaryStage.show();
    }

    /**
     * Entrée sur l'interface de création du projet (tournoi).
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadCreer(Stage primaryStage) throws IOException {
        creer = new FXMLLoader(getClass().getResource("creer.fxml"));
        creer.setController(creerControleur);

        Scene mainScene = new Scene(creer.load(), 1600, 900);
        primaryStage.setScene(mainScene);
        creerControleur.initImages();
        primaryStage.show();
    }

    /**
     * Entrée sur l'interface d'affichage et de modification du projet (tournoi).
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadProjet(Stage primaryStage, String nomTournoi) throws IOException {
        projet = new FXMLLoader(getClass().getResource("projet.fxml"));
        projet.setController(projetControleur);

        Scene mainScene = new Scene(projet.load(), 1600, 900);
        primaryStage.setScene(mainScene);
        projetControleur.initImages();
        projetControleur.labelsTournoi(controleur.getTounoi(nomTournoi));
        primaryStage.show();
    }

    /**
     * Entrée sur l'interface d'affichage et de modification des equipe du tournoi.
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadEquipe(Stage primaryStage, String nomTournoi) throws IOException {
        equipe = new FXMLLoader(getClass().getResource("equipe.fxml"));
        equipe.setController(equipeControleur);

        Scene mainScene = new Scene(equipe.load(), 1600, 900);
        primaryStage.setScene(mainScene);
        equipeControleur.afficherEquipes(controleur.getTounoi(nomTournoi));
        equipeControleur.initImages();
        primaryStage.show();
    }

    /**
     * Entrée sur l'interface de génération des rencontres entre les équipes (sous la forme d'un "tableau").
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadRencontre(Stage primaryStage, String nomTournoi) throws IOException {
        rencontre = new FXMLLoader(getClass().getResource("Rencontre.fxml"));
        rencontre.setController(rencontreControleur);

        Scene mainScene = new Scene(rencontre.load(), 1600, 900);
        primaryStage.setScene(mainScene);

        rencontreControleur.afficherRencontres(controleur.getTounoi(nomTournoi));
        rencontreControleur.initImages();
        primaryStage.show();

    }

    /**
     * Entrée sur l'interface de génération des rencontres entre les équipes (sous la forme d'un arbe de tournoi).
     *
     * @param primaryStage stage principale de l'interface JavaFX, sur laquelle
     *     définir des scenes.
     *
     * @throws IOException si le chargement de la vue FXML échoue.
     */
    public void loadRencontreGraph(Stage primaryStage, String nomTournoi) throws IOException {
        rencontreGraph = new FXMLLoader(getClass().getResource("RencontreGraph.fxml"));
        rencontreGraph.setController(rencontreGraphControleur);

        Scene mainScene = new Scene(rencontreGraph.load(), 1600, 900);
        primaryStage.setScene(mainScene);
        rencontreGraphControleur.initImages();
        primaryStage.show();
    }


//-----  Éléments du dialogue  -------------------------------------------------

    private void exitAction() {
        // fermeture de l'interface JavaFX : on notifie sa fin de vie
        this.eolBarrier.countDown();
    }

//-----  Implémentation des méthodes abstraites  -------------------------------

    @Override
    public void afficherClassement(ArrayList<String> classement) {

    }

    @Override
    public void definirBO(String nomTournoi) {

    }

    @Override
    public void demarrerInteraction() {
        // démarrage de l'interface JavaFX
        Platform.startup(() -> {
            Stage primaryStage = new Stage();
            primaryStage.setOnCloseRequest((WindowEvent t) -> this.exitAction());
            try {
                this.start(primaryStage);
            }
            catch (IOException exc) {
                throw new RuntimeException(exc);
            }
        });

        // attente de la fin de vie de l'interface JavaFX
        try {
            this.eolBarrier.await();
        }
        catch (InterruptedException exc) {
            System.err.println("Erreur d'exécution de l'interface.");
            System.err.flush();
        }
    }

    @Override
    public void demarrerInteractionTournoi(InfosTournoi tournoi) {

    }

    @Override
    public void informerUtilisateur(String msg, boolean succes) {
        final Alert alert = new Alert(
                succes ? Alert.AlertType.INFORMATION : Alert.AlertType.WARNING
        );
        alert.setTitle("GenEvent");
        alert.setContentText(msg);
        alert.showAndWait();
    }

    @Override
    public void saisirNouveauTournoi(final Set<String> nomsExistants) {

    }

    @Override
    public void saisirNouvelEquipe(Set<String> nomsExistants, String t) {

    }

    @Override
    public void saisirModifEquipe(String nomEquipeActuelle) {

    }

    @Override
    public void choixSuppresionEquipes(Set<String> nomEquipes, String t) {

    }

    @Override
    public void supprimerTournoi() {

    }

    @Override
    public void importationTournoi() {

    }

    @Override
    public void exportationTournois() {

    }

    @Override
    public void afficherEquipes(Set<String> nomEquipes) {

    }

    @Override
    public void afficherTournoi(InfosTournoi Tournoi) {

    }

    @Override
    public void definirScoreMatch(String nomTournoi) {

    }

    @Override
    public void afficherRencontres(String nomTournoi) {

    }

    @Override
    public void demarrerInteractionRencontre(String tournoi) {

    }
}
