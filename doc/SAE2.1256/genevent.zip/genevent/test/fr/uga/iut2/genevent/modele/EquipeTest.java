package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.exeption.EquipeExeption;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EquipeTest {

	@Test
	void setLogo() {
	}

	@Test
	void setNomEquipe() throws EquipeExeption {

	}
}