package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.exeption.ScoreExeption;

import static org.junit.jupiter.api.Assertions.*;

class MatchTest {

	@org.junit.jupiter.api.Test
	void setScoreEquipe1()  {
		assertThrows(ScoreExeption.class, () -> {
			int negatif = -1;
		}, "Un score ne peut être négatif");

		assertThrows(Exception.class, () -> {
			Integer vide = null;
		}, "Un score ne peut pas être null");
	}

	@org.junit.jupiter.api.Test
	void setScoreEquipe2() {
		assertThrows(ScoreExeption.class, () -> {
			int  negatif = -1;
		}, "Un score ne peut être négatif");

		assertThrows(Exception.class, () -> {
			Integer vide = null;
		}, "Un score ne peut pas être null");
	}

}