package fr.uga.iut2.genevent.modele;

import fr.uga.iut2.genevent.exeption.TournoiExeption;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class TournoiTest {

	@Test
	void setNbEquipe() throws TournoiExeption {
		assertThrows(TournoiExeption.class, () -> {
			int inf = 0;
		}, "Un tournoi ne peut pas avoir moins de X équipe");
	}

	@Test
	void setTailleEquipe() throws TournoiExeption {
		assertThrows(TournoiExeption.class, () -> {
			int inf = 0;
		}, "Une équipe ne peut pas être de 0 joueur");
	}

	@Test
	void setDate() {

	}

	@Test
	void setNom() {
		assertThrows(TournoiExeption.class, () -> {
			String vide = null;
		}, "Un nom de tournoi ne peut être vide");

		assertThrows(TournoiExeption.class, () -> {
			String vide1 = "";
		}, "Un tournoi ne peut pas avoir un nom vide");
	}


	@Test
	void setLogo() {
	}

	@Test
	void genererRencontre() {
	}

	@Test
	void changerRencontre() {
	}


	@Test
	void removeEquipe() {
	}
}